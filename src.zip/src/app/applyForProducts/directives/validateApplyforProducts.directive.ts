import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';


@Directive({
    selector: '[validateApplyForAccount]',
})
export class ValidateApplyForAccountDirective {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let applyForAccountValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var applyForAccountValidation = (<any>$("#applyForAccountForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    accountType: {
                        required: true
                    },
                    emirate: {
                        required: true
                    },
                    companyName: {
                        required: true
                    },
                    salary: {
                        required: true
                    },
                    hearAboutUs: {
                        required: true
                    },
                    comments: {
                        required: true
                    }
                },
                messages: {
                    accountType: {
                        required: "Please make a selection"
                    },
                    emirate: {
                        required: "Please make a selection"
                    },
                    companyName: {
                        required: "Please fill in"
                    },
                    salary: {
                        required: "Please fill in"
                    },
                    hearAboutUs: {
                        required: "Please make a selection"
                    },
                    comments: {
                        required: "Please fill in"
                    }
                }
            });
            applyForAccountValidationSubmit = applyForAccountValidation.form();
            this.templateService.setFormValidatorFlag(applyForAccountValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateApplyForCard]',
})
export class ValidateApplyForCardDirective {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let applyForCardValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var applyForCardValidation = (<any>$("#applyForCardForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    cardType: {
                        required: true
                    },
                    emirate: {
                        required: true
                    },
                    companyName: {
                        required: true
                    },
                    salary: {
                        required: true
                    },
                    hearAboutUs: {
                        required: true
                    },
                    comments: {
                        required: true
                    }
                },
                messages: {
                    cardType: {
                        required: "Please make a selection"
                    },
                    emirate: {
                        required: "Please make a selection"
                    },
                    companyName: {
                        required: "Please fill in"
                    },
                    salary: {
                        required: "Please fill in"
                    },
                    hearAboutUs: {
                        required: "Please make a selection"
                    },
                    comments: {
                        required: "Please fill in"
                    }
                }
            });
            applyForCardValidationSubmit = applyForCardValidation.form();
            this.templateService.setFormValidatorFlag(applyForCardValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateApplyForLoan]',
})
export class ValidateApplyForLoanDirective {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let applyForLoanValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var applyForLoanValidation = (<any>$("#applyForLoanForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    loanType: {
                        required: true
                    },
                    emirate: {
                        required: true
                    },
                    companyName: {
                        required: true
                    },
                    salary: {
                        required: true
                    },
                    hearAboutUs: {
                        required: true
                    },
                    comments: {
                        required: true
                    }
                },
                messages: {
                    loanType: {
                        required: "Please make a selection"
                    },
                    emirate: {
                        required: "Please make a selection"
                    },
                    companyName: {
                        required: "Please fill in"
                    },
                    salary: {
                        required: "Please fill in"
                    },
                    hearAboutUs: {
                        required: "Please make a selection"
                    },
                    comments: {
                        required: "Please fill in"
                    }
                }
            });
            applyForLoanValidationSubmit = applyForLoanValidation.form();
            this.templateService.setFormValidatorFlag(applyForLoanValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateApplyForDeposit]',
})
export class ValidateApplyForDepositDirective {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let applyForDepositValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var applyForDepositValidation = (<any>$("#applyForDepositForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    depositType: {
                        required: true
                    },
                    emirate: {
                        required: true
                    },
                    companyName: {
                        required: true
                    },
                    salary: {
                        required: true
                    },
                    hearAboutUs: {
                        required: true
                    },
                    comments: {
                        required: true
                    }
                },
                messages: {
                    depositType: {
                        required: "Please make a selection"
                    },
                    emirate: {
                        required: "Please make a selection"
                    },
                    companyName: {
                        required: "Please fill in"
                    },
                    salary: {
                        required: "Please fill in"
                    },
                    hearAboutUs: {
                        required: "Please make a selection"
                    },
                    comments: {
                        required: "Please fill in"
                    }
                }
            });
            applyForDepositValidationSubmit = applyForDepositValidation.form();
            this.templateService.setFormValidatorFlag(applyForDepositValidationSubmit);
        });
    }
}