import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'applyForNewAccountStep1-component',
  templateUrl: './../templates/applyForNewAccountStep1.html'
})
export class ApplyForNewAccountStep1Component {
	@Output() validateApplyForProductEvent = new EventEmitter();

	validate(valid :boolean){
		if(valid){
			this.validateApplyForProductEvent.emit();
		}		
	}
}