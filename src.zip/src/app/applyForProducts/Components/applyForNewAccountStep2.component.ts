import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'applyForNewAccountStep2-component',
  templateUrl: './../templates/applyForNewAccountStep2.html'
})
export class ApplyForNewAccountStep2Component {
	@Output() reviewApplyForProductEvent = new EventEmitter();
	@Output() backApplyForProductEvent = new EventEmitter();

	review(){
		this.reviewApplyForProductEvent.emit();
	}

	back(){
		this.backApplyForProductEvent.emit();
	}

}