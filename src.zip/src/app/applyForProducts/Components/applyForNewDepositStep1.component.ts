import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'applyForNewDepositStep1-component',
  templateUrl: './../templates/applyForNewDepositStep1.html'
})
export class ApplyForNewDepositStep1Component {
	@Output() validateApplyForProductEvent = new EventEmitter();

	validate(valid :boolean){
		if(valid){
			this.validateApplyForProductEvent.emit();	
		}	
	}
}