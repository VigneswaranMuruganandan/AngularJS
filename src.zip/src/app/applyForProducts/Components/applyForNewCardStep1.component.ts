import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'applyForNewCardStep1-component',
  templateUrl: './../templates/applyForNewCardStep1.html'
})
export class ApplyForNewCardStep1Component {
	@Output() validateApplyForProductEvent = new EventEmitter();

	validate(valid :boolean){
		if(valid){
			this.validateApplyForProductEvent.emit();	
		}	
	}
}



