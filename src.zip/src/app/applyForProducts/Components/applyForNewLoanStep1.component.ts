import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'applyForNewLoanStep1-component',
  templateUrl: './../templates/applyForNewLoanStep1.html'
})
export class ApplyForNewLoanStep1Component {
	@Output() validateApplyForProductEvent = new EventEmitter();

	validate(valid :boolean){
		if(valid){
			this.validateApplyForProductEvent.emit();	
		}	
	}
}