import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'applyForNewLoanStep3-component',
  templateUrl: './../templates/applyForNewLoanStep3.html'
})
export class ApplyForNewLoanStep3Component {
	

}