import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'applyForNewDepositStep3-component',
  templateUrl: './../templates/applyForNewDepositStep3.html'
})
export class ApplyForNewDepositStep3Component {
	

}