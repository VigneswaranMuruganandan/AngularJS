import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'applyForNewAccountStep3-component',
  templateUrl: './../templates/applyForNewAccountStep3.html'
})
export class ApplyForNewAccountStep3Component {
	

}