import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'applyForNewCardStep3-component',
  templateUrl: './../templates/applyForNewCardStep3.html'
})
export class ApplyForNewCardStep3Component {
	

}