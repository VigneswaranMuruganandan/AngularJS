import { Component, OnInit, Input} from '@angular/core';
import { 
    GlobalVariable, 
    SendOtpRequest, SendOtpResponse, AppSession,
    StaticDataResponse, 
    StaticData, 
    SharedService, 
    TemplateService, 
    ErrorService,
    SpinnerService ,
    Router
} from '../../shared';

@Component({
  templateUrl: './../templates/baseApplyForNewCard.html'
})
export class BaseApplyForNewCardComponent implements OnInit {
	public stepValue :number;

	constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

	ngOnInit() {
        //this.errorService.resetErrorResp();
        this.stepValue = 1;
    }

    validateApplyForProduct(){
    	this.stepValue = 2;
    }

    reviewApplyForProduct(){
    	this.stepValue = 3;
    }

    backApplyForProduct(value :number){
        if(value){
            this.stepValue = value;
        }
    }

}