import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'applyForNewCardStep2-component',
  templateUrl: './../templates/applyForNewCardStep2.html'
})
export class ApplyForNewCardStep2Component {
	@Output() reviewApplyForProductEvent = new EventEmitter();
	@Output() backApplyForProductEvent = new EventEmitter();

	review(){
		this.reviewApplyForProductEvent.emit();
	}

	back(){
		this.backApplyForProductEvent.emit();
	}
}