import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'dashboard-footer',
  templateUrl: './../templates/dashboardFooter.html'
})
export class DashboardFooterComponent {
	
}