import { Component } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { SharedService } from '../services/shared.service';
import { ErrorService } from '../services/error.service';
import { SessionContext} from '../model/sessionContext';
import { AuthRequest} from '../../register/model/authRequest';
import { AuthData} from '../model/authData';
import { Router } from '@angular/router';
import {TemplateService} from '../../shared/services/template.service';

@Component({
  selector: 'dashboard-header',
  templateUrl: './../templates/dashboardHeader.html'
})
export class DashboardHeaderComponent {

	constructor( private sharedService: SharedService,
				 private errorService: ErrorService,
		         private router: Router,
		         private templateService: TemplateService){}
	
	logout(){
		let data = new AuthRequest();
		data.deviceID = SessionContext.getInstance().deviceID
		this.sharedService.logout(data)
          .subscribe(
              resp => this.handleLogout(resp),
              error => this.sharedService.handleError(error)
          );
	}
	handleLogout(resp : AuthData){
		this.errorService.resetErrorResp();
		if(resp && resp.result.status == 'success'){
			SessionContext.destroyInstance(resp);
            this.router.navigate(['/login']);
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}

	onResize(event:any) {
	  this.templateService.showHideMenu();
      this.templateService.checkMenuState();
	}
}