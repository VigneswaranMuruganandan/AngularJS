import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'breadcrum',
  template: `
  			<ul class="bulletin-breadcrumb">
	            <li>
	               <a href="javascript:void(0);">{{breadCrum[0]}}</a>
	            </li>
	            <li>
	               <span class="chevron right"></span>
	            </li>
	            <li>
	               <a href="javascript:void(0);">breadCrum[1]</a>
	            </li>
	            <li>
	               <span class="chevron right"></span>
	            </li>
	            <li class="active">
	               <a href="javascript:void(0);">breadCrum[2]</a>
	            </li>
	         </ul>
  			`
})
export class BreadCrumComponent implements OnInit {
	public breadCrum : string[];
	
	constructor(private translate: TranslateService) {}

	ngOnInit() {
		this.breadCrum[0] = 'Dashboard';
		this.breadCrum[1] = '';
		this.breadCrum[2] = '';
	}
	
}