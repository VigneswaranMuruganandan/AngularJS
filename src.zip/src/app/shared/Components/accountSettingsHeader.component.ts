import { Component, OnInit } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { Router, Routes, RouterModule }  from '@angular/router';
import { UserContext } from '../model/userContext';
import { SessionContext } from '../model/sessionContext';
import { UserDetails } from '../model/userDetails';

@Component({
  selector: 'accountsettingsheader-component',
  templateUrl: './../templates/accountSettingsHeader.html'
})
export class AccountSettingsHeaderComponent implements OnInit{
	userDetails:UserDetails;

	constructor( private router:Router, 
		         private translate: TranslateService) {}

	  ngOnInit() {
      this.userDetails = UserContext.getInstance().userDetails;
    }

    changeLanguage(lang : string){
    	this.translate.use(lang);
      (lang == 'en') ? $('body').removeClass('arabic-design') :$('body').addClass('arabic-design');
      this.router.navigate(['/dashboard']);
	  }
}