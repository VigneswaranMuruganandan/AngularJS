import { Component, Input, OnInit, ViewChild} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { MultipleLoginSessionComponent } from '../../shared/Components/multipleLoginSession.component';
import { PlatformLocation } from '@angular/common';
import { AuthRequest} from '../../register/model/authRequest';
import { SessionContext} from '../model/sessionContext';
import { SharedService } from '../services/shared.service';
import { ErrorService } from '../services/error.service';
import { Router } from '@angular/router';

@Component({
  selector: 'baseview-component',
  templateUrl: './../templates/baseView.html'
})
export class BaseViewComponent implements OnInit{
	@ViewChild(MultipleLoginSessionComponent) loginSessionComponent:MultipleLoginSessionComponent;

	constructor( private sharedService: SharedService,
				 private errorService: ErrorService,
				 location: PlatformLocation,
				 private router: Router) {
		
		location.onPopState(() => {
	        let sessCtx = SessionContext.getInstance();
	        sessCtx.authKey.sessionType = 'IB_ANON';

	        let data = new AuthRequest();
			data.deviceID = sessCtx.deviceID
			this.sharedService.logout(data)
	          	.subscribe(
	              resp => {
	              	this.errorService.resetErrorResp();
	              	if(resp && resp.result.status == 'success'){
						SessionContext.destroyInstance(resp);
			        }else if(resp.result.status == 'error'){
			            this.errorService.setErrorResp(resp.result);
			        }
	              },
	              error => this.sharedService.handleError(error)
	          	);
	    });	  
	}

	ngOnInit() {
		this.loginSessionComponent.watch();
    }
}