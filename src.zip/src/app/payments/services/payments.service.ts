import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import { BillerListResp} from '../model/billerListResp';
import { SetupForPaymentResponse} from '../model/setupForPaymentResponse';
import { SetupForPaymentRequest} from '../model/setupForPaymentRequest';
import { FetchBalanceForPaymentRequest } from '../model/fetchBalanceForPaymentRequest';
import { FetchBalanceForPaymentResponse } from '../model/fetchBalanceForPaymentResponse';
import { ExecutePaymentRequest} from '../model/executePaymentRequest';
import { ExecutePaymentResponse} from '../model/executePaymentResponse';
import { SetupForCharityResponse} from '../model/setupForCharityResponse';
import { ExecuteCharityPaymentRequest} from '../model/executeCharityPaymentRequest';
import { Biller} from '../../beneficiaries/model/biller';
import { ValidateBeneficiaryRequest} from '../../beneficiaries/model/validateBeneficiaryRequest';
import { APIResponse } from '../../shared/model/apiResponse';
import { DeleteBillerBeneRequest} from '../../beneficiaries/model/deleteBillerBeneRequest';
import {
    GlobalURL,
    StaticDataResponse,
    StaticData
} from '../../shared';

@Injectable()
export class PaymentsService{

  constructor(private serviceInvoker: ServiceInvoker) {}

    fetchBenePaymentList(): Observable <BillerListResp> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.BENE_PAYMENT_FETCH,null)
                                .map(resp => JSON.parse(resp));
    }

  	paymentSetup(data:SetupForPaymentRequest): Observable <SetupForPaymentResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.PAYMENTS.SETUP_FOR_PAYMENT,data)
                                .map(resp => JSON.parse(resp));
    }

    balanceEnquiryForPayment(data:FetchBalanceForPaymentRequest):Observable <FetchBalanceForPaymentResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.PAYMENTS.BALANCE_FETCH_FOR_PAYMENT,data)
                                .map(resp => JSON.parse(resp));
    }

    validateBillerBeneficary(data:ValidateBeneficiaryRequest): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.BENE_VALIDATE,data)
                                .map(resp => JSON.parse(resp));
    }

    executePayment(data:ExecutePaymentRequest):Observable <ExecutePaymentResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.PAYMENTS.EXECUTE_PAYMENT,data)
                                .map(resp => JSON.parse(resp));
    }
    
    setupCharityList(): Observable <StaticDataResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.PAYMENTS.SETUP_FOR_CHARITY_LIST,null)
                                .map(resp => JSON.parse(resp));
    }

    setupCharity(): Observable <SetupForCharityResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.PAYMENTS.SETUP_FOR_CHARITY,null)
                                .map(resp => JSON.parse(resp));
    }

    executeCharityPayment(data :ExecuteCharityPaymentRequest): Observable <ExecutePaymentResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.PAYMENTS.CHARITY_PAYMENT, data)
                                .map(resp => JSON.parse(resp));
    }

    deleteBillPayBeneficiary(data:DeleteBillerBeneRequest):Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.DELETE_BILLPAY_TEMPLATE,data)
                                .map(resp => JSON.parse(resp));
    }
}


