import { Autopay } from '../../transfers/model/autopay';

export class ExecutePaymentRequest {

	accountType:string;
	currencyCode:string;
	transactionAmount:number;
	availableBalance:number;
	amountDue:number;
	transactionId:string;
	agency:string;
	consumerNo:string;
	telephoneNo:string;
	salikPinNo:string;
	createAutopay:boolean;
	authKey:string;
	txnRef:string;
	accountOrCardNo:string;
	nickName:string;
	createBiller:boolean;
	minAmount:number;
	productType:string;
	autopay :Autopay;
}

