import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { GlobalVariable} from '../../shared/services/global';
import { Product } from '../../shared/model/product';
import { TemplateService } from '../../shared/services/template.service';

@Component({
  selector: 'paymentsTransactions-component',
  templateUrl: './../templates/paymentsTransactions.html'
})
export class PaymentsTransactionsComponent implements OnInit  {

	public imageUrl:any;

	/*@Output() confirmBillerReviewButtonEvent = new EventEmitter();
	@Output() backBillerReviewButtonEvent = new EventEmitter();*/


	constructor( public templateService: TemplateService){}

	ngOnInit() { 
	 /* this.imageUrl = GlobalVariable.IMAGE_URL;
	  this.product = this.setupForPaymentResponse.fundingSources[this.templateService.getSelectIndex(this.setupForPaymentResponse.fundingSources,'prodRef',this.createBillerBeneRequest.accountOrCardNo)];*/
	}
	
	

    
}
