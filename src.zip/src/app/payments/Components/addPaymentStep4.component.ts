import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';
import { ExecutePaymentRequest} from '../model/executePaymentRequest';
import { ExecutePaymentResponse} from '../model/executePaymentResponse';
import { GlobalVariable} from '../../shared/services/global';
import { FetchBalanceForPaymentResponse } from '../model/fetchBalanceForPaymentResponse';

@Component({
  selector: 'addPaymentStep4-component',
  templateUrl: './../templates/addPaymentStep4.html'
})
export class AddPaymentStep4Component implements OnInit {
 	
 	public imageUrl:any;
 	@Input() salikAutoBy:string;
 	@Input() createBillerBeneficiary:boolean;
 	@Input() executePaymentRequest:ExecutePaymentRequest;
 	@Input() executePaymentResponse:ExecutePaymentResponse;
 	@Input() fetchBalanceForPaymentResponse:FetchBalanceForPaymentResponse;

 	constructor( private router: Router) {}

 	ngOnInit() { 
	  this.imageUrl = GlobalVariable.IMAGE_URL;
	}

	backToPayments(){
		this.router.navigate([GlobalVariable.ROUTE_MAPPING.PAYMENTS]);
	}
    
    
}
