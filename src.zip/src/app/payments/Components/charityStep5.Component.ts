import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { ExecutePaymentResponse} from '../model/executePaymentResponse';
import { ExecuteCharityPaymentRequest} from '../model/executeCharityPaymentRequest';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    StaticDataResponse, 
    StaticData,
    GlobalVariable,
    Product
} from '../../shared';
import { SetupForCharityResponse} from '../model/setupForCharityResponse';

@Component({
  selector: 'charitystep5-component',
  templateUrl: './../templates/charityStep5.html'
})
export class CharityStep5Component implements OnInit {
	@Input() charityPaymentResponse:ExecutePaymentResponse;
	@Input() charityPaymentRequest :ExecuteCharityPaymentRequest;
	@Input() setupForCharityResponse :SetupForCharityResponse;
    @Output() reloadCharityEvent = new EventEmitter();
	product :Product;
	todayDate :string;

	constructor( private templateService: TemplateService){}

	ngOnInit() {
		this.product = this.setupForCharityResponse.fundingSources[this.templateService.getSelectIndex(this.setupForCharityResponse.fundingSources,'prodRef',this.charityPaymentRequest.sourceAccountNumber)];
		this.todayDate = this.templateService.getTodaydate('DD/MM/YYYY');
	}

    reload(){
        this.reloadCharityEvent.emit();
    }
}