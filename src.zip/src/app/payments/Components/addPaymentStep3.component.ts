import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';

@Component({
  selector: 'addPaymentStep3-component',
  templateUrl: './../templates/addPaymentStep3.html'
})
export class AddPaymentStep3Component {

	@Output() validateOTPEvent = new EventEmitter();
	@Output() backOTPButtonEvent = new EventEmitter();
	@Input() sendOtpRequest:SendOtpRequest;
	@Input() sendOtpResponse:SendOtpResponse;

	validateOTP(otp : string){
		this.validateOTPEvent.emit(otp);
	}

	backOTP(){
		this.backOTPButtonEvent.emit();
	}
    
}
