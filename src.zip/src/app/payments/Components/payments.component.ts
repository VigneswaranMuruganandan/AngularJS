import { Component, OnInit, Input, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { AppSession} from '../../shared/model/appSession';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { GlobalVariable} from '../../shared/services/global';
import { TemplateService} from '../../shared/services/template.service';
import { BillerListResp} from '../model/billerListResp';
import { Biller} from '../../beneficiaries/model/biller';
import { PaymentsService} from '../services/payments.service';
import { UserContext} from '../../shared/model/userContext';
import { DeletePaymentComponent }   from './deletePayment.component';

@Component({
  templateUrl: './../templates/payments.html'
})
export class PaymentsComponent implements OnInit{

    @ViewChild('tableBiller') tableBillerElem: any;
    @ViewChild('tableAutoBiller') tableAutoBillerElem: any;
    @ViewChild(DeletePaymentComponent) deletePaymentComponent:DeletePaymentComponent;
    public billerListResp:BillerListResp;
    public biller:Biller;
    public imageUrl:any;
    //public tempBillers: any = [];
    public rowsBillers: any = [];
    //public tempAutoBillers: any = [];
    public rowsAutoBillers: any = [];
    public paymentRouter:string;

    constructor(  private sharedService: SharedService,
                  private errorService: ErrorService,
                  private spinnerService: SpinnerService,
                  public templateService: TemplateService,
                  private paymentsService:PaymentsService,
                  private router: Router) {}

  	ngOnInit() { 
        this.initPayments();
    }

    initPayments(){
      this.spinnerService.startSpinner('loader');
      this.getBillerList();
      this.imageUrl = GlobalVariable.IMAGE_URL;
      this.errorService.resetErrorResp();
      this.paymentRouter = GlobalVariable.ROUTE_MAPPING.PAYMENTS_EXECUTE;
    }

    getBillerList(){
      this.paymentsService.fetchBenePaymentList()
        .subscribe(
            resp => this.handleBenePaymentResp(resp),
            error => this.sharedService.handleError(error)
        );
    }

    handleBenePaymentResp(resp:BillerListResp){
      this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.billerListResp = new BillerListResp();
          this.billerListResp = resp;
          this.initTableData(resp);
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
    }

    initTableData(beneList:BillerListResp){
      if(beneList.billerList.length>0){
        this.rowsBillers = beneList.billerList.filter(biller => biller.autoPayment==false);
        //this.tempBillers = beneList.billerList.filter(biller => biller.autoPayment==false);
        this.rowsAutoBillers = beneList.billerList.filter(biller => biller.autoPayment==true);
        //this.tempAutoBillers = beneList.billerList.filter(biller => biller.autoPayment==true);
      }
      this.tableBillerElem.offset = 0;
      this.tableAutoBillerElem.offset = 0;
    }

    payBill(biller:Biller,paymentType:string){
      if(paymentType == 'B_P'){
        UserContext.getInstance().biller = null;
        this.router.navigate([GlobalVariable.ROUTE_MAPPING.PAYMENTS_EXECUTE]);
      }
      if(paymentType == 'P'){
        UserContext.getInstance().biller = biller;
        this.router.navigate([GlobalVariable.ROUTE_MAPPING.PAYMENTS_EXECUTE]);
      }
    }

    deleteBiller(biller:Biller){
      this.biller = biller;
     (<any>$('#deleteBene-payment')).modal('show');
      if(this.deletePaymentComponent){
        this.deletePaymentComponent.initDeleteBeneficiary();
      }
    }
    
}
