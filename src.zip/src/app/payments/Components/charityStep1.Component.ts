import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    StaticDataResponse, 
    StaticData,
    GlobalVariable
} from '../../shared';
import { ExecuteCharityPaymentRequest} from '../model/executeCharityPaymentRequest';

@Component({
  selector: 'charitystep1-component',
  templateUrl: './../templates/charityStep1.html'
})
export class CharityStep1Component implements OnInit{
	@Output() charitySelectionEvent = new EventEmitter();
    @Input() charityItems :StaticDataResponse;
    @Input() charityPaymentRequest :ExecuteCharityPaymentRequest;
	public GlobalVariable :any;

	constructor( private templateService: TemplateService,
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

	ngOnInit() { 
    	this.GlobalVariable = GlobalVariable;
  }

  charitySelection(data :StaticData){
      if(data){
          this.charityPaymentRequest.charityName = data.description;
      }
  }

	validateCharitySelectionEvent(){
		this.charitySelectionEvent.emit();
	}
}