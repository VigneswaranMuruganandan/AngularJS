import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    SendOtpRequest, SendOtpResponse, Router,
    TranslateService,
    ServerError,
    Product
} from '../../shared';

@Component({
  selector: 'charitystep4-component',
  templateUrl: './../templates/charityStep4.html'
})
export class CharityStep4Component{
	@Output() validateCharityOTPEvent = new EventEmitter();
	@Output() backbuttonCharityEvent = new EventEmitter();
    @Input() sendOtpRequest:SendOtpRequest;
    @Input() sendOtpResponse:SendOtpResponse;
	
	constructor( private templateService: TemplateService,
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

	validateOTP(otp : string){
		this.errorService.resetErrorResp();
		this.validateCharityOTPEvent.emit(otp);
	}

	back(){
        this.errorService.resetErrorResp();
		this.backbuttonCharityEvent.emit(3);
	}
}