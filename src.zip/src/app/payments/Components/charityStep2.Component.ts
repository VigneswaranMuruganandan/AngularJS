import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    StaticDataResponse, 
    StaticData,
    GlobalVariable
} from '../../shared';
import { ExecuteCharityPaymentRequest} from '../model/executeCharityPaymentRequest';
import { SetupForCharityResponse} from '../model/setupForCharityResponse';

@Component({
  selector: 'charitystep2-component',
  templateUrl: './../templates/charityStep2.html'
})
export class CharityStep2Component implements OnInit {
	@Output() submitCharityPaymentEvent = new EventEmitter();
	@Output() backbuttonCharityEvent = new EventEmitter();
  @Output() resetCharityEvent = new EventEmitter();
	@Input() charityItems :StaticDataResponse;
  @Input() charityPaymentRequest :ExecuteCharityPaymentRequest;
  @Input() setupForCharityResponse :SetupForCharityResponse;
  public GlobalVariable :any;

    constructor( private templateService: TemplateService,
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

	ngOnInit() { 
    	this.GlobalVariable = GlobalVariable;
    }

	submitCharity(valid :boolean){
    if(valid){
      this.charityPaymentRequest.currency = 'AED';
      this.submitCharityPaymentEvent.emit();
    }
	}

	removeCharity(){
		this.resetCharityEvent.emit();
	}

	back(){
		this.backbuttonCharityEvent.emit(1);
	}
}