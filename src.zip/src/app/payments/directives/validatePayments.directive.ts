import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';

@Directive({
    selector: '[validateCharity]',
})
export class ValidateCharityDirective {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let emiratesStep2Submit:boolean;
        this.zone.runOutsideAngular(() => {
            var emiratesSelectionValidation = (<any>$("#charityForm")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("select")) {
                        element.parent().append(error);
                    }
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    sourceAccount: {
                        required: true
                    },
                    donationAmount:{
                        required: true,
                        min: 1
                    }
                },
                messages: {
                    sourceAccount: {
                        required: "Please make a selection",
                    },
                    donationAmount:{
                        required: "Please fill in",
                        min : "Donation amount should be greater than 0"
                    }
                }
            });
            emiratesStep2Submit = emiratesSelectionValidation.form();
            this.templateService.setFormValidatorFlag(emiratesStep2Submit);
        });
    }
}
/*
* Validation for ADD Payment and Payment
*/
@Directive({
    selector: '[validatePayment]',
})
export class ValidateAddPayment {

    @Input() executePaymentRequest: any;
    @Input() fetchBalanceForPaymentResponse:any;

    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {

        var el = $(this.el.nativeElement);
        let paymentForm:boolean;
        this.zone.runOutsideAngular(() => {
            (<any>$).validator.addMethod("autoConsumereLengthValidation", function (value, element, param) {
                  if((param.executePaymentRequest && param.executePaymentRequest.agency =="ETISALAT") || 
                      (param.executePaymentRequest && param.executePaymentRequest.agency =="DU")){
                     return true;
                  }else{
                     return this.optional(element) || (value.length == 10 );
                  }
            
             });
            var addPaymentValidation = (<any>$("#addPaymentForm")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                     if (element.is("select")) {
                        element.parent().append(error);
                    }
                },
                 rules: {
                    billerAgency: {
                        required: true
                    },
                    consumerNo: {
                        required: true
                       // autoConsumereLengthValidation: this.executePaymentRequest
                    },
                    nickName: {
                        required: true
                    },
                    salikPinNo: {
                        required: true
                    },
                    minAmount: {
                        required: true
                    },
                    amount: {
                        required: true,
                        min: () => { 
                                if(this.executePaymentRequest && this.executePaymentRequest.agency){
                                    if(this.fetchBalanceForPaymentResponse && this.fetchBalanceForPaymentResponse.minimumAmount)
                                    return this.fetchBalanceForPaymentResponse.minimumAmount.value;
                                }
                            },
                        max: () => { 
                            if(this.executePaymentRequest && this.executePaymentRequest.agency){
                            	if(this.fetchBalanceForPaymentResponse && this.fetchBalanceForPaymentResponse.maximumAmount)
                                return this.fetchBalanceForPaymentResponse.maximumAmount.value;
                            } 
                        }
                    },
                    sourceAccount: {
                        required: true
                    }
                },
                messages: {
                    billerAgency: {
                        required: "Please select"
                    },
                    consumerNo: {
                        required: "Please fill in"
                        //autoConsumereLengthValidation: "Length of consumer number should be 10"
                    },
                    nickName: {
                        required: "Please fill in"
                    },
                    salikPinNo: {
                        required: "Please fill in"
                    },
                    minAmount: {
                        required: "Please fill in"
                    },
                    amount: {
                        required: "Please fill in",
                        min: () => { 
                                if(this.executePaymentRequest && this.executePaymentRequest.agency){
                                	if(this.fetchBalanceForPaymentResponse && this.fetchBalanceForPaymentResponse.minimumAmount)
                                    return "Minimum payment accepted is AED "+this.fetchBalanceForPaymentResponse.minimumAmount.valueFmt;
                                } 
                            },
                        max: () => { 
                                if(this.executePaymentRequest && this.executePaymentRequest.agency){
                                	if(this.fetchBalanceForPaymentResponse && this.fetchBalanceForPaymentResponse.maximumAmount)
                                    return "Maximum payment accepted is AED "+this.fetchBalanceForPaymentResponse.maximumAmount.valueFmt;
                                } 
                            }
                    },
                    sourceAccount: {
                        required: "Please fill in"
                    }
                }
            });
            paymentForm = addPaymentValidation.form();
            this.templateService.setFormValidatorFlag(paymentForm);
            
            });
    }
}