import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SharedService } from '../../shared/services/shared.service';
import { CustomerData } from '../../register/model/customerData';
import { TemplateService } from '../../shared/services/template.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ForgotPasswordService } from '../services/forgotPassword.service';
import { ErrorService } from '../../shared/services/error.service';
import { ForgotPassword } from '../model/forgotPassword';
import { VerifyPasswordResponse } from '../../shared/model/verifyPasswordResponse';

@Component({
  selector: 'forgotpasswordstep4-component',
  templateUrl: './../templates/forgotPasswordStep4.html'
})
export class ForgotPasswordStep4Component implements OnInit{
	public showConfirmPassword: boolean;
	@Input() validPasswordFlag: boolean;
	@Output() editUsernameForgotPwdEvent = new EventEmitter();
	@Output() forgotPwdBackEvent = new EventEmitter();
	@Output() validateForgotNewPasswordEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	public passwordData : any;

	constructor( private forgotPasswordService: ForgotPasswordService,
				 private sharedService: SharedService, 
				 private templateService: TemplateService,
				 private errorService: ErrorService,
				 private spinnerService: SpinnerService) {}

	ngOnInit() {
		this.passwordData = {"password":"","confirmPassword":""};
		this.showConfirmPassword = false;
		this.spinnerService.stopSpinner('loader');
	}

	editUsername(){
		this.editUsernameForgotPwdEvent.emit();
	}

	passwordValidations(flag: boolean){
		this.validPasswordFlag = flag;
	}

	validatePassword(){
		if(this.validPasswordFlag){
			this.errorService.resetErrorResp();
			let data = new ForgotPassword();
	        data.pwd = this.passwordData.password;
			this.forgotPasswordService.verifyPassword(data)
	                .subscribe(
	                    resp => this.handleVerifyPasswordResp(resp),
	                    error => this.sharedService.handleError(error)
	                );	
		}		
	}

	handleVerifyPasswordResp(resp: VerifyPasswordResponse){
		if(resp && resp.result.status == 'success'){
            this.showConfirmPassword = true;
        }else if(resp && resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}

	validateConfirmPassword(valid: boolean){
		if(valid){
			this.errorService.resetErrorResp();
			this.templateService.resetFormValidatorFlag();
			this.validateForgotNewPasswordEvent.emit(this.passwordData.password);
		}
	}

	back(){
		this.forgotPwdBackEvent.emit(1);
	}

	backConfirmPwd(){
		this.showConfirmPassword = false;
	}
}