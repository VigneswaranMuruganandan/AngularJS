import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { CustomerData } from '../../register/model/customerData';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'forgotpasswordstep3-component',
  templateUrl: './../templates/forgotPasswordStep3.html'
})
export class ForgotPasswordStep3Component implements OnInit {
	@Input() validUsernameFlag: boolean;
	@Output() validateForgotPwdUsernameEvent = new EventEmitter();
	@Output() forgotPwdBackEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	public userName:string;
	
	constructor( private errorService: ErrorService ){}

	ngOnInit() {
		if(this.customerData.userName){
			this.userName = this.customerData.userName;
			this.validUsernameFlag = true;
			(<any>$('.validate li')).addClass('success');
		}
	}

    usernameValidations(flag :boolean){
    	this.validUsernameFlag = flag;
    }

	validateUsername(){
		this.errorService.resetErrorResp();
		this.validateForgotPwdUsernameEvent.emit(this.userName);
	}
	back(){
		this.forgotPwdBackEvent.emit(1);
	}
}