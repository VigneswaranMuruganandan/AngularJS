import { AuthRequest } from '../../shared/model/authRequest';

export class UpdatePassword extends AuthRequest{
	oldPassword: string;
	newPassword: string;
	confirmPassword: string;
}