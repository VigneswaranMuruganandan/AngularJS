export class Alert{
	email :boolean ;
	sms:boolean;
}