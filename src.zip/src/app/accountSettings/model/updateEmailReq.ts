export class UpdateEmailReq{
	email :string;
	authKey: string;
	txnRef :string;
}