export class AlertDetail{
	date:string;
    alertType:string;
    alertMessage:string;
    address:string;

}