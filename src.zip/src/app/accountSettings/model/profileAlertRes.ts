import { APIResponse } from '../../shared/model/apiResponse';
import { Alert } from './alert';

export class ProfileAlertRes extends APIResponse{
	profileAlert :Alert ;
	maketingAlert:Alert;
	loginAlert:Alert;
}