import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './accountSettings.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { FormsModule } from '@angular/forms';
import { AccountSettingsComponent }   from './Components/accountSettings.component';
import { PersonalInformationComponent }   from './Components/personalInformation.component';
import { UpdateEmailComponent }   from './Components/updateEmail.component';
import { UpdateEmailStep1Component }   from './Components/updateEmailStep1.component';
import { UpdateEmailStep2Component }   from './Components/updateEmailStep2.component';
import { UpdateEmailStep3Component }   from './Components/updateEmailStep3.component';
import { UpdateUsernamePasswordComponent }   from './Components/updateUsernamePassword.component';
import { UpdateUsernamePasswordStep1Component }   from './Components/updateUsernamePasswordStep1.component';
import { UpdateUsernamePasswordStep2Component }   from './Components/updateUsernamePasswordStep2.component';
import { UpdateUsernamePasswordStep3Component }   from './Components/updateUsernamePasswordStep3.component';
import { UpdateEStatementComponent }   from './Components/updateEStatement.component';
import { UpdateEStatementStep1Component }   from './Components/updateEStatementStep1.component';
import { UpdateEStatementStep2Component }   from './Components/updateEStatementStep2.component';
import { UpdateEStatementStep3Component }   from './Components/updateEStatementStep3.component';
import { MyAccountsComponent }   from './Components/myAccounts.component';
import { MyCardsComponent }   from './Components/myCards.component';
import { MyAlertsComponent }   from './Components/myAlerts.component';
import { AlertCenterComponent }   from './Components/alertCenter.component';
import { EStatementModalComponent }   from './Components/estatementModal.component';
import { AccountsService} from '../accounts/services/accounts.service';
import { AccountSettingsService} from './services/accountSettings.service';

import { 
  ValidatePersonalInfo,
  ValidateChangePasswordDirective
} from './directives/validateAccountSettings.directive';

const ACCOLUNTSETTINGS_COMPONENTS = [
    AccountSettingsComponent,
    PersonalInformationComponent,
    UpdateEmailComponent,
    UpdateEmailStep1Component,
    UpdateEmailStep2Component,
    UpdateEmailStep3Component,
    UpdateUsernamePasswordComponent,
    UpdateUsernamePasswordStep1Component,
    UpdateUsernamePasswordStep2Component,
    UpdateUsernamePasswordStep3Component,
    UpdateEStatementComponent,
    UpdateEStatementStep1Component,
    UpdateEStatementStep2Component,
    UpdateEStatementStep3Component,
    MyAccountsComponent,
    MyCardsComponent,
    MyAlertsComponent,
    AlertCenterComponent,
    EStatementModalComponent
];

const ACCOLUNTSETTINGS_PROVIDERS = [
   SharedService,
   TemplateService,
   AccountsService,
   AccountSettingsService
];

const ACCOLUNTSETTINGS_DIRECTIVES = [
    ValidatePersonalInfo,
    ValidateChangePasswordDirective
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule
	],
  	declarations: [
	    ...ACCOLUNTSETTINGS_COMPONENTS,
	    ...ACCOLUNTSETTINGS_DIRECTIVES
	],
  	providers: [
  		...ACCOLUNTSETTINGS_PROVIDERS
  	]
})
export class AccountSettingsModule {}
