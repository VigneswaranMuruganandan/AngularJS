import { Component, OnInit, Input, ViewChild} from '@angular/core';
import { AccountSettingsService } from '../services/accountSettings.service';
import { UpdateEmailComponent } from './updateEmail.component';
import { UpdateUsernamePasswordComponent } from './updateUsernamePassword.component';
import {
    SharedService, SpinnerService, ErrorService, TemplateService, Router, TranslateService, ServerError, Product, GlobalVariable, AppSession, APIResponse, UserDetails, UserContext
} from '../../shared';


@Component({
  selector: 'personalinformation-component',
  templateUrl: './../templates/personalInformation.html'
})
export class PersonalInformationComponent implements OnInit{
	userDetails: UserDetails;
	@ViewChild(UpdateEmailComponent) updateEmail: UpdateEmailComponent;
    @ViewChild(UpdateUsernamePasswordComponent) updateUsernamePwd: UpdateUsernamePasswordComponent;

	constructor( private templateService: TemplateService,
				 private errorService: ErrorService,
				 private sharedService: SharedService,
				 private accountSettingsService: AccountSettingsService,
				 private spinnerService: SpinnerService) {}

	ngOnInit() {
        this.userDetails = UserContext.getInstance().userDetails;
    }

    changeEmailId(){
    	this.errorService.resetErrorResp();
    	this.updateEmail.init();
    	(<any>$('#changeEmail')).modal('show');
    }

    updateUsernamePassword(){
        this.errorService.resetErrorResp();
        this.updateUsernamePwd.init();
        (<any>$('#changeUnamePwd')).modal('show');
    }
}