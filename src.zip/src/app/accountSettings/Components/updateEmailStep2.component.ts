import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'updateEmailStep2-component',
  templateUrl: './../templates/updateEmailStep2.html'
})
export class UpdateEmailStep2Component implements OnInit{
	@Output() validateUpdateEmailEvent = new EventEmitter();
	@Output() backUpdateEmailEvent = new EventEmitter();

	constructor() {}
	
	ngOnInit(){}

	validateOTP(otp : string){
		//this.errorService.resetErrorResp();
		this.validateUpdateEmailEvent.emit(otp);
	}

	back(){
		this.backUpdateEmailEvent.emit(1);
	}

}