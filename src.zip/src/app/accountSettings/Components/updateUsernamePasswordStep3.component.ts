import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'updateUsernamePasswordStep3-component',
  templateUrl: './../templates/updateUsernamePasswordStep3.html'
})
export class UpdateUsernamePasswordStep3Component implements OnInit{
	@Input() currentTabUserPwd: string;
	@Output() backUpdateUsernamePasswordEvent = new EventEmitter();

	constructor() {}

	ngOnInit(){
		console.log(this.currentTabUserPwd);
	}

	back(){
		this.backUpdateUsernamePasswordEvent.emit(1);
	}

}