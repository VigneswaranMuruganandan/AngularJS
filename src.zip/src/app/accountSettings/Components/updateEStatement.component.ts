import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'updateEStatement-component',
  templateUrl: './../templates/updateEStatement.html'
})
export class UpdateEStatementComponent implements OnInit{
	public stepValue: number;

	constructor() {}
	
	ngOnInit(){
		this.stepValue = 1;
	}

	confirmUpdateEStatement(otp :string){
		this.stepValue = 2;
	}

	validateUpdateEStatement(){
		this.stepValue = 3;
	}

	backUpdateEStatement(step :number){
		this.stepValue = step;
	}

}