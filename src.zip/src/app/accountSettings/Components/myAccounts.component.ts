import { Component, OnInit, Input, OnChanges,SimpleChanges} from '@angular/core';
import {AccountSettingsService} from '../services/accountSettings.service';
import { APIResponse } from '../../shared/model/apiResponse';
import { NickNameReq } from '../model/nickNameReq';
import {
	SharedService, SpinnerService, ErrorService, TemplateService, Router, TranslateService, ServerError, Product, 
	GlobalVariable, Account, UserDetails, UserContext
} from '../../shared';
import { CustomerAccountsResponse} from '../../accounts/model/customerAccountsResponse';
import { AccountsService} from '../../accounts/services/accounts.service';

@Component({
  selector: 'myaccounts-component',
  templateUrl: './../templates/myAccounts.html'
})
export class MyAccountsComponent implements OnInit{
	customerAccountsResponse: CustomerAccountsResponse;
	accounts: Array <Account>;
	currentAccount :number;
	nickNameReq :NickNameReq;
	tempNickNameReq :NickNameReq;
	saveButtonShow :boolean;
	eStatementFlag :boolean;

	constructor(private accountsService: AccountsService,
				private accountSettingsService: AccountSettingsService,
				private sharedService: SharedService,
				private errorService: ErrorService,
				private spinnerService: SpinnerService,
				private templateService: TemplateService,) {}

	
	ngOnInit(){
		this.fetchAccounts();
		this.currentAccount = 0;
		this.saveButtonShow = true;
		this.eStatementFlag = UserContext.getInstance().userDetails.estatementPreference;
	}

	/*
    * Fetch Customer Accounts 
    */
    fetchAccounts() {
    	this.spinnerService.startSpinner('accountSettings');
        this.accountsService.fetchCustomerAccounts()
            .subscribe(
                resp => this.handleCustAcctsResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    
    /*
    * Handle Customer Accounts Response
    */
    handleCustAcctsResp(resp: CustomerAccountsResponse) {
    	this.spinnerService.stopSpinner('accountSettings');
        if (resp.result.status == "success") {
            this.customerAccountsResponse = new CustomerAccountsResponse();
            this.customerAccountsResponse = resp;
            if(this.customerAccountsResponse.customerProducts && this.customerAccountsResponse.customerProducts.accounts){
                this.accounts = this.customerAccountsResponse.customerProducts.accounts.length >0 ? this.customerAccountsResponse.customerProducts.accounts : [];
                this.onAccountSelection(this.currentAccount);
            }else{
                this.accounts = [];
            }
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }

    onAccountSelection(index : any){
		this.currentAccount = index;
		if(this.accounts && this.accounts.length > 0){
			this.nickNameReq = new NickNameReq();
			console.log(this.accounts[this.currentAccount]);
			this.nickNameReq.productID = this.accounts[this.currentAccount].number;
			this.nickNameReq.nickName = this.accounts[this.currentAccount].nickName;
			this.nickNameReq.isFavorite = this.accounts[this.currentAccount].isFavorite;
			let data = JSON.stringify(this.nickNameReq);
        	this.tempNickNameReq = JSON.parse(data);
			this.saveButtonShow = true;
		}
	}

	onFieldChanges(){
		this.saveButtonShow = this.templateService.dataComparsion(this.nickNameReq,this.tempNickNameReq);
	}

	saveAccountInformation(){
		this.spinnerService.startSpinner('accountSettings');
		this.accountSettingsService.updateNickName(this.nickNameReq)
        .subscribe(
           resp => this.handleUpdateNickNameResp(resp),
           error => this.sharedService.handleError(error)
        );
	}

	handleUpdateNickNameResp(resp:APIResponse){
		this.spinnerService.stopSpinner('accountSettings');
		if(resp && resp.result.status == 'success'){
            console.log(resp);
            this.accounts[this.currentAccount].nickName=this.nickNameReq.nickName;
            this.accounts[this.currentAccount].isFavorite=this.nickNameReq.isFavorite;
            let data = JSON.stringify(this.nickNameReq);
        	this.tempNickNameReq = JSON.parse(data);
			this.saveButtonShow = true;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
            this.saveButtonShow = false;
        }
	}
}