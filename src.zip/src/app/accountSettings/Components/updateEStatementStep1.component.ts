import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'updateEStatementStep1-component',
  templateUrl: './../templates/updateEStatementStep1.html'
})
export class UpdateEStatementStep1Component implements OnInit{
	@Output() confirmUpdateEStatementEvent = new EventEmitter();

	constructor() {}
	
	ngOnInit(){}

	confirm(){
		this.confirmUpdateEStatementEvent.emit();
	}

}