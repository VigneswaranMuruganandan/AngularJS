import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {
    TranslateService
} from '../../shared';

@Component({
  selector: 'updateEmailStep3-component',
  templateUrl: './../templates/updateEmailStep3.html'
})
export class UpdateEmailStep3Component{
	@Input() updateEmailRes: any;

	constructor() {}

}