import { NameObject } from '../../shared/model/nameObject';

export class MerchantItems {
    ItemID :number;
	Title :string;
	TitleAR :string;
	OfferDescription :string;
	OfferDetails :string;
	OfferSmallImage :string;
	OfferLargeImage :string;
	TermAndConditions :string;
	EndOffersDate :string;
	StartOffersDate :string;
	CreatedDate :string;
	ShowMobile :Boolean;
	ShowWeb :Boolean;
	ValidWith :string;
	ZeroOffer :Boolean;
	MerchantDescription :string;
	CategoryTitleAR :string;
	Merchants : NameObject;
	Emirates :NameObject[];
	Locations :NameObject[];
	OfferCategory :NameObject;
}