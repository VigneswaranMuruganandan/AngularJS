import { MerchantItems } from './merchantItems';
import { APIResponse } from '../../shared/model/apiResponse';

export class Merchants extends APIResponse{
    items : MerchantItems[];
}