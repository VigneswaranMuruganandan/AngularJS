import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { GlobalVariable} from '../../shared/services/global';
import { ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import { EncryptionService} from '../../shared/services/encryption.service';
import { GlobalURL} from '../../shared/services/globalURL';
import { OffersRequest } from '../model/offersRequest';
import { OffersResponse } from '../model/offersResponse';
import { Merchants } from '../model/merchants';
import { Categories } from '../model/categories';


@Injectable()
export class OffersService {

    constructor( private serviceInvoker: ServiceInvoker,
                 private encryptionService: EncryptionService) {}

    fetchOffers(offersRequest: OffersRequest) : Observable < OffersResponse >{
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.OFFERS.SEARCHOFFERS, offersRequest)
                                  .map(resp => JSON.parse(resp));
    }

    fetchMerchants() : Observable < Merchants >{
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.OFFERS.MERHCHANTS, null)
                                  .map(resp => JSON.parse(resp));
    }

    fetchCategories() : Observable < Categories >{
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.OFFERS.CATEGORIES, null)
                                  .map(resp => JSON.parse(resp));
    }
}

  



