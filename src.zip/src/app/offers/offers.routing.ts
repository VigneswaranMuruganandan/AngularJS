import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OffersComponent } from './Components/offers.component';
import { AuthGuard } from '../auth-guard.service';

const routes: Routes = [
    {
        path: '',
        component: OffersComponent,
        canActivate: [AuthGuard]
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
