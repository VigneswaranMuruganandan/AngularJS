import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './services.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { ServicesService} from './services/services.service';
import { FormsModule } from '@angular/forms';

import { ChequeBookRequestComponent } from './Components/chequeBookRequest.component';
import { ChequeBookRequestFormComponent }   from './Components/chequeBookRequestForm.component';
import { ChequeBookRequestReviewComponent }   from './Components/chequeBookRequestReview.component';
import { ChequeBookRequestOtpComponent }   from './Components/chequeBookRequestOtp.component';
import { ChequeBookRequestSuccessComponent }   from './Components/chequeBookRequestSuccess.component';



import { baseOpenTermDepositComponent } from './Components/baseOpenTermDeposit.component';
import { OpenTermDepositStep1Component } from './Components/openTermDepositStep1.component';
import { OpenTermDepositStep2Component } from './Components/openTermDepositStep2.component';
import { OpenTermDepositStep3Component } from './Components/openTermDepositStep3.component';

import {
  ValidateChequeBookRequestDirective,
  ValidateTermDpositDirective
} from './directives/validateServices.directive'


const SERVICES_COMPONENTS = [
    ChequeBookRequestComponent,
    ChequeBookRequestFormComponent,
    ChequeBookRequestReviewComponent,
    ChequeBookRequestOtpComponent,
    ChequeBookRequestSuccessComponent,
    baseOpenTermDepositComponent,
    OpenTermDepositStep1Component,
    OpenTermDepositStep2Component,
    OpenTermDepositStep3Component    
];

const SERVICES_DIRECTIVES = [
    ValidateChequeBookRequestDirective,
    ValidateTermDpositDirective
];

const SERVICES_PROVIDERS = [
   SharedService,
   TemplateService,
   ServicesService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      	CommonModule
	],
  	declarations: [
	    ...SERVICES_COMPONENTS,
      ...SERVICES_DIRECTIVES
	],
  	providers: [
  		...SERVICES_PROVIDERS
  	]
})
export class ServicesModule {}
