import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChequeBookRequestComponent } from './Components/chequeBookRequest.component';
import { baseOpenTermDepositComponent } from './Components/baseOpenTermDeposit.component';

const routes: Routes = [
	{
        path: 'chequeBookRequest',
        component: ChequeBookRequestComponent
    },
    {
        path: 'openTermDeposit',
        component: baseOpenTermDepositComponent
    },
    {
	    path: '',
	    redirectTo: '/chequeBookRequest',
	    pathMatch: 'full'
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);