import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { ChequeBookRequest } from '../model/chequeBookRequest';
import { ChequeBookAccountsResponse } from '../model/chequeBookAccountsResponse';
import { ChequeBookChargeResponse } from '../model/chequeBookChargeResponse';
import { RequestChequeBookResponse } from '../model/requestChequeBookResponse';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product,
    GlobalVariable
} from '../../shared';

@Component({
  selector: 'chequeBookRequestSucess-component',
  templateUrl: './../templates/chequeBookRequestSuccess.html'
})
export class ChequeBookRequestSuccessComponent implements OnInit {
	@Input() chequeBookRequest: ChequeBookRequest;
	@Input() chequeBookAccounts: ChequeBookAccountsResponse;
  @Input() chequeBookcharges: ChequeBookChargeResponse;
	@Input() requestChequeBookResponse :RequestChequeBookResponse;
	product :Product;
	public serverError :ServerError;
	
	constructor( private errorService: ErrorService,
				 public templateService: TemplateService,
				 public translate: TranslateService){}

	ngOnInit() {
		this.generateError();
		this.product = this.chequeBookAccounts.fundingSources[this.templateService.getSelectIndex(this.chequeBookAccounts.fundingSources,'prodRef',this.chequeBookRequest.accountIdentifier)];
	}

	generateError(){
      this.serverError = new ServerError();
      this.serverError.backButton = {"text":"Back to Cheque Book Request","router":GlobalVariable.ROUTE_MAPPING.CHEQUE_BOOK_REQUEST};
      this.translate.get('SERVERERROR.CHEQUEBOOKREQUEST')
      .subscribe((value: string) => {
          this.serverError.errorDescription = value;
      });
    }
}