import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    GlobalVariable
} from '../../shared';

@Component({
    selector: 'openTermDepositStep3-component',
    templateUrl: './../templates/openTermDepositStep3.html'
})
export class OpenTermDepositStep3Component implements OnInit {
    @Output() initEvent = new EventEmitter();
    
    constructor( private templateService: TemplateService, 
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

    ngOnInit() {        
        
    }

    reload(){
        this.initEvent.emit();
    }
}