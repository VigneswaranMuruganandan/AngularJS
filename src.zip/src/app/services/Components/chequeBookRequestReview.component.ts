import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { OTPComponent } from '../../shared/Components/otp.component';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { Subscription } from 'rxjs/Subscription';
import { ChequeBookChargeResponse } from '../model/chequeBookChargeResponse';
import { ChequeBookRequest } from '../model/chequeBookRequest';
import { Product } from '../../shared/model/product';
import { TemplateService } from '../../shared/services/template.service';
import { ChequeBookAccountsResponse } from '../model/chequeBookAccountsResponse';

@Component({
  selector: 'chequeBookRequestReview-component',
  templateUrl: './../templates/chequeBookRequestReview.html'
})
export class ChequeBookRequestReviewComponent implements OnInit {
	@Output() reviewChequeBookReqEvent = new EventEmitter();
	@Output() backChequeBookReqEvent = new EventEmitter();
	@Input() chequeBookcharges: ChequeBookChargeResponse;
	@Input() chequeBookRequest: ChequeBookRequest;
	@Input() chequeBookAccounts: ChequeBookAccountsResponse;
	product :Product;

	constructor( private errorService: ErrorService,
				 private sharedService: SharedService,
				 public templateService: TemplateService){}

	ngOnInit() {
		this.product = this.chequeBookAccounts.fundingSources[this.templateService.getSelectIndex(this.chequeBookAccounts.fundingSources,'prodRef',this.chequeBookRequest.accountIdentifier)];
	}

	confirm(){
		this.reviewChequeBookReqEvent.emit();
	}

	back(){
		this.backChequeBookReqEvent.emit(1);
	}
}