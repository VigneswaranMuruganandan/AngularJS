import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';
import 'app/assets/js/jquery.validate.js';

@Directive({
    selector: '[validateChequeBookRequestDirective]',
})
export class ValidateChequeBookRequestDirective {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let chequeBookRequestValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var chequeBookRequestValidation = (<any>$("#chequeBookRequestForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    accountNumber: {
                        required: true
                    },
                    noOfChequeBooks: {
                        required: true
                    }
                },
                messages: {
                    accountNumber: {
                        required: "Please make a selection"
                    },
                    noOfChequeBooks: {
                        required: "Please make a selection"
                    }
                }
            });
            chequeBookRequestValidationSubmit = chequeBookRequestValidation.form();
            this.templateService.setFormValidatorFlag(chequeBookRequestValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateTermDeposit]',
})
export class ValidateTermDpositDirective {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let termDepositValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var termDepositValidation = (<any>$("#termDepositForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    sourceAccount: {
                        required: true
                    },
                    principalRedeemAccount: {
                        required: true
                    },
                    interestRedeemAccount: {
                        required: true
                    },
                    depositAmount: {
                        required: true
                    },
                    tenure: {
                        required: true
                    },
                    renewOnMaturity: {
                        required: true
                    },
                    renewWithInterest: {
                        required: true
                    }
                },
                messages: {
                    sourceAccount: {
                        required: "Please make a selection"
                    },
                    principalRedeemAccount: {
                        required: "Please make a selection"
                    },
                    interestRedeemAccount: {
                        required: "Please make a selection"
                    },
                    depositAmount: {
                        required: "Please fill in"
                    },
                    tenure: {
                        required: "Please make a selection"
                    },
                    renewOnMaturity: {
                        required: "Please make a selection"
                    },
                    renewWithInterest: {
                        required: "Please make a selection"
                    }
                }
            });
            termDepositValidationSubmit = termDepositValidation.form();
            this.templateService.setFormValidatorFlag(termDepositValidationSubmit);
        });
    }
}