export class DepositRateRequest {
	currency :string;
}