
import { APIResponse } from '../../shared/model/apiResponse';
import { Product } from '../../shared/model/product';

export class ChequeBookAccountsResponse extends APIResponse {
	fundingSources :Product[];
	notes: string[];
	txnRef :string;
	chequeBkList :string[];
}