export class DepositRate{
	currency :string;
    term :string;
    rate :string;
    duration :string;
}