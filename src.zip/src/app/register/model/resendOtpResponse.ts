import {APIResponse} from '../../shared/model/apiResponse';
export class ResendOtpResponse extends APIResponse{
	
	remainingOtpAttempts:number;
}