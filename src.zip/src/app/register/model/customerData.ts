export class CustomerData{
	customerID : string;
	mobileNumber : string;
	emailID : string;
	name: string;
	userName: string;
	pwd: string;
	otpDuration: number;
}