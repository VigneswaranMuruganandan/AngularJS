
import {APIResponse} from '../../shared/model/apiResponse';

export class VerifyCustomerResponse extends APIResponse{
	otpDuration:number;
	convID:string;
	cif:string;
	emailMasked:string;
	mobileNumberMasked:string;
	remainingOtpAttempts:number;
}

