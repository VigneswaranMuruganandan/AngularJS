import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegisterComponent } from './Components/register.component';
import { RegistrationStep1Component }   from './Components/registrationStep1.Component';
import { RegistrationStep2Component }   from './Components/registrationStep2.Component';


const routes: Routes = [
	{
        path: '',
        component: RegisterComponent
    },
    {
	    path: '',
	    redirectTo: '',
	    pathMatch: 'full'
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);