import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {CustomerData} from '../model/customerData';
import {TemplateService} from '../../shared/services/template.service';
import 'app/assets/js/jquery.validate.js';
/*
* Customer Identification validation for Registration
*/
@Directive({
    selector: '[ValidateRegisterDirective]',
})
export class ValidateCustomerIdentificationRegister {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let registrationCusIDValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var registrationCusIDValidation = (<any>$("#registrationCusIDForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    customerIdentificationNo: {
                        required: true
                    }
                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    }
                }
            });
            registrationCusIDValidationSubmit = registrationCusIDValidation.form();
            this.templateService.setFormValidatorFlag(registrationCusIDValidationSubmit);
        });
    }
}

/*
* Username validation for Registration
*/
@Directive({
    selector: '[ValidateUsernameRegDirective]',
})
export class ValidateUsernameRegister {
    @Output() usernameValidationsEvent = new EventEmitter();
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {

    }
    @HostListener('keyup', ['$event'])
    onKeyUp(event: KeyboardEvent) { 
        let e = <KeyboardEvent> event;
        let registrationUsernameSubmit;
        this.zone.runOutsideAngular(() => {

            (<any>$).validator.addMethod("usernameLength", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regx6to16 = new RegExp("^.{6,16}$"),
                    flag = regx6to16.test(value);
                    if(flag){
                        $('.validate li:eq(0)').addClass('success');
                        $('.validate li:eq(0)').removeClass('error');
                    }else{
                        $('.validate li:eq(0)').addClass('error');
                        $('.validate li:eq(0)').removeClass('success');                        
                    }
                }
                return flag;
            });
            (<any>$).validator.addMethod("atleast1Alphabetic", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regx1alphabetic = new RegExp("(.*[a-zA-Z]){1}"),
                    flag = regx1alphabetic.test(value);
                    if(flag){
                        $('.validate li:eq(1)').addClass('success');
                        $('.validate li:eq(1)').removeClass('error');
                    }else{
                        $('.validate li:eq(1)').addClass('error');
                        $('.validate li:eq(1)').removeClass('success');                        
                    }
                }
                return flag;
            });
            (<any>$).validator.addMethod("validateSpecialCharacters", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regxSpecialCharacters = new RegExp("^[^!#%^&\\<>\/]+$"),
                    flag = regxSpecialCharacters.test(value);
                    if(flag){
                        $('.validate li:eq(2)').addClass('success');
                        $('.validate li:eq(2)').removeClass('error');
                    }else{
                        $('.validate li:eq(2)').addClass('error');
                        $('.validate li:eq(2)').removeClass('success');                        
                    }
                }
                return flag;
            });
            var registrationUsernameValidation = (<any>$("#usernameRegisterForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    username: {
                        required: function(){
                            $('.validate li:eq(0)').removeAttr('class');
                            $('.validate li:eq(1)').removeAttr('class');
                            $('.validate li:eq(2)').removeAttr('class');
                            return true;
                        },
                        usernameLength: true,
                        atleast1Alphabetic: true,
                        validateSpecialCharacters: true
                    }
                },
                messages: {
                    username: {
                        required: "Please fill",
                        usernameLength: "",
                        atleast1Alphabetic: "",
                        validateSpecialCharacters: ""
                    }
                }
            });
            registrationUsernameSubmit = registrationUsernameValidation.form();            
            this.usernameValidationsEvent.emit(registrationUsernameSubmit);
        });
    }
}

/*
* Password validation for Registration
*/
@Directive({
    selector: '[ValidatePasswordRegDirective]',
})
export class ValidatePasswordRegister {
    @Output() passwordValidationsEvent = new EventEmitter();
    @Input() customerData: CustomerData;

    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {

    }
    @HostListener('keyup', ['$event'])
    onKeyUp(event: KeyboardEvent) { 
        let e = <KeyboardEvent> event;
        let registrationPasswordSubmit;
        this.zone.runOutsideAngular(() => {

        	(<any>$).validator.addMethod("matchUsername", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    flag = (value != param.userName) ? true : false;
                }
                return flag;
            });
            (<any>$).validator.addMethod("passwordLength", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regx6to16 = new RegExp("^.{8,15}$"),
                    flag = regx6to16.test(value);
                    if(flag){
                        $('.validate.password li:eq(0)').addClass('success');
                        $('.validate.password li:eq(0)').removeClass('error');
                    }else{
                        $('.validate.password li:eq(0)').addClass('error');
                        $('.validate.password li:eq(0)').removeClass('success');                        
                    }
                }
                return flag;
            });
            (<any>$).validator.addMethod("atleast3Numeric", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regx3numeric = new RegExp("[0-9]{3,}"),
                    flag = regx3numeric.test(value);
                    if(flag){
                        $('.validate.password li:eq(1)').addClass('success');
                        $('.validate.password li:eq(1)').removeClass('error');
                    }else{
                        $('.validate.password li:eq(1)').addClass('error');
                        $('.validate.password li:eq(1)').removeClass('success');                        
                    }
                }
                return flag;
            });
            (<any>$).validator.addMethod("validateSpecialCharacters", 
            function (value :any, element :any, param :any) {
                var flag = true;
                if(value != null){
                    var regxSpecialCharacters = /[ !#%^&\\<>\/]/,
                    flag = regxSpecialCharacters.test(value);
                    if(flag){
                        $('.validate.password li:eq(2)').addClass('error');
                        $('.validate.password li:eq(2)').removeClass('success');
                    }else{
                        $('.validate.password li:eq(2)').addClass('success');
                        $('.validate.password li:eq(2)').removeClass('error');                        
                    }
                }
                return !flag;
            });
            var registrationPasswordValidation = (<any>$("#passwordRegisterForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    password: {
                        required: function(){
                            $('.validate.password li:eq(0)').removeAttr('class');
                            $('.validate.password li:eq(1)').removeAttr('class');
                            $('.validate.password li:eq(2)').removeAttr('class');
                            return true;
                        },
                        matchUsername: this.customerData,
                        passwordLength: true,
                        atleast3Numeric: true,
                        validateSpecialCharacters: true
                    }
                },
                messages: {
                    password: {
                        required: "Please fill",
                        matchUsername: "Password should not match with username",
                        passwordLength: "",
                        atleast3Numeric: "",
                        validateSpecialCharacters: ""
                    }
                }
            });
            registrationPasswordSubmit = registrationPasswordValidation.form();            
            this.passwordValidationsEvent.emit(registrationPasswordSubmit);
            this.templateService.setFormValidatorFlag(registrationPasswordSubmit);
        });
    }
}

/*
* ConfirmPassword validation for Registration
*/
@Directive({
    selector: '[ValidateConfirmPasswordDirective]',
})
export class ValidateConfirmPasswordRegister {
    @Input() passwordData: any;
    
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}

    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let registrationConfirmPasswordValidationSubmit;
        this.zone.runOutsideAngular(() => {


            (<any>$).validator.addMethod("comparePassword", 
            function (value :any, element :any, param :any) {
                var flag = false;
                (param.password == param.confirmPassword) ? (flag = true) : (flag = false);                   
                return flag;
            });


            var registrationConfirmPasswordValidation = (<any>$("#confirmPasswordForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    confirmPassword: {
                        required: true,
                        comparePassword: this.passwordData
                    }
                },
                messages: {
                    confirmPassword: {
                        required: "Please Confirm the Password once again",
                        comparePassword: "Please enter the same password"
                    }
                }
            });
            registrationConfirmPasswordValidation.settings.rules.confirmPassword.comparePassword = this.passwordData;
            registrationConfirmPasswordValidationSubmit = registrationConfirmPasswordValidation.form();
            this.templateService.setFormValidatorFlag(registrationConfirmPasswordValidationSubmit);
        });
    }
}


@Directive({
    selector: '[ValidateCustIDDirective]',
})
export class ValidateCustID {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
        $('#verifyCustomerIdentification').prop('disabled', 'disabled');
    }

    @HostListener('keyup', ['$event'])
    onKeyUp(event: KeyboardEvent) { 
        let e = <KeyboardEvent> event;
        let cusIDKeypressSubmit;
        this.zone.runOutsideAngular(() => {
            (<any>$).validator.addMethod("customerIdentificationLength", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regx7to16 = new RegExp("^.{7,16}$"),
                    flag = regx7to16.test(value);
                    if(flag){
                        $('#verifyCustomerIdentification').prop('disabled', false);  
                    }else{
                        $('#verifyCustomerIdentification').prop('disabled', 'disabled');
                    }
                }
                return flag;
            });
            var cusIDKeypressValidation = (<any>$("#registrationCusIDForm")).validate({
                highlight: function(element:any) {
                    return false;
                },
                unhighlight: function(element:any, errorClass:any) {
                    return false;
                },
                errorPlacement: function(error:any, element:any) {
                    return false;
                },
                rules: {
                    customerIdentificationNo: {
                        required: function(){
                            return true;
                        },
                        customerIdentificationLength: true
                    }
                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please fill",
                        customerIdentificationLength: ""
                    }
                }
            });
            cusIDKeypressSubmit = cusIDKeypressValidation.form();            
        });
    }
}