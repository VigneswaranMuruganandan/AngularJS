import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {CustomerData} from '../model/customerData';
import { GlobalVariable} from '../../shared/services/global';

@Component({
  selector: 'registrationstep5-component',
  templateUrl: './../templates/registrationStep5.html'
})
export class RegistrationStep5Component implements OnInit {
	@Output() saveRegistrationEvent = new EventEmitter();
	@Input() customerData: CustomerData;

	ngOnInit() {}
    
	validateAuthenticationType(){
		this.saveRegistrationEvent.emit();
	}
}