import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { CustomerData} from '../model/customerData';
import { OTPComponent } from '../../shared/Components/otp.component';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'registrationstep2-component',
  templateUrl: './../templates/registrationStep2.html'
})
export class RegistrationStep2Component{
	@Output() validateRegistrationOTPEvent = new EventEmitter();
	@Output() registrationBackEvent = new EventEmitter();
	@ViewChild(OTPComponent) otpComponent:OTPComponent;
	@Input() customerData: CustomerData;
	

	constructor( private errorService: ErrorService,
				 private sharedService: SharedService){}

	validateOTP(otp : string){
		this.errorService.resetErrorResp();
		this.validateRegistrationOTPEvent.emit(otp);
	}

	resetForm(code :string){
		this.otpComponent.resetOTPForm(code);		
	}

	back(){
		this.registrationBackEvent.emit(1);
	}
}