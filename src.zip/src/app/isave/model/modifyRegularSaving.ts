export class ModifyRegularSaving {
   siRefNumber :string;
   isaveAccountIdentifier :string;
   frequency :string;
   transactionAmount :string;
   startDate :string;
   endDate :string;
}