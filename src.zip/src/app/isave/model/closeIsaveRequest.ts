export class CloseIsaveRequest {
	iSaveAccountNumber :string;
	reasonToClose :string;
	transferAccounNumber :string;
	nickName :string;
	accountPurpose :string;
	endDate :string;

	constructor() { 
 		this.transferAccounNumber = '';
	}
}