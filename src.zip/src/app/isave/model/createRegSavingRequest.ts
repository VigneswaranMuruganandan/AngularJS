export class CreateRegSavingRequest {
	sourceAccount :string;
	sourceAccountNickName :string;
	savingsAmount :number;
	isaveAccountNo :string;
	iSaveAccountNickName :string;
	frequency :string;
	startDate :string;
	endDate :string;
}