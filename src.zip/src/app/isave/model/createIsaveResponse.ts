import { APIResponse } from '../../shared/model/apiResponse';

export class CreateIsaveResponse extends APIResponse {
   transactionRefNo :string;
   isaveAccountIdentifier :string;
}