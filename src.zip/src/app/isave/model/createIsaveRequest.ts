export class CreateIsaveRequest {
	sourceAccount :string;
	sourceAccountCurrency :string;
	nickName :string;
	withInterest : boolean;
	openingBalance :number;
	accountPurpose :string;
	accountingUnitIdentifier :string;
	currency :string;
	isaveAcctNumber :string;

	constructor() { 
 		this.sourceAccount = '';
 		this.accountPurpose = '';
 		this.withInterest = true;
	}
}