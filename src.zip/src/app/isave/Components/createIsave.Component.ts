import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { CreateIsaveRequest } from '../model/createIsaveRequest';
import { TemplateService } from '../../shared/services/template.service';

@Component({
  selector: 'createIsave-component',
  templateUrl: './../templates/createIsave.html'
})
export class CreateIsaveComponent implements OnInit{
	@Output() createIsaveAccountEvent = new EventEmitter();
	@Input() setupIsaveResponse :SetupIsaveResponse;
	@Input() createIsaveRequest :CreateIsaveRequest;
	public temp :any;

	constructor( private errorService: ErrorService,
				 public templateService: TemplateService,
				 private sharedService: SharedService){}

	ngOnInit() {
		this.temp = { "termsAndCond":false, "others":"" }
	}
	
	accountSelection(){
		if(this.createIsaveRequest.sourceAccount){
			this.createIsaveRequest.currency = this.setupIsaveResponse.fundingSources[this.templateService.getSelectIndex(this.setupIsaveResponse.fundingSources,'prodRef',this.createIsaveRequest.sourceAccount)].balance.currency;
			this.createIsaveRequest.sourceAccountCurrency = this.setupIsaveResponse.fundingSources[this.templateService.getSelectIndex(this.setupIsaveResponse.fundingSources,'prodRef',this.createIsaveRequest.sourceAccount)].balance.currency;
		}
	}
	createiSave(valid: boolean){
		if(valid){
			this.templateService.resetFormValidatorFlag();
			if(this.createIsaveRequest.accountPurpose =='Other'){
				this.createIsaveRequest.accountPurpose = this.temp.others;
			}
			this.createIsaveAccountEvent.emit();
		}
	}
}