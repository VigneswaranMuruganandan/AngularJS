import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { IsaveService } from '../services/isave.service';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { SessionContext } from '../../shared/model/sessionContext';
import { Router } from '@angular/router';


@Component({
    templateUrl: './../templates/isaveWelcome.html'
})
export class IsaveWelcomeComponent implements OnInit {

    constructor( private isaveService: IsaveService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
    			 private router: Router) {}

    ngOnInit() {
        //test
    }
}