import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { IsaveService } from '../services/isave.service';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { CreateIsaveRequest } from '../model/createIsaveRequest';
import { CreateIsaveResponse } from '../model/createIsaveResponse';

@Component({
  templateUrl: './../templates/baseCreateIsave.html'
})
export class BaseCreateIsaveComponent implements OnInit {
	public stepValue: number;
    public setupIsaveResponse :any;
    public createIsaveRequest :CreateIsaveRequest;
    public createIsaveResponse :CreateIsaveResponse;
    public accountPurposeOther :string;
	
	constructor( private errorService: ErrorService,
                 public isaveService: IsaveService,
                 private spinnerService: SpinnerService,
				 private sharedService: SharedService){}

	ngOnInit() {
        this.initIsave();
    }

    initIsave(){
        this.errorService.resetErrorResp();
        this.stepValue = 1;
        this.createIsaveRequest = new CreateIsaveRequest();
        this.spinnerService.startSpinner('createIsave');
        this.isaveService.setupIsave()
            .subscribe(
                resp => this.handleSetupIsave(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleSetupIsave(resp :SetupIsaveResponse){
        this.spinnerService.stopSpinner('createIsave');
        if(resp.result.status == 'success'){
            this.setupIsaveResponse = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    createIsaveAccount(desc :string){
        if(desc){
            this.accountPurposeOther = desc;
        }
    	this.stepValue = 2;
    }

    submitIsaveAccount(){
        this.spinnerService.startSpinner('createIsave');
        this.isaveService.createIsave(this.createIsaveRequest)
            .subscribe(
                resp => this.handleCreateIsave(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleCreateIsave(resp :CreateIsaveResponse){
        this.spinnerService.stopSpinner('createIsave');
        if(resp.result.status == 'success'){
            this.createIsaveResponse = resp;
            this.stepValue = 3;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    backIsaveAccount(value: number){
        this.stepValue = value;
    }
}