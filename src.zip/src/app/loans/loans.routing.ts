import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoansComponent } from './Components/loans.component';
import { LoanDeferralComponent } from './Components/loanDeferral.component';


const routes: Routes = [
    {
        path: '',
        component: LoansComponent
    },
    {
        path: 'loanDeferral',
        component: LoanDeferralComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
