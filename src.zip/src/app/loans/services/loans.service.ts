import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {SessionContext} from '../../shared/model/sessionContext';
import {AppSession} from '../../shared/model/appSession';
import {GlobalURL} from '../../shared/services/globalURL';
import {ErrorService} from '../../shared/services/error.service';
import {SharedService} from '../../shared/services/shared.service';
import { LoansResponse } from '../model/loansResponse';
import { SetupLoanDeferralResponse } from '../model/setupLoanDeferralResponse';
import { LoanDeferralRequest } from '../model/loanDeferralRequest';

@Injectable()
export class LoansService {
    
    constructor(private serviceInvoker: ServiceInvoker, 
                private errorService: ErrorService,
                private sharedService: SharedService) {}

    fetchLoanDetails(data: any): Observable < any > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOANS.FETCH_LOAN_DETAILS, data)
                                  .map(resp => JSON.parse(resp));
    }

    fetchLoanList(): Observable < LoansResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOANS.FETCH_LOANS_LISTS, null)
                                  .map(resp => JSON.parse(resp));
    }

    setupLoanDeferral(): Observable < SetupLoanDeferralResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOANS.SETUP_LOAN_DEFERRAL, null)
                                  .map(resp => JSON.parse(resp));
    }

    saveLoanDeferral(loanDeferralRequest :LoanDeferralRequest): Observable < any > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOANS.SAVE_LOAN_DEFERRAL, loanDeferralRequest)
                                  .map(resp => JSON.parse(resp));
    }
   
}
