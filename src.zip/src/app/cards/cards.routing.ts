import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CardsComponent } from './Components/cards.component';
import { CreditCardPinResetComponent }   from './Components/creditCardPinReset.component';
import { ActivateDebitCardComponent }   from './Components/activateDebitCard.component';
import { DebitCardsMainComponent }   from './Components/debitCardsMain.component';
import { ResetPinDebitCardComponent }   from './Components/resetPinDebitCard.component';



const routes: Routes = [
    {
        path: '',
        component: DebitCardsMainComponent
    },
    {
        path: 'creditCardPinReset',
        component: CreditCardPinResetComponent
    },
    {
        path: 'resetPinDebitCard',
        component: ResetPinDebitCardComponent
    },
    {
        path: 'activateDebitCard',
        component: ActivateDebitCardComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
