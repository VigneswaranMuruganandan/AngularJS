
export class DebitCardDetail {

	maskedCardNumber:string;
	cardNumber:string;
	expiryDate:string;
	status:string;
	accountNumber:string;
	embosingName:string;
	accountType:string;
	cardIssuer:string;
	cardType:string;
	statusCode:string;

}

