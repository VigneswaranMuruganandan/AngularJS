export class ReplaceCardRequest {
    accountNumber:string;
    embossingName:string;
    reasonForReissuance:string;
    authKey:string;
    txnRef:string;
}

