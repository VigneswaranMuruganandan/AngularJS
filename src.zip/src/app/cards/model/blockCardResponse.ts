import {APIResponse} from '../../shared/model/apiResponse';

export class BlockCardResponse extends APIResponse {
   txnRef:string;
}

