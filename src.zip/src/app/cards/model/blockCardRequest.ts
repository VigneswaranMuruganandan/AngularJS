export class BlockCardRequest {
    cardNumber:string;
    blockCode:string;
    cardType:string;
}

