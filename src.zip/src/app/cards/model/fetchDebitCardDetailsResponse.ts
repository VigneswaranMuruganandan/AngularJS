
import {APIResponse} from '../../shared/model/apiResponse';
import { DebitCardDetail } from './debitCardDetail';

export class FetchDebitCardDetailsResponse  extends APIResponse{

  	debitCardDetails:DebitCardDetail[];
}

