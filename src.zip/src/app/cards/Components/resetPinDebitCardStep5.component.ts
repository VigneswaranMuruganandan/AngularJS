import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { APIResponse } from '../../shared/model/apiResponse';
import { GlobalVariable} from '../../shared/services/global';
import { Router } from '@angular/router';

@Component({
  selector: 'resetPinDebitCardStep5-component',
  templateUrl: './../templates/resetPinDebitCardStep5.html'
})
export class ResetPinDebitCardStep5Component{
	
	@Input() resetPinDebitCardResponse:APIResponse;

	  constructor( private router: Router) {}	

	redirectToContactUs(){
		this.router.navigate([GlobalVariable.ROUTE_MAPPING.CONTACT_US]);
	}
}