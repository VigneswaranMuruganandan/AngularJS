import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {DebitCardDetail} from '../model/debitCardDetail';

@Component({
  selector: '[debitcardrightcontent-component]',
  templateUrl: './../templates/debitCardsRightContent.html'
})
export class DebitCardsRightContentComponent{
	
	@Input() carouselDebitCardList:DebitCardDetail[];
	@Output() carouselDebitCardEvent = new EventEmitter();

	carouselDebitCard(card:DebitCardDetail){
	  	this.carouselDebitCardEvent.emit(card);
	  }
	
	
}