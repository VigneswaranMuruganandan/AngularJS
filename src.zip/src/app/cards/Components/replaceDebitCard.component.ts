import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { DebitCardDetail} from '../model/debitCardDetail';
import { ReplaceCardRequest} from '../model/replaceCardRequest';
import { AppSession} from '../../shared/model/appSession';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { CardsService } from '../services/cards.service';
import { GlobalVariable} from '../../shared/services/global';

@Component({
  templateUrl: './../templates/replaceDebitCard.html',
  selector:'replaceDebitCard-component'
})
export class ReplaceDebitCardComponent implements OnInit{

    public replaceCardRequest:ReplaceCardRequest;
    public stepValue:number;
    public sendOtpRequest:SendOtpRequest;
    public sendOtpResponse:SendOtpResponse;
    @Input() debitCard:DebitCardDetail;
    @Input() reasonForReissuance:string;
    @Input() txnRef:string;
    
    ngOnInit() { 
        this.stepValue = 1;
        this.replaceCardRequest = new ReplaceCardRequest();
        this.replaceCardRequest.accountNumber = this.debitCard.accountNumber;
        this.replaceCardRequest.reasonForReissuance =this.reasonForReissuance;
        this.errorService.resetErrorResp();
    }

    constructor( private sharedService: SharedService,
                 private errorService: ErrorService,
                 private spinnerService: SpinnerService,
                 public cardsService: CardsService){}

    validateReplaceCardProceed(){
        this.sendOtpRequest = new SendOtpRequest();
        this.spinnerService.startSpinner('replaceCardstep1');
        this.sendOtpRequest.txnCode = GlobalVariable.TRANSACTION_CODES.DEBIT_CARD_REPLACEMENT;
        this.sendOtpRequest.txnRef = this.txnRef; 
        this.sharedService.sendOTP(this.sendOtpRequest)
            .subscribe(
                resp => this.handleSendOtpResp(resp),
                error => this.sharedService.handleError(error)
            );       
    }

    handleSendOtpResp(resp :SendOtpResponse){ 
        this.spinnerService.stopSpinner('replaceCardstep1');       
        if(resp.result.status == 'success'){
            this.sendOtpResponse = new SendOtpResponse();
            this.sendOtpResponse = resp;
            this.stepValue = 2;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }


    validateOTP(otp: string){
        if(otp){
            this.spinnerService.startSpinner('replaceCardstep2'); 
            this.replaceCardRequest.authKey = otp;
            this.replaceCardRequest.txnRef = this.txnRef;
            this.cardsService.replaceDebitCard(this.replaceCardRequest)
            .subscribe(
                resp => this.handleReplaceDebitCardResp(resp),
                error => this.sharedService.handleError(error)
            );
        }                
    }


    handleReplaceDebitCardResp(resp :any){
        this.spinnerService.stopSpinner('replaceCardstep2'); 
        if(resp.result.status == 'success'){
            this.stepValue = 3;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
    
}