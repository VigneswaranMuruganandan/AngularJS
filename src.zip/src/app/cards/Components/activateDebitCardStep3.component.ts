import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'activateDebitCardStep3-component',
  templateUrl: './../templates/activateDebitCardStep3.html'
})
export class ActivateDebitCardStep3Component {
	
	@Output() validateConfirmPinDebitCardEvent = new EventEmitter();
	@Output() backToStepTwoEvent = new EventEmitter();

	validateConfirmPin(confirmPin:string){
		this.validateConfirmPinDebitCardEvent.emit(confirmPin);
	}

	backToStepTwo(){
		this.backToStepTwoEvent.emit();
	}
}