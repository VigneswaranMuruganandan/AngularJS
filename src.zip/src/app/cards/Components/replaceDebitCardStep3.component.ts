import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { CardsService } from '../services/cards.service';

@Component({
  templateUrl: './../templates/replaceDebitCardStep3.html',
  selector:'replaceDebitCardStep3-component'
})
export class ReplaceDebitCardStep3Component implements OnInit{


	constructor( private sharedService: SharedService,
	             private errorService: ErrorService,
	             private spinnerService: SpinnerService,
	             public cardsService: CardsService){}


	ngOnInit() { 

    	
    }

   
}