import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { GlobalVariable} from '../../shared/services/global';
import { Router } from '@angular/router';

@Component({
  selector: 'resetPinDebitCardStep1-component',
  templateUrl: './../templates/resetPinDebitCardStep1.html'
})
export class ResetPinDebitCardStep1Component{
	
	@Output() validateDebitCardResetPinEvent = new EventEmitter();

	constructor( private router: Router) {}
	
	beginDebitCardResetPin(event:any){
		this.validateDebitCardResetPinEvent.emit();
	}

	chooseDifferentDebitcard(){
		this.router.navigate([GlobalVariable.ROUTE_MAPPING.DEBITCARDS]);
	}
}