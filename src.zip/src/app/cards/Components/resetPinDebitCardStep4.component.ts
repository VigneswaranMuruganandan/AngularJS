import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';

@Component({
  selector: 'resetPinDebitCardStep4-component',
  templateUrl: './../templates/resetPinDebitCardStep4.html'
})
export class ResetPinDebitCardStep4Component {

	@Output() validateOTPDebitCardResetPinEvent = new EventEmitter();
	@Output() backOTPButtonEvent = new EventEmitter();
	@Input() sendOtpRequest:SendOtpRequest;
	@Input() sendOtpResponse:SendOtpResponse;

	validateOTP(otp : string){
		this.validateOTPDebitCardResetPinEvent.emit(otp);
	}

	backOTP(){
		this.backOTPButtonEvent.emit();
	}
}