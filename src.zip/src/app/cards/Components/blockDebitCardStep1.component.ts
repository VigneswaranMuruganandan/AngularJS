import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { DebitCardDetail} from '../model/debitCardDetail';
import { BlockCardRequest} from '../model/blockCardRequest';
import { BlockCardResponse} from '../model/blockCardResponse';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { CardsService } from '../services/cards.service';
import { StaticDataResponse } from '../../shared/model/staticDataResponse';
import { StaticData } from '../../shared/model/StaticData';
import { Entity } from '../../shared/model/entity';
import {TemplateService} from '../../shared/services/template.service';

@Component({
  templateUrl: './../templates/blockDebitCardStep1.html',
  selector:'blockDebitCardStep1-component'
})
export class BlockDebitCardStep1Component implements OnInit{

	public modalStepValue:number;
	public blockReasons:StaticData[];
	@Input() reasonForReissuance:string;
	@Input() debitCard:DebitCardDetail;
	@Input() blockCardRequest:BlockCardRequest;
	@Input() blockCardResponse:BlockCardResponse;
	@Output() replaceDebitCardButtonEvent = new EventEmitter();

	constructor( private sharedService: SharedService,
	             private errorService: ErrorService,
	             private spinnerService: SpinnerService,
	             public cardsService: CardsService,
	             public templateService: TemplateService){}

	ngOnInit() { 
    	this.modalStepValue=1;
    	this.fetchBlockReasons();
    	this.errorService.resetErrorResp();
    }

    /*
    * Fetch the Block Reasons
    */
	fetchBlockReasons(){
		this.spinnerService.startSpinner('loader');
		let data = new Entity();
		data.entityName = "ALL"
		this.sharedService.fetchStaticData(data)
				.subscribe(
					resp => this.handleStaticDataResponse(resp),
					error => this.sharedService.handleError(error)
				);
	}

	/*
    * Handle Block Reasons Response
    */
	handleStaticDataResponse(resp:StaticDataResponse){
		this.spinnerService.stopSpinner('loader');
		if(resp && resp.result.status == 'success'){
            this.blockReasons = resp.staticMasterDataMap["DEBITCARD_BLOCK_REASON"]; 
        }else if(resp && resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);

        }

	}

    continueButton(valid:boolean){
    	if(valid){
	        this.errorService.resetErrorResp();
	        this.spinnerService.startSpinner('blockReqstep1');
	        let tempBlockCode = this.blockReasons.filter(reasonItem=>reasonItem.description == this.reasonForReissuance);
	        this.blockCardRequest.blockCode = tempBlockCode[0].shortCode;
	        this.cardsService.cardBlock(this.blockCardRequest)
		        .subscribe(
		            resp => this.handleCardBlockResp(resp),
		            error => this.sharedService.handleError(error)
		        );
	    }
    }
    
    handleCardBlockResp(resp:BlockCardResponse){
      this.spinnerService.stopSpinner('blockReqstep1');
      if (resp.result.status == "success") {
   		  this.blockCardResponse=resp;
          this.modalStepValue=2;
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
    }

    replaceDebitCardButton(){
    	this.replaceDebitCardButtonEvent.emit({"reason":this.reasonForReissuance,"txnRef":this.blockCardResponse.txnRef});
    }
	
}