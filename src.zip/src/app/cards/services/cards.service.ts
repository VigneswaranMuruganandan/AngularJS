import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { GlobalURL} from '../../shared/services/globalURL';
import { ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import { FetchDebitCardDetailsResponse} from '../model/fetchDebitCardDetailsResponse';
import { BlockCardRequest} from '../model/blockCardRequest';
import { BlockCardResponse} from '../model/blockCardResponse';
import { ReplaceCardRequest} from '../model/replaceCardRequest';
import { ActivatePinResetCardRequest} from '../model/activatePinResetCardRequest';
import { APIResponse } from '../../shared/model/apiResponse';

@Injectable()
export class CardsService{

  constructor(private serviceInvoker: ServiceInvoker) {}

    public debitCard:any;

    setDebitCard(debitCard:any){
      this.debitCard = debitCard;
    }

    getDebitCard(){
      return this.debitCard;
    }

    resetDebitCard(){
      this.debitCard={};
    }

  	fetchDebitCardList(): Observable <FetchDebitCardDetailsResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.CARDS.FETCH_DEBIT_CARDS,null)
                                .map(resp => JSON.parse(resp));
    }

    cardActivate(data:ActivatePinResetCardRequest): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.CARDS.ACTIVATE,data)
                                .map(resp => JSON.parse(resp));
    }

    cardPinReset(data:ActivatePinResetCardRequest): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.CARDS.PIN_RESET,data)
                                .map(resp => JSON.parse(resp));
    }

    cardBlock(data:BlockCardRequest): Observable <BlockCardResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.CARDS.BLOCK,data)
                                .map(resp => JSON.parse(resp));
    }

    replaceDebitCard(data:ReplaceCardRequest): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.CARDS.REPLACE_DEBIT_CARD,data)
                                .map(resp => JSON.parse(resp));
    }
}


