import { Component, OnInit, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule }  from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'my-app',
  template: `
    <div class="loader full" id="loader"></div>
    <router-outlet></router-outlet>
  `,
  providers: []
})
export class AppComponent {
    constructor(private translate: TranslateService) {
        translate.addLangs(["en", "ar"]);
        translate.setDefaultLang('ar');
        translate.use('en');
    }
}