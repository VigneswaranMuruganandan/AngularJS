import {APIResponse} from '../../shared/model/apiResponse';
import {AssetLiabilities} from './assetLiabilities';
import { Amount } from '../../shared/model/amount';

export class AssetProductAllocationResponse extends APIResponse{
	assets :Amount;
	liabilities :Amount;
	netPostion :Amount;
	currency :string;
	assetLiablitiesList: AssetLiabilities[];
}
