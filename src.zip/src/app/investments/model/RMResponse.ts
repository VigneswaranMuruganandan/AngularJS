import {APIResponse} from '../../shared/model/apiResponse';
import {RelationshipManager} from './relationshipManager';

export class RMResponse extends APIResponse{
	rmList: RelationshipManager[];
}
