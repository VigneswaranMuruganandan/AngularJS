import { Amount } from '../../shared/model/amount';

export class AssetLiabilities {
	productClassName :string;
	productClassCode :string;
	type :string;
	currencyCode :string;
	amount :Amount;
}
