import {APIResponse} from '../../shared/model/apiResponse';
import {ProductInfo} from './productInfo';

export class SecurityHoldingResponse extends APIResponse{
	productInfo: ProductInfo[];
}
