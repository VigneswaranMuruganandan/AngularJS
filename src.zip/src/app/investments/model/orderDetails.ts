import { Amount } from '../../shared/model/amount';

export class OrderDetails {
	orderDate :string;
	orderNumber :string;
	orderType :string;
	securityName :string;
	ccy :string;
	quantity :string;
	amount :Amount;
	userName :string;
}
