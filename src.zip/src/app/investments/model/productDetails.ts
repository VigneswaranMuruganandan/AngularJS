import { Amount } from '../../shared/model/amount';

export class ProductDetails {
	accountType :string;
	securityName :string;
	securityCode :string;
	isIn :string;
	ccy :string;
	unitHeld :string;
	unitUnderLien :string;
	leverageAmount :Amount;
	costPrice :string;
	costValue :string;
	marketPrice :string;
	marketValue :string;
	appreciation :string;
	mvinAED :string;
	percAsset :string;
}
