import {APIResponse} from '../../shared/model/apiResponse';
import {Transactions} from './transactions';

export class TransactionHistoryResponse extends APIResponse{
	transactionList: Transactions[];
}
