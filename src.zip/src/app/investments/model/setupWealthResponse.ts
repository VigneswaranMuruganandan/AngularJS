import {APIResponse} from '../../shared/model/apiResponse';
import {NameValuePair} from '../../shared/model/nameValuePair';

export class SetupWealthResponse extends APIResponse{
	planList: NameValuePair[];
}
