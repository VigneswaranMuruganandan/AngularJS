import { Amount } from '../../shared/model/amount';

export class Transactions {
	securityName :string;
	securityCode :string;
	date :string;
	transactionType :string;
	productType :string;
	isin :string;
	currency :string;
	units :string;
	priceNAV :Amount;
	accuredInterest :string;
	feesCharges :string;
	transactionAmount :Amount;
	equivalentAED :Amount;
	realisedGainLoss :string;
}
