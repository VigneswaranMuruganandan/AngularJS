export class RelationshipManager {
	rmName :string;
	rmMobileNo :string;
	rmEmailId :string;
}
