import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './investments.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { InvestmentsService } from './services/investments.service';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule } from '@angular/forms';
import { InvestmentsOnboardingComponent }   from './Components/investmentsOnboarding.component';
import { ApplyProductComponent }   from './Components/applyProduct.component';
import { ApplyProductStep1Component }   from './Components/applyProductStep1.component';
import { ApplyProductStep2Component }   from './Components/applyProductStep2.component';
import { ApplyProductStep3Component }   from './Components/applyProductStep3.component';
import { ValidateApplyProductsSelection,ValidateEmiratesSelection }   from './directives/validateInvestments.directive';
import { TransactionHistoryComponent }   from './Components/transactionHistory.component';
import { AssetsAndProductAllocationComponent }   from './Components/assetsAndProductAllocation.component';
import { HoldingSummaryComponent }   from './Components/holdingSummary.component';
import { PendingOrderStatusComponent }   from './Components/pendingOrderStatus.component';
import { GlobalMarketUpdateComponent }   from './Components/globalMarketUpdate.component';

const INVESTMENT_COMPONENTS = [
    InvestmentsOnboardingComponent,


    ApplyProductComponent,
    ApplyProductStep1Component,
    ApplyProductStep2Component,
    ApplyProductStep3Component,
    ValidateApplyProductsSelection,
    ValidateEmiratesSelection,
    TransactionHistoryComponent,
    AssetsAndProductAllocationComponent,
    HoldingSummaryComponent,
    PendingOrderStatusComponent,
    GlobalMarketUpdateComponent
];

const INVESTMENT_PROVIDERS = [
   SharedService,
   TemplateService,
   InvestmentsService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule,
      NgxDatatableModule
	],
  	declarations: [
	    ...INVESTMENT_COMPONENTS
	],
  	providers: [
  		...INVESTMENT_PROVIDERS
  	]
})
export class InvestmentsModule {}
