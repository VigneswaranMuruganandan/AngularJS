import { Component, OnInit, Input} from '@angular/core';
import { InvestmentsService } from '../services/investments.service';
import {RelationshipManager} from '../model/relationshipManager';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    AppSession,
    TranslateService,
    NameValuePair
} from '../../shared'; 
import { WealthEnquiryRequest } from '../model/wealthEnquiryRequest';
import { TransactionHistoryResponse } from '../model/transactionHistoryResponse';
import { Transactions } from '../model/transactions';
import { SetupWealthResponse  } from '../model/setupWealthResponse';

@Component({
	templateUrl: './../templates/transactionHistory.html'
})
export class TransactionHistoryComponent implements OnInit {
	public relationshipManager: RelationshipManager;
	public wealthEnquiryRequest :WealthEnquiryRequest;
	public accountList :NameValuePair[];
	public durations :any;
	public transactionList :Transactions[];
	public rows :any;
	public columns :any;
	public columnsKey :any;


	constructor( private investmentsService: InvestmentsService, 
    			 private sharedService: SharedService,
    			 private templateService: TemplateService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}


	ngOnInit(){
		this.errorService.resetErrorResp();
		this.initRMDetails();
		this.initData();
	}

	initRMDetails(){
		this.wealthEnquiryRequest = new WealthEnquiryRequest();
		this.wealthEnquiryRequest.asOnDate = this.templateService.getTodaydate('YYYYMMDD');
		this.investmentsService.fetchRMDetails(this.wealthEnquiryRequest)
        .subscribe(
            resp => {
            	if(resp.result.status == 'success'){
            		this.relationshipManager = new RelationshipManager();
            		this.relationshipManager = resp.rmList[0];
            	}else if(resp.result.status == 'error'){
            		this.errorService.setErrorResp(resp.result);
            	}
            },
            error => this.sharedService.handleError(error)
        );
	}

	initTransactionHistory(){
		this.spinnerService.startSpinner('transactionHistory');
		this.investmentsService.setupTransactionHistory()
            .subscribe(
                resp => this.handleSetupTransactionHistory(resp),
                error => this.sharedService.handleError(error)
            );
	}

	handleSetupTransactionHistory(resp :SetupWealthResponse){
		this.spinnerService.stopSpinner('transactionHistory');
		if(resp.result.status == 'success'){
            this.accountList = resp.planList;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);			
        }
	}

	generateDate(month :number){
		let d = new Date();
		d.setMonth(d.getMonth() - 3);
		let dd :any = d.getDate();
	    let mm :any = d.getMonth()+1;
	    let yyyy :any = d.getFullYear();
	    if(dd<10){
	        dd='0'+dd;
	    } 
	    if(mm<10){
	        mm='0'+mm;
	    } 
	    return yyyy+mm+dd;
	}

	fetchTransactionHistory(){
		if(this.wealthEnquiryRequest.productClassCode!='' && this.wealthEnquiryRequest.startDate!=''){
			this.wealthEnquiryRequest.endDate = this.templateService.getTodaydate('YYYYMMDD');
			this.investmentsService.fetchTransactionHistoryList(this.wealthEnquiryRequest)
            .subscribe(
                resp => this.handleTransactionHistoryList(resp),
                error => this.sharedService.handleError(error)
            );
		}
	}

	handleTransactionHistoryList(resp :TransactionHistoryResponse){
		if(resp.result.status == 'success'){
            this.transactionList = resp.transactionList;
            this.generateRows();
            this.generateColumns();
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);			
        }
	}

	generateRows(){
		this.rows = [];
		Object.getOwnPropertyNames(this.columnsKey)
		.map((key: string) => {
			let obj = {};
			obj['label'] = this.columnsKey[key];
			for(let i in this.transactionList){
				if(key == 'priceNAV' || key == 'transactionAmount' || key == 'equivalentAED')
				obj['value'+i] = this.transactionList[i][key].valueFmt;
				else
				obj['value'+i] = this.transactionList[i][key];
			}
			this.rows.push(obj);
		});
	}

	generateColumns(){
		this.columns = [];
		this.columns.push({name: 'label',frozenLeft: true});
		for(let i in this.transactionList){
			this.columns.push({name: 'value'+i});
		}
	}

	initData(){
		this.wealthEnquiryRequest = new WealthEnquiryRequest();
		this.wealthEnquiryRequest.securityCode = '';
		this.wealthEnquiryRequest.startDate = '';
		this.durations = [{code: "all",value: "All",dt: '19000101'},{code: "1M",value: "Last 1 Month",dt: this.generateDate(1)}, {code: "3M",value: "Last 3 Months",dt: this.generateDate(3)},{code: "6M",value: "Last 6 Months",dt: this.generateDate(6)}, {code: "9M", value: "Last 9 Months",dt: this.generateDate(9)}, {code: "12M",value: "Last 12 Months",dt: this.generateDate(12)}];
		this.initTransactionHistory();
		this.columnsKey = {"securityName": "Security Name", "securityCode": "Security Code", "date": "Date", "transactionType": "Transaction Type", "productType": "Product Type", "isin": "ISIN", "currency": "CCY", "units": "Units/Shared/National", "priceNAV": "Price/NAV", "accuredInterest": "Accured Interest", "feesCharges": "Fees & Charges", "transactionAmount": "Transaction Amount", "equivalentAED": "AED Equivalent", "realisedGainLoss": "Realised Gain / Loss"};
	}
}