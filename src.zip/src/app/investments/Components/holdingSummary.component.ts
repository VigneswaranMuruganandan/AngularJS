import { Component, OnInit, Input} from '@angular/core';
import { InvestmentsService } from '../services/investments.service';
import { SecurityHoldingResponse } from '../model/securityHoldingResponse';
import { ProductInfo } from '../model/productInfo';
import { WealthEnquiryRequest } from '../model/wealthEnquiryRequest';
import {RelationshipManager} from '../model/relationshipManager';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    AppSession,
    TranslateService,
    UserDetails,
    UserContext
} from '../../shared';

@Component({
	templateUrl: './../templates/holdingSummary.html'
})
export class HoldingSummaryComponent implements OnInit {
	public relationshipManager: RelationshipManager;
	public wealthEnquiryRequest :WealthEnquiryRequest;
	public productInfo :ProductInfo[];
	public cashColumns :any;
	public cashColumnsKey :any;
	public cashRows :any;
	public othersColumns :any;
	public othersColumnsKey :any;
	public othersRows :any;

	constructor( private investmentsService: InvestmentsService,
				 private templateService: TemplateService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}

	ngOnInit(){
		this.errorService.resetErrorResp();
		this.cashColumnsKey = {	"securityName": "Name on Account", "isIn": "Account Number", "accountType": "Account Type", "ccy": "Currency", "costValue": "Current Balance", "mvinAED": "AED Equivalent", "percAsset": "% of Assets" };
		this.othersColumnsKey = { "securityName": "Security Name", "securityCode": "International Security Identification Number", "ccy": "Currency", "unitHeld": "Shares Held", "unitUnderLien": "Shares Under Lien", "leverageAmount": "Leverage Amount", "marketPrice": "Market Price", "marketValue": "Market Value", "appreciation": "Appreciation %", "mvinAED": "Market Value in AED", "percAsset": "% of Assets" };
		this.initRMDetails();
		this.initHoldingSummary();
	}	

	initRMDetails(){
		this.wealthEnquiryRequest = new WealthEnquiryRequest();
		this.wealthEnquiryRequest.asOnDate = this.templateService.getTodaydate('YYYYMMDD');
		this.investmentsService.fetchRMDetails(this.wealthEnquiryRequest)
        .subscribe(
            resp => {
            	if(resp.result.status == 'success'){
            		this.relationshipManager = new RelationshipManager();
            		this.relationshipManager = resp.rmList[0];
            	}else if(resp.result.status == 'error'){
            		this.errorService.setErrorResp(resp.result);
            	}
            },
            error => this.sharedService.handleError(error)
        );
	}

	initHoldingSummary(){
		this.spinnerService.startSpinner('holdingsummary');
		this.wealthEnquiryRequest = new WealthEnquiryRequest();
		this.wealthEnquiryRequest.asOnDate = this.templateService.getTodaydate('YYYYMMDD');
		this.investmentsService.fetchSecurityHolding(this.wealthEnquiryRequest)
        .subscribe(
            resp => this.handleSecurityHolding(resp),
            error => this.sharedService.handleError(error)
        );
	}

	handleSecurityHolding(resp :SecurityHoldingResponse){
		if(resp.result.status == 'success'){
            this.productInfo = resp.productInfo;
            this.generateCashRows();
            this.generateCashColumns();
            this.generateOthersRows();
            this.generateOthersColumns();
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
        this.spinnerService.stopSpinner('holdingsummary');
	}

	generateCashRows(){
		this.cashRows = [];
		Object.getOwnPropertyNames(this.cashColumnsKey)
		.map((key: string) => {
			let obj = {};
			obj['label'] = this.cashColumnsKey[key];
			for(let i in this.productInfo[0].productDetailsList){
				if(key == 'amount')
				obj['value'+i] = this.productInfo[0].productDetailsList[i][key].valueFmt;
				else
				obj['value'+i] = this.productInfo[0].productDetailsList[i][key];
			}
			this.cashRows.push(obj);
		});
	}

	generateCashColumns(){
		this.cashColumns = [];
		this.cashColumns.push({name: 'label',frozenLeft: true});
		for(let i in this.productInfo[0].productDetailsList){
			this.cashColumns.push({name: 'value'+i});
		}
	}

	generateOthersRows(){
		this.othersRows = [];
		Object.getOwnPropertyNames(this.othersColumnsKey)
		.map((key: string) => {
			let obj = {};
			obj['label'] = this.othersColumnsKey[key];
			for(let i in this.productInfo[1].productDetailsList){
				if(key == 'leverageAmount')
				obj['value'+i] = this.productInfo[1].productDetailsList[i][key].valueFmt;
				else
				obj['value'+i] = this.productInfo[1].productDetailsList[i][key];
			}
			this.othersRows.push(obj);
		});
	}

	generateOthersColumns(){
		this.othersColumns = [];
		this.othersColumns.push({name: 'label',frozenLeft: true});
		for(let i in this.productInfo[1].productDetailsList){
			this.othersColumns.push({name: 'value'+i});
		}
	}
}