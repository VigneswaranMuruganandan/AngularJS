import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TemplateService} from '../../shared/services/template.service';
import * as $ from 'jquery';
import { StaticData } from '../../shared/model/StaticData';
import { LeadRequest } from '../model/leadRequest';

@Component({
  selector: 'applyproductstep1-component',
  templateUrl: './../templates/applyProductStep1.html'
})
export class ApplyProductStep1Component {

	constructor(public templateService: TemplateService) {}
	@Output() applyProductNextEvent = new EventEmitter();
	@Input() leadRequest :LeadRequest;
	@Input() productSelected :any[];
		
	
	/*
    * Capture Products on selection and uncheck
    */
	onChange(value:string,checked:boolean){
		this.leadRequest.products = [];
	    this.productSelected.filter((product,index) => {
	    	if(product.description == value){
	    		this.productSelected[index].status = checked;
	    	}
	    	if(product.status){
	    		this.leadRequest.products.push(product.description);
	    	}
	    });
  	}

  	/*
    * Upon Selection ,Navigate to Step 2
    */
	applyProductNext(valid:boolean){
		if(valid){
			this.templateService.resetFormValidatorFlag();
			this.applyProductNextEvent.emit();			
		}
	}
}