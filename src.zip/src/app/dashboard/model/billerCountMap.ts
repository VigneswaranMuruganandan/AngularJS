export class BillerCountMap{
	numberOfpayments :number;
	paymentOrTransferProviderName :string;
}