export class BeneficiaryCountMap{
	numberOfpayments :number;
	paymentOrTransferProviderName :string;
}