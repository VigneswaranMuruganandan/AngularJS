export class TransferTypes{
	paymentTransferName :string;
	count: number;
}