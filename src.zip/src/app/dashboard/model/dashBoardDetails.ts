import { APIResponse } from '../../shared/model/apiResponse';
import { CustomerProducts } from '../../shared/model/customerProducts';
import { UserDetails } from '../../shared/model/userDetails';

export class DashBoardDetails extends APIResponse{
    favouriteProducts : CustomerProducts;
	customerProducts : CustomerProducts;
	bulletins : string[];
	user : UserDetails;
	lastLoginDate: string;
}