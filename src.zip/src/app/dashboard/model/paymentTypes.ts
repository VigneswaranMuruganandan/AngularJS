export class PaymentTypes{
	paymentTransferName :string;
}