import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';
import { DashboardRouting } from './dashboard.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { TransfersModule } from '../transfers/transfers.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { DashboardService} from './services/dashboard.service';
import { DashboardComponent} from './Components/dashboard.component';
import { WelcomeModalComponent} from './Components/welcomeModal.component';
import { FavouritesModalComponent} from './Components/favouritesModal.component';
import { FavouritesSettingsModalComponent} from './Components/favouritesSettingsModal.component';
import { TransferModalComponent } from './Components/transferModal.component';
import { PaymentModalComponent } from './Components/paymentModal.component';


const DASHBOARD_COMPONENTS = [
	DashboardComponent,
	WelcomeModalComponent,
	FavouritesModalComponent,
	FavouritesSettingsModalComponent,
	TransferModalComponent,
	PaymentModalComponent
];

const DASHBOARD_PROVIDERS = [
   SharedService,
   TemplateService,
   DashboardService
];

@NgModule({
  	imports: [
	    DashboardRouting,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
		CommonModule,
		TransfersModule
	],
  	declarations: [
	    ...DASHBOARD_COMPONENTS
	],
  	providers: [
  		...DASHBOARD_PROVIDERS
  	]
})
export class DashboardModule {}
