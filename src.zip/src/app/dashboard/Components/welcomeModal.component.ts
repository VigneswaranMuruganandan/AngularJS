import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'welcomeModal-component',
  templateUrl: './../templates/welcomeModal.html'
})
export class WelcomeModalComponent{
	@Output() openFavouritesModalEvent = new EventEmitter();
	@Output() saveAsAllFavouritesEvent = new EventEmitter();
	
	showFavouritesModal(){
		this.openFavouritesModalEvent.emit();
	}

	skipFavourites(){
		this.saveAsAllFavouritesEvent.emit();
	}
}