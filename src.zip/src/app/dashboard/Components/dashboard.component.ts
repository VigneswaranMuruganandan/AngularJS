import { Component, Input, OnInit, AfterViewInit, ViewChild  } from '@angular/core';
import { DashboardService} from '../services/dashboard.service';
import { DashBoardDetails } from '../model/dashBoardDetails';
import { FavouritesSettingsModalComponent } from './favouritesSettingsModal.component';
import { UpdateFavoritesProduct } from '../model/updateFavoritesProduct';
import { Observable } from 'rxjs/Rx';
import { BeneficiaryCountMap } from '../model/beneficiaryCountMap';
import { BillerCountMap } from '../model/billerCountMap';
import { PaymentTypes } from '../model/paymentTypes';
import { TransferTypes } from '../model/transferTypes';
import { BeneficiariesService } from '../../beneficiaries/services/beneficiaries.service';
import { BeneListResp } from '../../beneficiaries/model/beneListResp';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product,
    GlobalVariable,
    AppSession,
    UserDetails,
    CustomerProducts,
    Loan,
    Account,
    Card
} from '../../shared';

@Component({
  templateUrl: './../templates/dashboard.html'
})
export class DashboardComponent implements OnInit {
    @ViewChild(FavouritesSettingsModalComponent) favouritesSettingsModal: FavouritesSettingsModalComponent;
    public dashBoardDetails: DashBoardDetails;
    public appSession: AppSession;
    public transferTemplateCount : BeneficiaryCountMap[];  
    public selectedTransferTemplate : BeneficiaryCountMap;  
    public paymentTemplateCount : BillerCountMap[];
    public beneListResp :BeneListResp;
    GlobalVariable: any;   


    public currentTab :string;
    public favouriteProducts :any[];
    public accounts :Account[];
    public cards :Card[];
    public deposits :Account[];
    public loans :Loan[];

    constructor( private dashboardService: DashboardService,
                 private beneficiariesService: BeneficiariesService,
                 private spinnerService: SpinnerService, 
                 private errorService: ErrorService,
                 private sharedService: SharedService,
                 public templateService: TemplateService,
                 private router: Router) {}

    ngOnInit() {
        this.currentTab = 'FAVOURITE';
        this.init();
    }

    init(){
        this.GlobalVariable = GlobalVariable;
        this.appSession = AppSession.getInstance();
        if(this.appSession.newcustomer == 'Y'){
            (<any>$('#openWelcomeModal')).click();
            this.appSession.newcustomer = 'N';
        }
        this.initDashboardDetails();
        this.initTransferBillersTemplateCount();         
        this.fetchBeneficaryList();
    }

    tabSelection(type :string){
        this.spinnerService.startSpinner('dashboardFav');
        this.currentTab = type;
        setTimeout(()=> {
          this.spinnerService.stopSpinner('dashboardFav');
        }, 300);
    }

    initTransferBillersTemplateCount(){
        this.transferTemplateCount = new Array();
        this.paymentTemplateCount = new Array();
        let transferCount = this.appSession.transferTypes,
        paymentCount = this.appSession.paymentTypes;
        //Dashboard Transfer Template count
        transferCount.map((obj,index) => {
           let filteredData = this.appSession.beneficiaryCountMap.filter(data => data.paymentOrTransferProviderName == obj.paymentTransferName);
           let data = new BeneficiaryCountMap();
           data.paymentOrTransferProviderName = obj.paymentTransferName;
           if(filteredData.length > 0)
                data.numberOfpayments = filteredData[0].numberOfpayments;
           else
                data.numberOfpayments = 0;          
           this.transferTemplateCount.push(data);
        });
        // Dashboard Payment Billers Template count
        paymentCount.map((obj,index) => {
           let filteredData = this.appSession.billerCountMap.filter(data => data.paymentOrTransferProviderName == obj.paymentTransferName);
           let data = new BillerCountMap();
           data.paymentOrTransferProviderName = obj.paymentTransferName;
           if(filteredData.length > 0)
                data.numberOfpayments = filteredData[0].numberOfpayments;
           else
                data.numberOfpayments = 0;          
           this.paymentTemplateCount.push(data);
        });      
    }
    /*
    * Init method to fetch the Dashboard Details service
    * will provide favourites, payment templates
    * Transfer Templates, offers and all products
    */
    initDashboardDetails(){
        this.spinnerService.startSpinner('dashboardFav');
        this.dashboardService.fetchDashBoardResults()
            .subscribe(
                resp => this.handleDashboardInitResp(resp),
                error => this.sharedService.handleError(error)
            );        
    }
    /*
    * Handling Dashboard Response
    */
    handleDashboardInitResp(resp: any){
        this.spinnerService.stopSpinner('dashboardFav');
        if(resp && resp.result.status == "success"){
            this.dashBoardDetails = new DashBoardDetails();
            this.dashBoardDetails = resp;
            this.generateFavouriteProducts(this.dashBoardDetails.favouriteProducts);
            this.generateCustomerProducts(this.dashBoardDetails.customerProducts);
        }
    }
    /*
    * Save the selected favourites
    */
    saveAsAllFavourites(){
        this.spinnerService.startSpinner('welcomeDashboard');
        this.dashboardService.saveAsAllFavourites()
            .subscribe(
                resp => {
                    this.spinnerService.stopSpinner('welcomeDashboard');
                    if(resp.result.status == 'success'){
                        let AppSess = AppSession.getInstance();
                        (<any>$('#welcomeDashboard-1')).modal('hide');
                        this.initDashboardDetails();
                    }
                },
                error => this.sharedService.handleError(error)
            );
    }

    unFavouriteSelectedIndex(data :any, type :string){
        this.spinnerService.startSpinner('dashboardFavShow');
        let updateFavoritesProduct = new UpdateFavoritesProduct();
        if(data && type){
            switch(type) {
                case 'ACCOUNT':
                    updateFavoritesProduct.productRef = data.number
                    break;
                case 'DEPOSIT':
                    updateFavoritesProduct.productRef = data.number
                    break;
                case 'CARD':
                    updateFavoritesProduct.productRef = data.cardNumber;
                    break;
                case 'LOAN':
                    updateFavoritesProduct.productRef = data.loanNumber;
                    break;
            }
            updateFavoritesProduct.favoriteState = false;
        }
        this.sharedService.unFavouriteProduct(updateFavoritesProduct)
        .subscribe(
            resp => {
                if(resp && resp.result.status == "success"){
                    this.initDashboardDetails();
                }
            },
            error => this.sharedService.handleError(error)
        );
    }
    /*
    * Show Favourite settings option to customer
    */    
    dashboardFavouritesSettings(){   
        this.favouritesSettingsModal.initFavouritesDetails();
        (<any>$('#addFavouriteModal')).modal('show');
    }
    /*
    * Open Favourite Poup info modal
    */
    openFavouritesModal(){
        (<any>$('#close')).click();
        (<any>$('#openfavouritesModal')).click();        
    }
    /*
    * Show Favourite settings option to customer from Favourite Poup info
    */
    openFavouritesSettingsModal(){
        (<any>$('#close')).click();
        this.favouritesSettingsModal.initFavouritesDetails();
        (<any>$('#openAddFavouritesModal')).click();
    }
    /*
    * Navigating to Account page with selected Account Number
    */
    onSelectedAccount(accountNum:string){
        this.appSession.dashboardAccount = accountNum;
        this.router.navigate(['/accounts']);
    }   

    fetchBeneficaryList(){
        this.beneficiariesService.fetchBeneTransferList()
            .subscribe(
              resp => this.handleBeneTransferResp(resp),
              error => this.sharedService.handleError(error)
            );
    }

    handleBeneTransferResp(resp:BeneListResp){
        if (resp.result.status == "success") {
            this.beneListResp = new BeneListResp();
            this.beneListResp = resp;
        }else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }
    showTransferBeneficiary(count :BeneficiaryCountMap){
        if(count){
            this.selectedTransferTemplate = count;
            if(this.selectedTransferTemplate.paymentOrTransferProviderName == "WITHIN_BANK_FUNDS_TRANSFER"||
               this.selectedTransferTemplate.paymentOrTransferProviderName == "WITHIN_UAE_FUNDS_TRANSFER" ||
               this.selectedTransferTemplate.paymentOrTransferProviderName == "OWN_ACCT_FUNDS_TRANSFER"){
                (<any>$('#transfer-modal')).modal('show');
            }
        }
    }

    generateFavouriteProducts(data :CustomerProducts){
        this.favouriteProducts = [];
        let temp :any = [];
        if(data){
            if(data.accounts){
                for(let account of data.accounts){
                    account['accountSubType'] = "ACCOUNT";
                    temp.push(account);
                }
            }
            if(data.loans){
                for(let loan of data.loans){
                    loan['accountSubType'] = "LOAN";
                    temp.push(loan);
                }
            }
            if(data.cards){
                for(let card of data.cards){
                    card['accountSubType'] = "CARD";
                    card['availableBalancePercentage'] = this.templateService.calAvailBalPercentage(card.availableBalance.value,card.cardLimit.value);
                    temp.push(card);
                }
            }
            if(data.deposits){
                for(let deposit of data.deposits){
                    deposit['accountSubType'] = "DEPOSIT";
                    temp.push(deposit);
                }
            }
        }
        this.favouriteProducts = temp;
    }

    generateCustomerProducts(data :CustomerProducts){
        this.accounts = [];
        this.loans = [];
        this.cards =[];
        this.deposits = [];
        if(data){
            if(data.accounts){
                this.accounts = data.accounts;
            }
            if(data.loans){
                this.loans = data.loans;
            }
            if(data.cards){
                this.cards = data.cards;
                this.cards.map(obj => {                                    
                   obj['availableBalancePercentage'] = this.templateService.calAvailBalPercentage(obj.availableBalance.value,obj.cardLimit.value);
                });
            }
            if(data.deposits){
                this.deposits = data.deposits;
            }
        }
    }
}