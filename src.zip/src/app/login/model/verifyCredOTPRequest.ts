export class VerifyCredOTPRequest {
	otp :string;
	pwd :string;
	authByDevice :boolean;
	deviceID :string;
}