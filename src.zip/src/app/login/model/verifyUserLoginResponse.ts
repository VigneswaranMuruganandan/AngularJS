import { UserDetails } from '../../shared/model/userDetails';

import { Biller } from '../../beneficiaries/model/biller';
import { FundTransfer } from '../../beneficiaries/model/fundTransfer';
import { Beneficiary } from '../../beneficiaries/model/beneficiary';
import { PaymentTransferMaster } from './paymentTransferMaster';
import { CountOfBillersOrPaymentsOfCustomer } from './countOfBillersOrPaymentsOfCustomer';
import { VerifyResponse } from './verifyResponse';

export class VerifyUserLoginResponse extends VerifyResponse {
	   lastSucessLoginTime :string;
       lastFailedLoginTime :string;
       remainingNumOfLoginAttempts :number;
       userDetails :UserDetails;
       hasFavorites :string;
       transferTypes :PaymentTransferMaster;
       paymentTypes :PaymentTransferMaster;
       beneficiaryCountMap :CountOfBillersOrPaymentsOfCustomer;
       billerCountMap :CountOfBillersOrPaymentsOfCustomer;
       recentTransfers :FundTransfer;
       scheduledTransfers :FundTransfer;
       productsOwned: Map<string,number>;
       beneList :Beneficiary;
       billPayList :Biller;
       auth2Factor :string; 
}