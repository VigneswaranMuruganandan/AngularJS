import { Component, OnInit, Input } from '@angular/core';
import { LoginService } from '../services/login.service';
import { LoginRequest } from '../model/loginrequest';
import { User } from '../model/user';
import { CIFData } from '../model/cifdata';
import { VerifyCredOTPRequest } from '../model/verifyCredOTPRequest';
import { VerifyUserLoginResponse } from '../model/verifyUserLoginResponse';
import { AuthKey } from '../../shared/model/authKey';
import { AuthData } from '../../shared/model/authData';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product,
    SessionContext,
    AppSession,
    GlobalVariable
} from '../../shared';

@Component({
    templateUrl: './../templates/login.html'
})
export class LoginComponent implements OnInit {
    public user: User;
    public stepValue :number;
    public IP :string;
    public loginOTPRequest: VerifyCredOTPRequest;

    constructor( private loginService: LoginService, 
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private templateService: TemplateService,
                 private errorService: ErrorService,
                 private router: Router) {}

    ngOnInit() {
      this.initLogin();
    }

    initLogin(){
      this.errorService.resetErrorResp();
      this.fetchUserIP();
      this.stepValue = 1;
      this.user = new User();
      this.templateService.loginSetup(this.user);
    }

    fetchUserIP(){
      this.loginService.fetchIPAddress()
      .subscribe(
            resp => {this.IP = resp.ip},
            error => this.sharedService.handleError(error)
        );
    }
    /*
    * Step 1: Initate the Register Device before verifying the Credentials
    */
    validateCredentials() {
      this.spinnerService.startSpinner('loader');
      let registerDeviceData = this.sharedService.setupAuthKeys();
      if(registerDeviceData && registerDeviceData.deviceID != null){
        this.sharedService.registerDevice(registerDeviceData)
          .subscribe(
              resp => this.handleRegisterDeviceDataResp(resp),
              error => this.sharedService.handleError(error)
          );
      }else{
        let sessCtx = SessionContext.getInstance();
        this.handleRegisterDeviceDataResp(sessCtx)
      }      
    }
    /*
    * Step 2: With Username , fetch the CIF ID
    */
    handleRegisterDeviceDataResp(resp: any){
      if(resp.authKey && resp.authKey.convID != null){
        let data = new LoginRequest();
        data.customerID = this.user.userName;
        this.loginService.fetchCIFNumber(data)
          .subscribe(
              resp => this.handleFetchCIFNumberLogin(resp),
              error => this.sharedService.handleError(error)
          );
      }
    }
    /*
    * Step 3: Verify the Username and Password
    */
    handleFetchCIFNumberLogin(respObj: any) {
      if (respObj && respObj.cif != null) {
        this.increaseRiskEvaluation();
        let data = new User();
        data = Object.assign({}, this.user);
        this.loginService.verifyLogin(data)
            .subscribe(
                resp => this.handleVerifyLogin(resp),
                error => this.sharedService.handleError(error)
            );
      }
    }
    /*
    * Step 4: Mange the Succes of verify Login
    */
    handleVerifyLogin(resp: VerifyUserLoginResponse) {      
      if(resp && resp.result.status == 'success'){
          if(resp.riskEvaluationAdvice == GlobalVariable.RISKEVALUATIONADVICE.ALLOW){
            this.router.navigate([GlobalVariable.ROUTE_MAPPING.CONTACT_US]);
          }
          else if(resp.riskEvaluationAdvice == GlobalVariable.RISKEVALUATIONADVICE.INCREASEAUTH){
            this.stepValue = 2;
          }
      }else if(resp.result.status == 'error'){
          this.user.pwd = '';
      }
      this.spinnerService.stopSpinner('loader');
    }

    validateOTPLogin(otp :string){
      this.spinnerService.startSpinner('loader');
      this.loginOTPRequest = new VerifyCredOTPRequest();
      this.loginOTPRequest.otp = otp;
      this.loginOTPRequest.pwd = this.user.pwd;
      this.loginService.verifyLoginOTP(this.loginOTPRequest)
        .subscribe(
            resp => this.handleVerifyLogin(resp),
            error => this.sharedService.handleError(error)
        );
    }

    handleVerifyLoginOTP(resp: VerifyUserLoginResponse){
      this.spinnerService.stopSpinner('loader');
      if(resp && resp.result.status == 'success'){
        this.router.navigate([GlobalVariable.ROUTE_MAPPING.CONTACT_US]);
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
    }

    increaseRiskEvaluation(){
      this.user.caDeviceDNA = ($("#dna").val()).toString();
      this.user.caDeviceID = this.deviceID();
      this.user.deviceIP = this.IP;
    }

    deviceID(): string {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0,
                v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    loginBack(step :number){
      if(step){
        this.stepValue = step;
        this.user = new User();
      }
    }
}