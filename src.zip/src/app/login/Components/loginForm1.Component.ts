import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import {User} from '../model/user';
import { FormsModule} from '@angular/forms';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'loginform1-component',
  templateUrl: './../templates/loginform1.html'
})
export class LoginForm1Component{
    @Output() validateCredentialsEvent = new EventEmitter();
    @Input() user: User;
    test :string;

    constructor( public templateService: TemplateService,
                 public errorService: ErrorService) {}

    
    validateUserNamePwd(valid: boolean){
      console.log(this.test);
        if(valid){
            this.errorService.resetErrorResp();
            this.templateService.resetFormValidatorFlag();
            this.validateCredentialsEvent.emit();
        }        
    }
}