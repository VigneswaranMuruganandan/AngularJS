import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { User} from '../model/user';
import { FormsModule} from '@angular/forms';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TranslateService,
    SendOtpRequest,
    TemplateService, 
    SendOtpResponse, 
    GlobalVariable
} from '../../shared';


@Component({
  selector: 'loginform2-component',
  templateUrl: './../templates/loginform2.html'
})
export class LoginForm2Component{
  @Output() loginBackEvent = new EventEmitter();

    constructor( public templateService: TemplateService,
                 public errorService: ErrorService) {}

  validateOTP(otp : string){
    if(otp){
		  this.errorService.resetErrorResp();
		}
	}

	back(){
		this.loginBackEvent.emit(1);
	}    
}