import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'registerSoftTokenModal-component',
  templateUrl: './../templates/registerSoftToken.html'
})
export class RegisterSoftTokenComponent{

}