import { Component, OnInit, Input} from '@angular/core';

@Component({
  templateUrl: './../templates/myFABProducts.html'
})
export class MyFABProductsComponent {
	

}