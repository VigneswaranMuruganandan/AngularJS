import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './myFABProducts.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { MyFABProductsService } from './services/myFABProducts.service';
import { FormsModule } from '@angular/forms';
import { MyFABProductsComponent } from './Components/myFABProducts.component';


const MYFABPRODUCTS_COMPONENTS = [
    MyFABProductsComponent
];

const MYFABPRODUCTS_PROVIDERS = [
   SharedService,
   TemplateService,
   MyFABProductsService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule
	],
  	declarations: [
	    ...MYFABPRODUCTS_COMPONENTS
	],
  	providers: [
  		...MYFABPRODUCTS_PROVIDERS
  	]
})
export class MyFABProductsModule {}
