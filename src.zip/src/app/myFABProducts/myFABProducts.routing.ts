import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MyFABProductsComponent } from './Components/myFABProducts.component';
import { AuthGuard } from '../auth-guard.service';

const routes: Routes = [
	{
        path: '',
        component: MyFABProductsComponent
    },
    {
	    path: '',
	    redirectTo: '',
	    pathMatch: 'full'
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);