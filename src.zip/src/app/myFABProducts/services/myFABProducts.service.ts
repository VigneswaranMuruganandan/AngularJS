import { Injectable } from '@angular/core';
import { Http, Response, Headers , URLSearchParams, RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class MyFABProductsService {

}