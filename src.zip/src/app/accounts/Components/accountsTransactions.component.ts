import { Component, OnInit, Input,ViewChild,ElementRef,OnChanges,SimpleChanges} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { AccountTransactions } from '../model/accountTransactions';
import * as $ from 'jquery';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import {SharedService} from '../../shared/services/shared.service';
import {AccountsService} from '../services/accounts.service';
import {AccountIdReq} from '../model/accountIdReq';
import {FTDetailReq} from '../model/ftDetailReq';
import {FTDetailResp} from '../model/ftDetailResp';
import { APIResponse } from '../../shared/model/apiResponse';
import { AccountTransactionsResp } from '../model/accountTransactionsResp';
import 'rxjs/Rx';

@Component({
    selector: 'accounts-transactions',
    templateUrl: './../templates/accountsTransactions.html'
})
export class AccountsTransactionsComponent {
  @Input() accountTransactions: AccountTransactionsResp;
  downloadFiletype :string = '';
  @ViewChild('table') tableElem: any;
  accountIdReq: AccountIdReq;
  transactions: AccountTransactions[];
  ftDetailReq: FTDetailReq;
  ftDetailResp: FTDetailResp;
  transaction: any = {
      type: "",
      count: "",
      toDate: "",
      fromDate: ""
  };
  temp: any = [];
  rows: any = [];
  columns: any = [];
  sortDateAsc = true;
  disableDownload = false;


  constructor(private accountsService: AccountsService,
      private sharedService: SharedService,
      private errorService: ErrorService,
      private spinnerService: SpinnerService) {}    

    ngOnChanges(changes: SimpleChanges) {
        if (changes.accountTransactions.currentValue) {
            this.initTableData();
        }
    }
    /*
     * Init table Data
     */
    initTableData() {
        this.errorService.resetErrorResp();
        this.transaction.type = 'All';
        this.transaction.count = 'All';
        if (this.accountTransactions.transactions) {
            this.transactions = this.accountTransactions.transactions;
            this.rows = this.transactions.map(obj => {
                let rObj = {};
                rObj['date'] = obj.txnDate;
                rObj['description'] = obj.txnDesc;
                rObj['index'] = obj.index;
                rObj['amountCurrency'] = obj.txnAmount.currency;
                rObj['balance'] = obj.balanceAfterTxn.value;
                rObj['balanceCurrency'] = obj.balanceAfterTxn.currency;
                rObj['showFT'] = obj.showFT;
                rObj['txnRef'] = obj.txnRef;
                if (obj.debitCreditIndicator == "Debit") {
                    let tempAmount = "-" + obj.txnAmount.value;
                    rObj['amount'] = parseFloat(tempAmount);
                } else {
                    rObj['amount'] = obj.txnAmount.value;
                }
                return rObj;
            });
            this.handleDownloadButton();
        } else {
            this.rows = [];
            this.handleDownloadButton();
        }
        this.temp = this.rows;
        this.tableElem.offset = 0;
    }
    /*
     * FILTER: By count 10,20,30 etc
     */
    onFilterTransactionCount(event: any) {
        const count = this.transaction.count;
        this.tableElem.offset = 0;
        if (count !== 'All' && count != 'POS') {
            const temp = this.temp.filter(function(d: any, index) {
                if (index < parseInt(count))
                    return d;
            });
            this.rows = temp;
        } else if (count == 'POS') {
            this.getPosTransactions();
        } else {
            const temp = this.temp;
            this.rows = temp;
        }
        /*reset rest filter values*/
        this.transaction.toDate = "";
        this.transaction.toFromDate = "";
        this.transaction.type = "All";
        this.handleDownloadButton();        
    }
    /*
     * Fetch POS Transactions
     */
    getPosTransactions() {
        this.spinnerService.startSpinner("loader");
        this.errorService.resetErrorResp();
        this.accountIdReq = new AccountIdReq();
        this.accountIdReq.accountId = this.accountTransactions.accountId;
        this.accountsService.fetchPosTransactions(this.accountIdReq)
            .subscribe(
                resp => this.handlePosTransactions(resp),
                error => this.sharedService.handleError(error)
            );
    }
    /*
     * Handle POS Transactions Response
     */
    handlePosTransactions(resp: any) {
        this.spinnerService.stopSpinner("loader");
        if (resp.result.status == "success") {
            if (resp.transactions.length > 0) {
                let posTransactions = resp.transactions;
                this.rows = posTransactions.map(obj => {
                    let rObj = {};
                    rObj['date'] = obj.txnDate;
                    rObj['description'] = obj.txnDesc;
                    rObj['amount'] = obj.txnAmount.value;
                    rObj['amountCurrency'] = obj.txnAmount.currency;
                    rObj['balance'] = "";
                    rObj['balanceCurrency'] = "";
                    rObj['showFT'] = false;
                    rObj['txnRef'] = obj.txnRef;
                    return rObj;
                });
                this.handleDownloadButton();
            } else {
                this.rows = [];
                this.handleDownloadButton();
            }
        } else {
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
     * FILTER: By date selection from calender
     */
    onFilterTransactionDate() {
        this.transaction.fromDate = $('#from').val();
        this.transaction.toDate = $('#to').val();
        if (this.transaction.fromDate != "" && this.transaction.toDate != "") {
            this.spinnerService.startSpinner("loader");
            this.errorService.resetErrorResp();
            this.accountIdReq = new AccountIdReq();
            this.accountIdReq.accountId = this.accountTransactions.accountId;
            this.accountIdReq.startDate = this.transaction.fromDate;
            this.accountIdReq.endDate = this.transaction.toDate;
            this.accountsService.fetchAccountTransactions(this.accountIdReq)
                .subscribe(
                    resp => this.handleAccountTransactionsResponse(resp),
                    error => this.sharedService.handleError(error)
                );
        }
    }
    handleAccountTransactionsResponse(resp: AccountTransactionsResp) {
        this.spinnerService.stopSpinner("loader");
        /*reset rest filter values*/
        this.transaction.count = "All";
        this.transaction.type = "All";
        if (resp.result.status == "success") {
            if (resp.transactions) {
                this.rows = resp.transactions.map(obj => {
                    let rObj = {};
                    rObj['date'] = obj.txnDate;
                    rObj['description'] = obj.txnDesc;
                    rObj['index'] = obj.index;
                    rObj['amountCurrency'] = obj.txnAmount.currency;
                    rObj['balance'] = obj.balanceAfterTxn.value;
                    rObj['balanceCurrency'] = obj.balanceAfterTxn.currency;
                    rObj['showFT'] = obj.showFT;
                    rObj['txnRef'] = obj.txnRef;
                    if (obj.debitCreditIndicator == "Debit") {
                        let tempAmount = "-" + obj.txnAmount.value;
                        rObj['amount'] = parseFloat(tempAmount);
                    } else {
                        rObj['amount'] = obj.txnAmount.value;
                    }
                    return rObj;
                });
                this.handleDownloadButton();
            } else {
                this.rows = [];
                this.handleDownloadButton();
            }
        } else {
            this.errorService.setErrorResp(resp.result);
            this.rows = [];
            this.handleDownloadButton();
        }
    }
    /*
     * FILTER: By All, Debit, Credit
     */
    onFilterTransactionType(event: any) {
        const type = this.transaction.type;
        if (type == 'Debit') {
            const temp = this.temp.filter(function(d: any) {
                return (d.amount.toString()).indexOf('-') !== -1;
            });
            this.rows = temp;
        }
        if (type == 'Credit') {
            const temp = this.temp.filter(function(d: any) {
                return (d.amount.toString()).indexOf('-') == -1;
            });
            this.rows = temp;
        }
        if (type == 'All') {
            const temp = this.temp;
            this.rows = temp;
        }
        /*reset rest filter values*/
        this.transaction.toDate = "";
        this.transaction.toFromDate = "";
        this.transaction.count = "All";
    }
    /*
     * SEARCH Box: By catetgory of columns 
     */
    updateFilter(event: any) {
        const val = event.target.value.toLowerCase();
        const temp = this.temp.filter(function(d: any) {
            return (
                (d.description.toLowerCase().indexOf(val) !== -1) ||
                ((d.amount.toString()).toLowerCase().indexOf(val) !== -1) ||
                ((d.balance.toString()).toLowerCase().indexOf(val) !== -1) ||
                !val
            );
        });
        this.rows = temp;
        this.tableElem.offset = 0;
    }
    /*
     * Custom sort for date column
     */
    sortDate() {
        if (this.sortDateAsc) {
            let temp = []
            let i = temp.length;
            let x = this.transactions.length - 1;
            for (i = 0; i < this.transactions.length; i++) {
                this.temp.filter((d, index, arr) => {
                    if (d.index == arr[x].index) {
                        temp.push(d);
                    };
                })
                x--;
            }
            this.rows = temp;
            this.sortDateAsc = false;
        } else {
            this.rows = this.temp;
            this.sortDateAsc = true;
        }
    }
    /*
     * Click of Filter Button
     */
    filterOptions(event: ElementRef) {
        $('.download-popover').hide();
        $('.search-transactions').hide();
        $('.transactions-filters').show();
        $('.download1').hide();
    }
    /*
     * Close Filter options
     */
    closeFilter(event: ElementRef) {
        $('.download-popover').hide();
        $('.search-transactions').show();
        $('.transactions-filters').hide();
        $('.apply-filter').show();
        $('.download1').show();
        const temp = this.temp;
        this.rows = temp;
        this.tableElem.offset = 0;
        this.transaction.type = 'All';
        this.transaction.count = 'All';
        this.transaction.toDate = "";
        this.transaction.fromDate = "";
        this.handleDownloadButton();
    }
    /*
     * Show FT Details
     */
    showFTDetails(txnRef: string, event: any) {
        let offset = $(event.currentTarget).offset();
        $(".paypal-popover").css({
            "top": (offset.top - 1150) + "px",
            "left": (offset.left - 150) + "px"
        });
        $(".paypal-popover").show();
        this.spinnerService.startSpinner("ftPopup");
        this.ftDetailReq = new FTDetailReq();
        this.ftDetailReq.accountNo = this.accountTransactions.accountId;
        this.ftDetailReq.transactionId = txnRef;
        this.errorService.resetErrorResp();
        this.accountsService.fetchFTDetail(this.ftDetailReq)
          .subscribe(
              resp => this.handleFTDetailResponse(resp),
              error => this.sharedService.handleError(error)
          );
    }
    handleFTDetailResponse(resp: FTDetailResp) {
        this.spinnerService.stopSpinner("ftPopup");
        if (resp.result.status == "success") {
            this.ftDetailResp = new FTDetailResp();
            this.ftDetailResp = resp;
        } else {
            this.errorService.setErrorResp(resp.result);
        }
    }
    closeFTDetail() {
        $(".paypal-popover").hide();
    }
    /*
     * Download Popover open/close
     */
    openDownloadPopover(event: ElementRef) {
        $('.download-popover').slideToggle();
    }
    closeDownloadPopup() {
        $('.download-popover').hide();
    }
    /*
     * Download: Transactions PDF,EXCEL,CSV
     */
    selectDownloadTransactionsType(checked: boolean, format: string) {
        if (checked) {
            this.errorService.resetErrorResp();
            this.spinnerService.startSpinner("loader");
            this.accountIdReq = new AccountIdReq();
            this.accountIdReq.accountId = this.accountTransactions.accountId;
            this.accountIdReq.exportType = format;
            if (this.transaction.count != "All") {
                this.accountIdReq.numberOfTransactions = this.transaction.count;
            }
            if (this.transaction.type != "All") {
                this.accountIdReq.transactionType = this.transaction.type;
            }
            if (this.transaction.toDate != "" && this.transaction.fromDate != "") {
                this.accountIdReq.startDate = this.transaction.fromDate;
                this.accountIdReq.endDate = this.transaction.toDate;
            }
            this.accountsService.downloadTransactions(this.accountIdReq)
                .subscribe(
                    resp => this.handleDownloadTransactionsResponse(resp, format),
                    error => this.sharedService.handleError(error)
                );
        }
    }
    handleDownloadTransactionsResponse(resp: any, format: string) {
      $('.download-popover').slideToggle();
      this.downloadFiletype = '';
      if (resp.statusText == "OK") {
          let filename = resp.headers.get('content-disposition').match(/filename="(.+)"/)[1];
          this.spinnerService.stopSpinner("loader");
          let mediaType;
          let fileType = {
              "PDF": "application/pdf",
              "EXCEL": "application/vnd.ms-excel",
              "CSV": "text/csv"
          }
          switch (format) {
              case 'PDF':
                  mediaType = "application/" + format.toLowerCase();
                  break;
              case 'EXCEL':
                  mediaType = "application/vnd.ms-excel"
                  break;
              default:
                  mediaType = "text/csv"
          }
          var blob = new Blob([resp._body], {
              type: mediaType
          });
          var url = window.URL.createObjectURL(blob);
          if (mediaType == "application/pdf" || mediaType == "text/csv" || mediaType == "application/vnd.ms-excel") {
              if (navigator.msSaveOrOpenBlob) {
                  navigator.msSaveBlob(blob, filename);
              } else {
                  let a = document.createElement('a');
                  a.href = url;
                  a.download = filename;
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
              }
          }
      } else {
        this.errorService.setErrorResp(resp.result);
      }
    }
    /*
     * Download E-Statement for Accounts
     */
    downloadEstatement() {
        this.spinnerService.startSpinner("loader");
        this.errorService.resetErrorResp();
        this.accountIdReq = new AccountIdReq();
        this.accountIdReq.accountId = this.accountTransactions.accountId;
        this.accountsService.downloadEstatement(this.accountIdReq)
          .subscribe(
              resp => this.handleAccountEstatementResponse(resp),
              error => this.sharedService.handleError(error)
          );
    }
    /*
    * Handle the Download E-Statement service
    */
    handleAccountEstatementResponse(resp: any) {
      if (resp.statusText == "OK") {
        this.spinnerService.stopSpinner("loader");
        let filename = resp.headers.get('content-disposition').match(/filename="(.+)"/)[1];
        let blob = new Blob([resp._body], {
            type: 'application/pdf'
        });
        let url = window.URL.createObjectURL(blob);
        if (navigator.msSaveOrOpenBlob) {
            navigator.msSaveBlob(blob, filename);
        } else {
          let a = document.createElement('a');
          a.href = url;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }
      }else{
        this.errorService.setErrorResp(resp.result);
      }
    }
    handleDownloadButton(){
      this.disableDownload = false;
      if(this.rows.length == 0){
        this.disableDownload = true;
      }
    }
}
