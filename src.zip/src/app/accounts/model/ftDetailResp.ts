import { Amount } from '../../shared/model/amount';
import { APIResponse } from '../../shared/model/apiResponse';

export class FTDetailResp extends APIResponse{
	  transactionId:string;
	  transactionType:string;
	  debitAmount:Amount;
	  creditAmount:Amount;
	  debitValueDate:string;
	  creditValueDate:string;
	  processedDate:string;
	  debitaccountNo:string;
	  debitCurrencyCode:string;
	  creditaccountNo:string;
	  creditCurrencyCode:string;
	  orderingCustomer:string;
	  orderingBank:string;
	  paymentDetails:string;
	  rate:string;
	  cin:string;
	  customerName:string;
	  beneficiary:string;
	  transactionDesc:string;
}

