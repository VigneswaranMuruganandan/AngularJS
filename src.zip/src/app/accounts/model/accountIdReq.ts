
export class AccountIdReq {
	 accountId:string;
	 exportType:string;
     numberOfTransactions:string;
     transactionType:string;
 	 startDate:string;
     endDate:string;

}

