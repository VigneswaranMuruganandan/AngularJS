import {APIResponse} from '../../shared/model/apiResponse';
import { AccountTransactions } from './accountTransactions';

export class AccountTransactionsResp extends APIResponse{
	accountId:string;
	transactions:AccountTransactions[];

}

