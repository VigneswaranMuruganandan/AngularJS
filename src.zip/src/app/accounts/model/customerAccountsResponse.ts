
import {APIResponse} from '../../shared/model/apiResponse';
import { CustomerProducts } from '../../shared/model/customerProducts';

export class CustomerAccountsResponse extends APIResponse{
	 favouriteProducts : CustomerProducts;
	 customerProducts : CustomerProducts;
}

