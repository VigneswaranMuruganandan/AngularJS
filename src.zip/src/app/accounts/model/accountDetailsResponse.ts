
import {APIResponse} from '../../shared/model/apiResponse';
import { Amount } from '../../shared/model/amount';


export class AccountDetailsResponse extends APIResponse{
	accountNumber:string;
	accountTitle1:string;
	accountTitle2:string;
	nickName:string;
	currency:string;
	startDate:string;
	unclearedBalance:Amount;
	usableBalance:Amount;
	ledgerBalance:Amount;
	clearedBalance:Amount;
	isInactive:boolean ;
	productIdentifier:string;
	productGroup:string;
	productDescription:string;
	iban:string;
}

