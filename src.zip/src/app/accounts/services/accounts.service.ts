import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {AppSession} from '../../shared/model/appSession';
import {AuthKey} from '../../shared/model/authKey';
import {AuthData} from '../../shared/model/authData';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {SessionContext} from '../../shared/model/sessionContext';
import {GlobalURL} from '../../shared/services/globalURL';
import {CustomerAccountsResponse} from '../model/customerAccountsResponse';
import { APIResponse } from '../../shared/model/apiResponse';
import {AccountIdReq} from '../model/accountIdReq';
import {FTDetailReq} from '../model/ftDetailReq';
import {FTDetailResp} from '../model/ftDetailResp';
import {AccountDetailsResponse} from '../model/accountDetailsResponse';
import { AccountTransactionsResp } from '../model/accountTransactionsResp';


@Injectable()
export class AccountsService{

  constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService) {}

   fetchCustomerAccounts(): Observable <CustomerAccountsResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTS.CUSTOMERACCOUNTS,null)
                                .map(resp => JSON.parse(resp));
    }

    fetchAccountDetails(data:any): Observable <AccountDetailsResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTS.ACCOUNTDETAIL,data)
                                .map(resp => JSON.parse(resp));
    }

    fetchAccountTransactions(data:any): Observable <AccountTransactionsResp> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTS.ACCOUNT_TRANSACTIONS,data)
                                .map(resp => JSON.parse(resp));
    }
    fetchFTDetail(data:FTDetailReq): Observable <FTDetailResp> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTS.FT_DETAIL,data)
                                .map(resp => JSON.parse(resp));
    }
    fetchPosTransactions(data:AccountIdReq): Observable <any> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTS.POS_TRANSACTIONS,data)
                                .map(resp => JSON.parse(resp));
    }

    downloadEstatement(data:AccountIdReq): Observable <APIResponse> {
      return this.serviceInvoker.invokeDownLoad(GlobalURL.SERVICE_URL.ACCOUNTS.DOWNLOAD_ACCOUNT_ESTATEMENT,data)
                                //.map(resp => JSON.parse(resp));
    }

    downloadTransactions(data:AccountIdReq): Observable <APIResponse> {
      return this.serviceInvoker.invokeDownLoad(GlobalURL.SERVICE_URL.ACCOUNTS.DOWNLOAD_ACCOUNT_TRANSACTIONS,data)
                               // .map(resp => JSON.parse(resp));
    }
   

}


