import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './beneficiaries.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { BeneficiariesService} from './services/beneficiaries.service';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { FormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { BeneficiariesComponent } from './Components/beneficiaries.component';
import { BeneficiariesTransfersComponent } from './Components/beneficiariesTransfers.component';
import { BeneficiariesPaymentsComponent } from './Components/beneficiariesPayments.component';
import { WithinFABAddBeneComponent }      from './Components/withinFABAddBene.component';
import { WithinFABAddBeneStep1Component } from './Components/withinFABAddBeneStep1.component';
import { WithinFABAddBeneStep2Component } from './Components/withinFABAddBeneStep2.component';
import { WithinFABAddBeneStep3Component } from './Components/withinFABAddBeneStep3.component';
import { WithinFABAddBeneStep4Component } from './Components/withinFABAddBeneStep4.component';
import { WithinUAEAddBeneComponent }      from './Components/withinUAEAddBene.component';
import { WithinUAEAddBeneStep1Component } from './Components/withinUAEAddBeneStep1.component';
import { WithinUAEAddBeneStep2Component } from './Components/withinUAEAddBeneStep2.component';
import { WithinUAEAddBeneStep3Component } from './Components/withinUAEAddBeneStep3.component';
import { WithinUAEAddBeneStep4Component } from './Components/withinUAEAddBeneStep4.component';
import { OutsideUAEAddBeneComponent }     from './Components/outsideUAEAddBene.component';
import { OutsideUAEAddBeneStep1Component } from './Components/outsideUAEAddBeneStep1.component';
import { OutsideUAEAddBeneStep2Component } from './Components/outsideUAEAddBeneStep2.component';
import { OutsideUAEAddBeneStep3Component } from './Components/outsideUAEAddBeneStep3.component';
import { OutsideUAEAddBeneStep4Component } from './Components/outsideUAEAddBeneStep4.component';
import { OutsideUAEAddBeneStep5Component } from './Components/outsideUAEAddBeneStep5.component';
import { ValidateFABBeneficiary,ValidateWithinUAEBeneficiary,ValidateOutsideUAEBeneficiary, ValidateBillerBeneficiary } from './directives/validateBeneficiaries.directive';
import { AddBillerComponent }      from './Components/addBiller.component';
import { AddBillerStep1Component } from './Components/addBillerStep1.component';
import { AddBillerStep2Component } from './Components/addBillerStep2.component';
import { AddBillerStep3Component } from './Components/addBillerStep3.component';
import { AddBillerStep4Component } from './Components/addBillerStep4.component';
import { DeleteBillerBeneficiaryComponent } from './Components/deleteBillerBeneficiary.component';
import { DeleteTransferBeneficiaryComponent } from './Components/deleteTransferBeneficiary.component';

const BENEFICIARIES_COMPONENTS = [
    BeneficiariesComponent,
    BeneficiariesTransfersComponent,
    BeneficiariesPaymentsComponent,
    WithinFABAddBeneComponent,
    WithinFABAddBeneStep1Component,
    WithinFABAddBeneStep2Component,
    WithinFABAddBeneStep3Component,
    WithinFABAddBeneStep4Component,
    WithinUAEAddBeneComponent,
    WithinUAEAddBeneStep1Component,
    WithinUAEAddBeneStep2Component,
    WithinUAEAddBeneStep3Component,
    WithinUAEAddBeneStep4Component,
    OutsideUAEAddBeneComponent,
    OutsideUAEAddBeneStep1Component,
    OutsideUAEAddBeneStep2Component,
    OutsideUAEAddBeneStep3Component,
    OutsideUAEAddBeneStep4Component,
    OutsideUAEAddBeneStep5Component,
    AddBillerComponent,
    AddBillerStep1Component,
    AddBillerStep2Component,
    AddBillerStep3Component,
    AddBillerStep4Component,
    DeleteBillerBeneficiaryComponent,
    DeleteTransferBeneficiaryComponent
   
];

const BENEFICIARIES_PROVIDERS = [
   SharedService,
   TemplateService,
   BeneficiariesService
];

const BENEFICIARIES_DIRECTIVES = [
    ValidateFABBeneficiary,
    ValidateWithinUAEBeneficiary,
    ValidateOutsideUAEBeneficiary,
    ValidateBillerBeneficiary
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
		  CommonModule,
      NgxDatatableModule
	],
  	declarations: [
	    ...BENEFICIARIES_COMPONENTS,
      ...BENEFICIARIES_DIRECTIVES
	],
  	providers: [
  		...BENEFICIARIES_PROVIDERS
  	]
})
export class BeneficiariesModule {}
