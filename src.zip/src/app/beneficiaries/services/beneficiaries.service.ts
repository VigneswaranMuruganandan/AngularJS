import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { GlobalURL} from '../../shared/services/globalURL';
import { ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import { BeneListResp} from '../model/beneListResp';
import { BillerListResp} from '../model/billerListResp';
import { CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import { CreateBeneficiaryResponse} from '../model/createBeneficiaryResponse';
import { CreateBillerBeneRequest} from '../model/createBillerBeneRequest';
import { CreateBillerBeneResponse} from '../model/createBillerBeneResponse';
import { SetupForPaymentResponse} from '../model/setupForPaymentResponse';
import { SetupForPaymentRequest} from '../model/setupForPaymentRequest';
import { SetupForTransferResponse} from '../model/setupForTransferResponse';
import { SetupForTransferRequest} from '../model/setupForTransferRequest'
import { DeleteBeneficiaryRequest} from '../model/deleteBeneficiaryRequest';
import { DeleteBillerBeneRequest} from '../model/deleteBillerBeneRequest';
import { FetchBalanceForPaymentRequest } from '../model/fetchBalanceForPaymentRequest';
import { FetchBalanceForPaymentResponse } from '../model/fetchBalanceForPaymentResponse';
import { APIResponse } from '../../shared/model/apiResponse';
import { SetupForBeneficiaryResponse} from '../model/setupForBeneficiaryResponse';
import { SetupForBeneficiaryRequest} from '../model/setupForBeneficiaryRequest';
import { ValidateBeneficiaryRequest} from '../model/validateBeneficiaryRequest';

@Injectable()
export class BeneficiariesService {

    addBillerType:string;
  	constructor(private serviceInvoker: ServiceInvoker) {}

    setAddBillerType(type:string){
      this.addBillerType= type;
    }

    getAddBillerType(){
      return this.addBillerType;
    }

    fetchBeneTransferList(): Observable <BeneListResp> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.BENE_TRANSFER_FETCH,null)
                                .map(resp => JSON.parse(resp));
    }

    fetchBenePaymentList(): Observable <BillerListResp> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.BENE_PAYMENT_FETCH,null)
                                .map(resp => JSON.parse(resp));
    }

    createBeneficiary(data:CreateBeneficiaryRequest): Observable <CreateBeneficiaryResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.CREATE_BENEF,data)
                                .map(resp => JSON.parse(resp));
    }

    deleteBeneficiary(data:DeleteBeneficiaryRequest): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.DELETE_BENEF,data)
                                .map(resp => JSON.parse(resp));
    }

    beneficiarySetup(data:SetupForBeneficiaryRequest): Observable <SetupForBeneficiaryResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.BENE_CONF_FETCH,data)
                                .map(resp => JSON.parse(resp));
    }

    validateBeneficary(data:ValidateBeneficiaryRequest): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.BENE_VALIDATE,data)
                                .map(resp => JSON.parse(resp));
    }

    paymentSetup(data:SetupForPaymentRequest): Observable <SetupForPaymentResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.PAYMENTS.SETUP_FOR_PAYMENT,data)
                                .map(resp => JSON.parse(resp));
    }

    createBillPayBeneficiary(data:CreateBillerBeneRequest):Observable <CreateBillerBeneResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.CREATE_BILLPAY_TEMPLATE,data)
                                .map(resp => JSON.parse(resp));
    }

    deleteBillPayBeneficiary(data:DeleteBillerBeneRequest):Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.DELETE_BILLPAY_TEMPLATE,data)
                                .map(resp => JSON.parse(resp));
    }

    transferSetup(data:SetupForTransferRequest): Observable <SetupForTransferResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.TRANSFERS.SETUP_FOR_TRANSFER,data)
                                .map(resp => JSON.parse(resp));
    }

    balanceEnquiryForPayment(data:FetchBalanceForPaymentRequest):Observable <FetchBalanceForPaymentResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.PAYMENTS.BALANCE_FETCH_FOR_PAYMENT,data)
                                .map(resp => JSON.parse(resp));
    }

}


