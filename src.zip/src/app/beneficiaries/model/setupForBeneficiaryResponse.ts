import {APIResponse} from '../../shared/model/apiResponse';
import {Product} from '../../shared/model/product';
import {Amount} from '../../shared/model/amount';
import {Beneficiary} from './beneficiary';
import {Bank} from './bank';

export class SetupForBeneficiaryResponse  extends APIResponse{

	transferType:string;
	fundingSources:Product[];
	receivingPoints:Product[];
	txnRef:string;
/*	beneficiaries:Beneficiary[];
	dailyTransferLimit:Amount;
	currencies:string[];
	transferTypes:string[];
	transferInstructionNotes:string;
	sharedCharge:Amount;
	ownAccCharge:Amount;
	beneAccCharge:Amount;
	chargeHelpMsg:string;*/
	banks:Bank[];
}




