
export class ValidateBeneficiaryRequest{
  	fundTransferType:string;
    nickName:string;
    accountOrCardNo:string;
    consumerNo:string;
    operation:string;
    beneName:string;
    bankName:string;
    paymentTypes:string;
}

