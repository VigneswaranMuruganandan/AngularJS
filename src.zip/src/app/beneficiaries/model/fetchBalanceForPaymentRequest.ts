
export class FetchBalanceForPaymentRequest {

    agency:string;
    consumerNo:string;
    salikPinNo:string
    telephoneNo:string;
     
}

