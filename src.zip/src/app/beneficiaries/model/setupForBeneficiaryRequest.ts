export class SetupForBeneficiaryRequest {

	transferType:string;

}

