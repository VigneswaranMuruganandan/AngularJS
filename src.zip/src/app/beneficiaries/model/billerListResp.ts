
import {APIResponse} from '../../shared/model/apiResponse';
import { Biller } from './biller';

export class BillerListResp extends APIResponse{

  	billerList:Biller[];
}

