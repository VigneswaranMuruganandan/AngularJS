export class Biller {
    templateId: string;
    billerId: string;
    billerName: string;
    consumerNo: string;
    description: string;
    nextRunOnDate: string;
    maxAmount: string;
    autoPayment: boolean;
    nickName: string;
    siId: string;
    beneId:string;
}