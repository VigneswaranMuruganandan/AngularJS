import { FundTransfer } from './fundTransfer';

export class Beneficiary {	
  	id:string;
  	nickName:string;
  	name:string;
  	templateId:string;
  	acctOrCardNo:string;
  	type:string;
  	address1:string;
  	address2:string;
  	address3:string;
  	currency:string;
  	bankName:string;
  	country:string;
  	branch:string;
  	bankAddress1:string;
  	bankAddress2:string;
  	swiftCode:string;
    latestTransfers:FundTransfer[];  
    transferTo :string;
    $$index: number;
}