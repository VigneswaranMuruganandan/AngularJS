import { Account } from '../../shared/model/account';

export class FundTransfer {
    transferAmount: number;
    transferCurrency: string;
    description: string;
    transactionType: string;
    beneficiaryNickName: string;
    source: Account;
    destination: Account;
    fxRate: number;
    chargedTo: string;
}