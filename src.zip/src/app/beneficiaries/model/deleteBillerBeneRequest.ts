
export class DeleteBillerBeneRequest{
	agency:string;
	consumerNo:string;
	nickName:string;
	templateId:string;
	autopayEnabled:boolean;
    siId:string;
    beneId:string;
}

