
import {APIResponse} from '../../shared/model/apiResponse';
import { Beneficiary } from './beneficiary';

export class BeneListResp extends APIResponse{

  	beneficiaryList:Beneficiary[];
}

