import {APIResponse} from '../../shared/model/apiResponse';

export class CreateBeneficiaryResponse extends APIResponse{

  	

}

