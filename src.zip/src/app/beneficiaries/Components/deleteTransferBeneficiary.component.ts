import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product, 
    APIResponse,
    UserContext
} from '../../shared';
import { BeneficiariesService} from '../services/beneficiaries.service';
import { Beneficiary} from '../model/beneficiary';
import { DeleteBeneficiaryRequest} from '../model/deleteBeneficiaryRequest';

@Component({
	selector: 'deleteTransferBeneficiary-modal',
  templateUrl: './../templates/deleteTransferBeneficiary.html'
})
export class DeleteTransferBeneficiaryComponent implements OnInit  {
    public stepValue: number;
    public recurringPayments :boolean;
    deleteBeneficiaryRequest :DeleteBeneficiaryRequest;
    @Input() beneficiary :Beneficiary;
    @Output() reloadTransferBeneficiaries = new EventEmitter();

    constructor( private templateService: TemplateService,
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 public beneficiariesService: BeneficiariesService,
                 private router: Router) {}

    ngOnInit() {
        this.initDeleteBeneficiary();
        
    }

    initDeleteBeneficiary(){
      this.errorService.resetErrorResp();
      this.deleteBeneficiaryRequest = new DeleteBeneficiaryRequest();
      this.stepValue = 1;
      this.recurringPayments = false;
    }

    deleteBeneficiaryConfirm(){
      this.errorService.resetErrorResp();
      this.deleteBeneficiaryRequest.fundTransferType = this.beneficiary.type;
      this.deleteBeneficiaryRequest.nickName = this.beneficiary.nickName;
      this.deleteBeneficiaryRequest.beneId = this.beneficiary.id;
      this.errorService.resetErrorResp();
      this.spinnerService.startSpinner('deleteTransferBeneficiary');      
      this.beneficiariesService.deleteBeneficiary(this.deleteBeneficiaryRequest)
        .subscribe(
          resp => this.handleDeleteBeneficiary(resp),
          error => this.sharedService.handleError(error)
        );
    }

    handleDeleteBeneficiary(resp :APIResponse){
      UserContext.getInstance().transferData = null;
      this.spinnerService.stopSpinner('deleteTransferBeneficiary');
      if(resp.result.status == 'success'){
          this.stepValue = 2;
          this.reloadTransferBeneficiaries.emit();
      }else if(resp.result.status == 'error'){
          this.errorService.setErrorResp(resp.result);

      }
    }

    closeModal(){
      this.errorService.resetErrorResp();
      (<any>$('#deleteTransfer-bene')).modal('hide');
    }
}
