import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import {CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import { SetupForBeneficiaryResponse} from '../model/setupForBeneficiaryResponse';
import { Bank } from '../model/bank';
import { TemplateService } from '../../shared/services/template.service';

@Component({
  selector: 'withinUAEAddBeneStep2-component',
  templateUrl: './../templates/withinUAEAddBeneStep2.html'
})
export class WithinUAEAddBeneStep2Component implements OnInit{

	@Output() confirmReviewButtonEvent = new EventEmitter();
	@Output() backReviewButtonEvent = new EventEmitter();
	@Input() createBeneficiaryRequest:CreateBeneficiaryRequest;
	@Input() setupForBeneficiaryResponse:SetupForBeneficiaryResponse;
	public bank:Bank;

	constructor( public templateService: TemplateService){}
	
	ngOnInit() { 
	  this.bank = this.setupForBeneficiaryResponse.banks[this.templateService.getSelectIndex(this.setupForBeneficiaryResponse.banks,'bankCode',this.createBeneficiaryRequest.receiverBankName)];
	}

	confirmReview(){
		this.confirmReviewButtonEvent.emit();
	}

	backReview(){
		this.backReviewButtonEvent.emit();
	}
    
}
