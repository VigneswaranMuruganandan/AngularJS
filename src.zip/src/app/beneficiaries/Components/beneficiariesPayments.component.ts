import { Component, OnInit, Input, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { BeneficiariesService} from '../services/beneficiaries.service';
import { SharedService} from '../../shared/services/shared.service';
import { TemplateService} from '../../shared/services/template.service';
import { MessageService} from '../../shared/services/message.service';
import { BillerListResp} from '../model/billerListResp';
import { Biller} from '../model/biller';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { GlobalVariable} from '../../shared/services/global';
//import * as $ from 'jquery';
import { UserContext} from '../../shared/model/userContext';
import { DeleteBillerBeneficiaryComponent } from './deleteBillerBeneficiary.component';

@Component({
  selector: 'beneficiaries-payments',
  templateUrl: './../templates/beneficiariesPayments.html'
})
export class BeneficiariesPaymentsComponent implements OnInit{

	@ViewChild('table') tableElem: any;
	@ViewChild(DeleteBillerBeneficiaryComponent) deleteBillerComponent:DeleteBillerBeneficiaryComponent;
	billerListResp:BillerListResp;
	biller:Biller
	imageUrl:any;
	temp: any = [];
	rows: any = [];

	constructor(  private beneficiariesService:BeneficiariesService,
		          private sharedService: SharedService,
		          public templateService: TemplateService,
		          public messageService:MessageService,
		          private errorService: ErrorService,
		          private spinnerService: SpinnerService,
		          private router: Router) {}

	ngOnInit() { 
	  this.initBeneficariesPayment();
	}

	initBeneficariesPayment(){
	  this.spinnerService.startSpinner('loader');
	  this.getBillerList();
	  this.imageUrl = GlobalVariable.IMAGE_URL;
	  this.errorService.resetErrorResp();
	  if(!($('#info-drawer-payment').hasClass('slider-drawer-closed'))){
          $('#info-drawer-payment').addClass('slider-drawer-closed');
      }
	}

	getBillerList(){
      this.beneficiariesService.fetchBenePaymentList()
        .subscribe(
            resp => this.handleBenePaymentResp(resp),
            error => this.sharedService.handleError(error)
        );
  	}

	handleBenePaymentResp(resp:BillerListResp){
	  this.spinnerService.stopSpinner('loader');
	  if (resp.result.status == "success") {
	      this.billerListResp = new BillerListResp();
	      this.billerListResp = resp;
	      this.initTableData(resp);
	  }else if (resp.result.status == 'error') {
	      this.errorService.setErrorResp(resp.result);
	  }
	}

	initTableData(beneList:BillerListResp){
      this.rows=beneList.billerList;
      this.temp=beneList.billerList;
      this.tableElem.offset = 0;
  	}

  	paymentTypeFilter(event,payType:string){
	    if(payType=="Automatic"){
	        this.billerListResp.billerList = this.temp.filter(beneItem => 
	                                                beneItem.autoPayment == true);
	        this.rows = this.billerListResp.billerList;
	        $( "#dropdownMenuPayment" ).html(event.currentTarget.text);
	        //this.tableElem.offset = 0;
	    }else if(payType=="OneTime"){
	        this.billerListResp.billerList = this.temp.filter(beneItem => 
	                                                beneItem.autoPayment == false);
	        this.rows = this.billerListResp.billerList;
	        $( "#dropdownMenuPayment" ).html(event.currentTarget.text);
	        //this.tableElem.offset = 0;
	    }else{
	        this.billerListResp.billerList = this.temp;
	        this.rows = this.billerListResp.billerList;
	        $( "#dropdownMenuPayment" ).html(event.currentTarget.text);
	        //this.tableElem.offset = 0;
	    }
  	}

  	payBill(biller:Biller){ 
  	    UserContext.getInstance().biller = biller;
        this.router.navigate([GlobalVariable.ROUTE_MAPPING.PAYMENTS_EXECUTE]);
    }

  	createPayment(addPaymentType:string){
  		this.beneficiariesService.setAddBillerType(addPaymentType);
  		this.router.navigate([GlobalVariable.ROUTE_MAPPING.BENEFICIARIES_ADDBILLER]);
  	}

	listView(event){
		$('#grid-filter-payment').show();
		$(event.currentTarget).hide();
		$('.grid-payment-wrapper').hide();
		$('.list-payment-wrapper').show();
	}

	gridView(event){
		$('#list-filter-payment').show();
		$(event.currentTarget).hide();
		$('.grid-payment-wrapper').show();
		$('.list-payment-wrapper').hide();
	}

	detailDrawer(event,bene:Biller){
		this.biller = new Biller();
		this.biller = bene;
		$('#info-drawer-payment').toggleClass('slider-drawer-closed');
		$(event.currentTarget).toggleClass('active');
	};

	closeDrawer(){
		$('#info-drawer-payment').toggleClass('slider-drawer-closed');
		$('.grid-view').removeClass('active');
	};

	deletePaymentBene(){
		(<any>$('#delete-payment')).modal('show');
		if(this.deleteBillerComponent){
			this.deleteBillerComponent.initDeleteBeneficiary();
		}
	}
}