import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import {CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import {TemplateService} from '../../shared/services/template.service';
import { SetupForBeneficiaryResponse} from '../model/setupForBeneficiaryResponse';

@Component({
  selector: 'withinUAEAddBeneStep1-component',
  templateUrl: './../templates/withinUAEAddBeneStep1.html'
})
export class WithinUAEAddBeneStep1Component {

	@Output() validateFormNextButtonEvent = new EventEmitter();
	@Input() createBeneficiaryRequest:CreateBeneficiaryRequest;
	@Input() setupForBeneficiaryResponse:SetupForBeneficiaryResponse;

	constructor( public templateService: TemplateService) {}

	validateForm(valid:boolean){
		if(valid){
			this.createBeneficiaryRequest.receiverBankName = this.setupForBeneficiaryResponse.banks[this.templateService.getSelectIndex(this.setupForBeneficiaryResponse.banks,'bankCode',this.createBeneficiaryRequest.receiverBankSwiftCode)].bankName;
            this.templateService.resetFormValidatorFlag();
            this.validateFormNextButtonEvent.emit();
        }   
	}
    
}
