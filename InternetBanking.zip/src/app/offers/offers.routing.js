"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var offers_component_1 = require("./Components/offers.component");
var routes = [
    {
        path: '',
        component: offers_component_1.OffersComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=offers.routing.js.map