import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './offers.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { OffersComponent }   from './Components/offers.component';
import { FormsModule } from '@angular/forms';

const OFFERS_COMPONENTS = [
    OffersComponent
];

const OFFERS_PROVIDERS = [
   SharedService,
   TemplateService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
		CommonModule
	],
  	declarations: [
	    ...OFFERS_COMPONENTS
	],
  	providers: [
  		...OFFERS_PROVIDERS
  	]
})
export class OffersModule {}
