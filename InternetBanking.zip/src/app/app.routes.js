"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var auth_guard_service_1 = require("./auth-guard.service");
var routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'login',
        canActivate: [auth_guard_service_1.AuthGuard],
        loadChildren: 'app/login/login.module#LoginModule',
    },
    {
        path: 'registration',
        canActivate: [auth_guard_service_1.AuthGuard],
        loadChildren: 'app/register/register.module#RegisterModule'
    },
    {
        path: 'forgotPassword',
        canActivate: [auth_guard_service_1.AuthGuard],
        loadChildren: 'app/forgotPassword/forgotPassword.module#ForgotPasswordModule'
    },
    {
        path: '',
        canActivate: [auth_guard_service_1.AuthGuard],
        loadChildren: 'app/dashboard/dashboard.module#DashboardModule'
    }
];
exports.routing = router_1.RouterModule.forRoot(routes);
//# sourceMappingURL=app.routes.js.map