import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'investmentsAboutUs-component',
  templateUrl: './../templates/investmentsAboutUs.html'
})
export class InvestmentsAboutUsComponent {

}