import { Component, OnInit, Input,Output,EventEmitter} from '@angular/core';


@Component({
  selector: 'applyproductstep2-component',
  templateUrl: './../templates/applyProductStep2.html'
})
export class ApplyProductStep2Component {
@Output() applyProductsNowEvent = new EventEmitter();
	@Input() productsSelected:Array<any>;
	
	applyProductsNow(){
		this.applyProductsNowEvent.emit();
	}
}