"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var shared_service_1 = require("../../shared/services/shared.service");
var spinner_service_1 = require("../../shared/services/spinner.service");
var error_service_1 = require("../../shared/services/error.service");
var investments_service_1 = require("../services/investments.service");
var entity_1 = require("../../shared/model/entity");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/map");
var InvestmentsMainComponent = (function () {
    function InvestmentsMainComponent(investmentsService, sharedService, spinnerService, errorService) {
        this.investmentsService = investmentsService;
        this.sharedService = sharedService;
        this.spinnerService = spinnerService;
        this.errorService = errorService;
    }
    InvestmentsMainComponent.prototype.ngOnInit = function () {
        this.stepNumber = 1;
        this.viewProducts();
    };
    InvestmentsMainComponent.prototype.viewProducts = function () {
        var _this = this;
        var data = new entity_1.Entity();
        data.entityName = 'WEALTH_PRODUCTS';
        this.investmentsService.fetchProducts(data)
            .subscribe(function (resp) { return _this.handleViewProductsDataResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    InvestmentsMainComponent.prototype.handleViewProductsDataResp = function (resp) {
        console.log("handleViewProductsDataResp:::" + resp);
        if (resp && resp.result.status == 'success') {
            this.ourProducts = resp.staticMasterDataList[0];
            console.log(this.ourProducts);
        }
        else if (resp && resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    };
    InvestmentsMainComponent.prototype.validateNextToAboutUs = function () {
        this.stepNumber = 2;
    };
    InvestmentsMainComponent.prototype.validateOurProducts = function () {
        this.stepNumber = 3;
    };
    InvestmentsMainComponent = __decorate([
        core_1.Component({
            templateUrl: './../templates/investmentsMain.html'
        }),
        __metadata("design:paramtypes", [investments_service_1.InvestmentsService,
            shared_service_1.SharedService,
            spinner_service_1.SpinnerService,
            error_service_1.ErrorService])
    ], InvestmentsMainComponent);
    return InvestmentsMainComponent;
}());
exports.InvestmentsMainComponent = InvestmentsMainComponent;
//# sourceMappingURL=investmentsMain.component.js.map