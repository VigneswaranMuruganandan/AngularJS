import { Component, OnInit, Input} from '@angular/core';


@Component({
  selector: 'applyproductstep3-component',
  templateUrl: './../templates/applyProductStep3.html'
})
export class ApplyProductStep3Component {

}