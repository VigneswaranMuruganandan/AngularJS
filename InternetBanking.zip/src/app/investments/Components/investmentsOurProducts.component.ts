import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'investmentsOurProducts-component',
  templateUrl: './../templates/investmentsOurProducts.html'
})
export class InvestmentsOurProductsComponent {
@Input() ourProducts:Array<any>;

}