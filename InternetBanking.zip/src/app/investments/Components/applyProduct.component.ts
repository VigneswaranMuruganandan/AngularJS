import { Component, OnInit, Input} from '@angular/core';


@Component({
	templateUrl: './../templates/applyProduct.html'
})
export class ApplyProductComponent implements OnInit {
	stepFlag:number;
	productsSelected:Array<any>=[];
	products=[{caption:"Mutual Fund",value:"Mutual Fund"},
			  {caption:"Exchange Traded Funds",value:"Exchange Traded Funds"},
			  {caption:"Systematic Investment Plan",value:"Systematic Investment Plan"},
			  {caption:"Fixed Income",value:"Fixed Income"},
			  {caption:"Structured Notes",value:"Structured Notes"},
			  {caption:"Dual Currency Investments",value:"Dual Currency Investments"},
			  {caption:"Others",value:"Others"}]

	ngOnInit(){
		this.stepFlag=1;
	}

	applyProductSelectionSubmit(){
		this.stepFlag=2;
	}

	applyProductsNowSubmit(){
		this.stepFlag=3;
	}
}