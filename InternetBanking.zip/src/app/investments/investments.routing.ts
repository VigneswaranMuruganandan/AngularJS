import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplyProductComponent }   from './Components/applyProduct.component';
import { InvestmentsMainComponent }   from './Components/investmentsMain.component';



const routes: Routes = [
    

    {
        path: '',
        component: InvestmentsMainComponent
    },
    {
        path: 'applyProducts',
        component: ApplyProductComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
