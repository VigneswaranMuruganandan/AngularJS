"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var $ = require("jquery");
var template_service_1 = require("../../shared/services/template.service");
/*
* Apply Products Selection
*/
var ValidateApplyProductsSelection = (function () {
    function ValidateApplyProductsSelection(el, zone, templateService) {
        this.el = el;
        this.zone = zone;
        this.templateService = templateService;
        this.x = require('jquery-validator');
    }
    ValidateApplyProductsSelection.prototype.ngAfterViewInit = function () {
    };
    ValidateApplyProductsSelection.prototype.onClick = function (event) {
        var _this = this;
        var el = $(this.el.nativeElement);
        var applyProductStep1Submit;
        this.zone.runOutsideAngular(function () {
            var applyProductSelectionValidation = $("#applyProductStep1Form").validate({
                ignore: [],
                highlight: function (element) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function (element, errorClass) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function (error, element) {
                    if (element.is("input")) {
                        $('#errorDiv').append(error);
                    }
                },
                rules: {
                    products: {
                        required: true
                    },
                },
                messages: {
                    products: {
                        required: "Please make a selection"
                    }
                }
            });
            applyProductStep1Submit = applyProductSelectionValidation.form();
            _this.templateService.setFormValidatorFlag(applyProductStep1Submit);
        });
    };
    __decorate([
        core_1.HostListener('click', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], ValidateApplyProductsSelection.prototype, "onClick", null);
    ValidateApplyProductsSelection = __decorate([
        core_1.Directive({
            selector: '[ValidateProductsSelection]',
        }),
        __metadata("design:paramtypes", [core_1.ElementRef, core_1.NgZone, template_service_1.TemplateService])
    ], ValidateApplyProductsSelection);
    return ValidateApplyProductsSelection;
}());
exports.ValidateApplyProductsSelection = ValidateApplyProductsSelection;
//# sourceMappingURL=validateInvestments.directive.js.map