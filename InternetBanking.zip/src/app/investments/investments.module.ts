import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './investments.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { InvestmentsService } from './services/investments.service';
import { FormsModule } from '@angular/forms';
import { InvestmentsMainComponent }   from './Components/investmentsMain.component';
import { InvestmentsDetailsComponent }   from './Components/investmentsDetails.component';
import { InvestmentsAboutUsComponent }   from './Components/investmentsAboutUs.component';
import { InvestmentsOurProductsComponent }   from './Components/investmentsOurProducts.component';
import { ApplyProductComponent }   from './Components/applyProduct.component';
import { ApplyProductStep1Component }   from './Components/applyProductStep1.component';
import { ApplyProductStep2Component }   from './Components/applyProductStep2.component';
import { ApplyProductStep3Component }   from './Components/applyProductStep3.component';
import { ValidateApplyProductsSelection }   from './directives/validateInvestments.directive';


const INVESTMENT_COMPONENTS = [
    InvestmentsMainComponent,
    InvestmentsDetailsComponent,
    InvestmentsAboutUsComponent,
    InvestmentsOurProductsComponent,
    ApplyProductComponent,
    ApplyProductStep1Component,
    ApplyProductStep2Component,
    ApplyProductStep3Component,
    ValidateApplyProductsSelection
];

const INVESTMENT_PROVIDERS = [
   SharedService,
   TemplateService,
   InvestmentsService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule
	],
  	declarations: [
	    ...INVESTMENT_COMPONENTS
	],
  	providers: [
  		...INVESTMENT_PROVIDERS
  	]
})
export class InvestmentsModule {}
