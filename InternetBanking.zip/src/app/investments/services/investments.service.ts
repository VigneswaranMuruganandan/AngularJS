import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {GlobalVariable} from '../../shared/services/global';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {ErrorService} from '../../shared/services/error.service';
import {SessionContext} from '../../shared/model/sessionContext';
import {GlobalURL} from '../../shared/services/globalURL';
import { StaticDataResponse } from '../../shared/model/staticDataResponse';

@Injectable()
export class InvestmentsService{
  private baseUrl: string = 'stubs/';

  constructor(  private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService,
                private errorService: ErrorService) {}

  fetchProducts(data: any): Observable < StaticDataResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.VIEW_PRODUCTS, data)
                                .map(resp => JSON.parse(resp));
  }
  
}


