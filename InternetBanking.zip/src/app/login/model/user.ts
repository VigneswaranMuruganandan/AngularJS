export class User{
	userName: string;
    pwd: string;
}