export class LoginRequest{
	deviceID:string;
	customerID:string;
	otp:string;
	txnCode:string;
	pwd:string;
	userName:string;
	otpMethod: string;
}