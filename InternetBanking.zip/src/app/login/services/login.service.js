"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
require("rxjs/add/operator/toPromise");
var authKey_1 = require("../../shared/model/authKey");
var authData_1 = require("../../shared/model/authData");
var serviceInvoker_service_1 = require("../../shared/connector/serviceInvoker.service");
var encryption_service_1 = require("../../shared/services/encryption.service");
var sessionContext_1 = require("../../shared/model/sessionContext");
var globalURL_1 = require("../../shared/services/globalURL");
var error_service_1 = require("../../shared/services/error.service");
var LoginService = (function () {
    function LoginService(serviceInvoker, encryptionService, errorService) {
        this.serviceInvoker = serviceInvoker;
        this.encryptionService = encryptionService;
        this.errorService = errorService;
    }
    LoginService.prototype.verifyLogin = function (authRequest) {
        var _this = this;
        console.log(sessionContext_1.SessionContext.getInstance().userID);
        var pwdHash = this.encryptionService.generatePwdHash(sessionContext_1.SessionContext.getInstance().userID, authRequest.pwd);
        authRequest.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.LOGIN.VERIFYLOGIN, authRequest)
            .map(function (resp) { return _this.populateAuthReq(resp); });
    };
    LoginService.prototype.fetchCIFNumber = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.LOGIN.VERIFYCUSTOMERID, authRequest)
            .map(function (resp) { return _this.populateCustomerIDReq(resp); });
    };
    /*
    * verifyLogin Handler
    */
    LoginService.prototype.populateAuthReq = function (resp) {
        var respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            var authData = new authData_1.AuthData();
            authData.authKey = new authKey_1.AuthKey();
            authData.action = respObj.action[0];
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            console.log("convid " + authData.authKey.convID);
            var sessCtx = sessionContext_1.SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
            return authData;
        }
        else if (respObj.result.status == 'error') {
            this.errorService.setErrorResp(respObj.result);
        }
    };
    LoginService.prototype.populateCustomerIDReq = function (resp) {
        var respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            sessionContext_1.SessionContext.getInstance().userID = respObj.cif;
            return respObj;
        }
        else if (respObj.result.status == 'error') {
            $(".loader").fadeOut();
            this.errorService.setErrorResp(respObj.result);
        }
    };
    LoginService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [serviceInvoker_service_1.ServiceInvoker,
            encryption_service_1.EncryptionService,
            error_service_1.ErrorService])
    ], LoginService);
    return LoginService;
}());
exports.LoginService = LoginService;
//# sourceMappingURL=login.service.js.map