import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {GlobalVariable} from '../../shared/services/global';

@Injectable()
export class PaymentService{
  private baseUrl: string = 'stubs/';

  constructor(private http : Http){
  }

  
}


