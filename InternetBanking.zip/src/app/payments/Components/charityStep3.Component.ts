import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: '[charitystep3-component]',
  templateUrl: './../templates/charityStep3.html'
})
export class CharityStep3Component {
	@Output() charityMakePaymentEvent = new EventEmitter();

	charityMakePayment(){
		this.charityMakePaymentEvent.emit();
	}
}