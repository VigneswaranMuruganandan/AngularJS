import { Component, Input, OnInit, Output, EventEmitter,OnDestroy } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {Observable} from 'rxjs/Rx';
import {Subscription} from "rxjs";

@Component({
  selector: '[charitystep4-component]',
  templateUrl: './../templates/charityStep4.html'
})
export class CharityStep4Component implements OnInit,OnDestroy{
 @Output() charityOtpConfirmEvent = new EventEmitter();
 private subscription: Subscription;
 counter:number=10;
 validity:number=10;

 	ngOnInit(){
 		this.intiatliseTimer();
 	}
	charityOtpConfirm(){
		this.charityOtpConfirmEvent.emit();
	}

	intiatliseTimer(){
		let timer = Observable.timer(2000,1000);
    	this.subscription =timer.subscribe(()=>this.countUp());
	}
	countUp(){
		if(this.counter>0){
			console.log(this.counter);
			 return this.counter--;
		}
	}

	ngOnDestroy(){
		this.subscription.unsubscribe();
	}
}