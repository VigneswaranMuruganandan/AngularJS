import { Component, Input,OnInit, Output, EventEmitter,ViewChild,ElementRef,Renderer2 } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: '[charitystep1-component]',
  templateUrl: './../templates/charityStep1.html'
})
export class CharityStep1Component implements OnInit{
@Input() charityItemsList:Array<any>;
@Output() charitySelectionNextEvent = new EventEmitter();
@ViewChild('nextButton') buttonElem : ElementRef;

	
	constructor(private renderer: Renderer2){
		
	}

	ngOnInit() { 
    	
    }
	charitySelectionNext(){
		this.charitySelectionNextEvent.emit();
	}
	
	charitySelectedItem(event:any){
			this.renderer.addClass(event.currentTarget,'selected-charity');
			this.renderer.addClass(this.buttonElem.nativeElement,'visible');
		
	}
	
}