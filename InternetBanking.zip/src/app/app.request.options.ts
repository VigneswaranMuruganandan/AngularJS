import { Injectable, Inject, InjectionToken} from '@angular/core';
import {BaseRequestOptions, RequestOptions, RequestOptionsArgs, Http, Headers} from '@angular/http';



export class AppRequestOptions extends BaseRequestOptions {
  private appBaseUrl: string = 'app/assets';
  constructor() {
  	super();
  }

  merge(options?:RequestOptionsArgs):RequestOptions {
    var customOptions = super.merge(options);
    //customOptions.headers.set('Accept', 'application/json');
    customOptions.headers.set('rc', '56454545454');
    customOptions.headers.set('_OTP', '123456');
    customOptions.headers.set('_requestID', 'Vigneswaran');

    
    customOptions.url = this.appBaseUrl + options.url;
    return customOptions;
  }
}