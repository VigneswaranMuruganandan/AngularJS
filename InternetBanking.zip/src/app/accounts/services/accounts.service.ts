import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {AppSession} from '../../shared/model/appSession';
import {AuthKey} from '../../shared/model/authKey';
import {AuthData} from '../../shared/model/authData';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {SessionContext} from '../../shared/model/sessionContext';
import {GlobalURL} from '../../shared/services/globalURL';
import {CustomerAccountsResponse} from '../model/customerAccountsResponse';





@Injectable()
export class AccountsService{

  constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService) {}

   fetchCustomerAccounts(): Observable <CustomerAccountsResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTS.CUSTOMERACCOUNTS,null)
                                .map(resp => JSON.parse(resp));
    }

    fetchAccountDetail(data:any): Observable <any> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTS.ACCOUNTDETAIL,data)
                                .map(resp => JSON.parse(resp));
    }

    /*fetchAccountTransactions(data:any): Observable <any> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTS.ACCOUNTDETAIL,data)
                                .map(resp => JSON.parse(resp));
    }*/

    /*private populateAcctsResp(resp: string) {
        console.log("cust resp " + resp);
        let respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        //let responseObj = new CustomerAccountsResponse();
        return respObj;
        
    }*/


}


