import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {AccountsService} from '../services/accounts.service';
import {SharedService} from '../../shared/services/shared.service';
import {CustomerAccountsResponse} from '../model/customerAccountsResponse';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';




@Component({
  templateUrl: './../templates/accounts.html'
})
export class AccountsComponent implements OnInit {

/*STUBS START*/
	accountsStub1 ={"result":{"status":"success"},"favouriteProducts":{},
"customerProducts":{
"accounts":[{"productName":"Current Account","number":"1001001006860493","balance":{"value":122121,"valueFmt":"16,334,817.50","currency":"AED"},"accountCurrency":"AED","holderName":"FGB SCRAMBLE NAME-","currentBalance":{"value":1.63348176635E10,"valueFmt":"16,334,817,663.50","currency":"AED"},"accountType":"CH","productType":"CH","nickName":"Current Account","isFavourite":true},{"productName":"Current Account","number":"1001001006860517","balance":{"value":4334.9,"valueFmt":"4,334.90","currency":"AED"},"accountCurrency":"AED","holderName":"FGB SCRAMBLE","currentBalance":{"value":4334.9,"valueFmt":"4,334.90","currency":"AED"},"accountType":"CH","productType":"CH","nickName":"Current Account","isFavourite":true},{"productName":"Current Account","number":"1011001006860110","balance":{"value":2.46648955491898E12,"valueFmt":"2,466,489.98","currency":"USD"},"accountCurrency":"USD","holderName":"FGB SCRAMBLE NAME-1","currentBalance":{"value":2.46648955491898E12,"valueFmt":"2,466,489.98","currency":"USD"},"accountType":"CH","productType":"CH","nickName":"Current Account","isFavourite":false}],
"loans":[{"loanNumber":"MG1319900068","availableBal":-204866.79,"ledgerBal":-204866.79,"currency":"USD","holderName":"WM INVESTMENTS","type":"LN","purpose":"Loan"},{"loanNumber":"MG1413400059","availableBal":-51677.17,"ledgerBal":-51677.17,"currency":"USD","holderName":"WM INVESTMENTS","type":"LN","purpose":"Loan"}],
"cards":[{"cardNumber":"4002910001077114","cardHolderName":"Faxon","cardType":"P","status":"A","ownerType":"P","cardLimit":120000.0,"availableCashWithdrawalLimit":14000.0,"availableBalance":85000.0,"currentTotalOutstanding":500000.0,"outstandingBalance":500000.0,"minimumPaymentDue":0.0,"paymentDueDate":1426017600000,"nextStatementDate":1429041600000,"greenContributionAmount":0.0,"currency":"AED"}],
"deposits":[{"productName":"Term Deposit","number":"MM1424400004","balance":{"value":25000.0,"valueFmt":"25,000.00","currency":"CHF"},"accountCurrency":"CHF","holderName":"FIXED DEPOSITS","currentBalance":{"value":25000.0,"valueFmt":"25,000.00","currency":"CHF"},"accountType":"TD","productType":"TD"}]}};
/*STUBS END*/

	customerAccountsResponse:CustomerAccountsResponse;
	carouselAccountList:any;
	account:any;

	constructor(private accountsService: AccountsService,
				private sharedService: SharedService,
				private errorService: ErrorService,
				private spinnerService: SpinnerService) {}

	ngOnInit() {
		this.spinnerService.startSpinner();
		this.fetchAccounts();

	}

	fetchAccounts(){
		this.accountsService.fetchCustomerAccounts()
	        .subscribe(
	           resp => this.handleCustAcctsResp(resp),
	           //error => this.sharedService.handleError(error) //uncomment it later
	           error => this.handleCustAcctsResp(error) //comment it later
	        );
	
	}
	

	//private handleCustAcctsResp(resp:CustomerAccountsResponse){  //uncomment it later
	private handleCustAcctsResp(resp:any){
		this.spinnerService.stopSpinner();
		resp=this.accountsStub1;//comment it later
       if (resp.result.status == "success") {
       		//this.customerAccountsResponse= new CustomerAccountsResponse();
       		this.customerAccountsResponse= resp;
       		if(this.customerAccountsResponse.customerProducts.accounts.length>0){
	       		let account = this.customerAccountsResponse.customerProducts.accounts[0];
	       		this.accountToBeDisplayed(account);
       		}
       		//this.getAccountDetailAndTransactions(); //uncomment it later
       }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
       
    }

    getAccountDetailAndTransactions(){
    	this.getAccountdetail();
    }
    
    getAccountdetail(){
    	let data = {accountId:"1001001000000300"};
		this.accountsService.fetchAccountDetail(data)
	        .subscribe(
	           resp => this.handleAcctDetailResp(resp),
	           error => this.sharedService.handleError(error)
	        );
	
	}
	
	private handleAcctDetailResp(resp:any){
       if (resp.result.status == "success") {
       		console.log(resp);
       }else{

       		console.log(resp.result.status);
       }
       
    }
    
    accountToBeDisplayed(account:any){
    	this.account=account;
    	this.updateCarouselAccounts(account);

    }
    updateCarouselAccounts(account:any){
    	let accountsList =this.customerAccountsResponse.customerProducts.accounts;
    	this.carouselAccountList = accountsList.filter(accountItem => accountItem.number!==account.number);
    }
    carouselAccountSelection(account:any){
    	this.accountToBeDisplayed(account);
    }

}