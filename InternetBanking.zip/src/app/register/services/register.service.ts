import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {AppSession} from '../../shared/model/appSession';
import {AuthRequest} from '../model/authRequest';
import {VerifyCustomerResponse} from '../model/verifyCustomerResponse';
import {RegisterPwdResponse} from '../model/registerPwdResponse';
import {VerifyOtpResponse} from '../../shared/model/verifyOtpResponse';
import {VerifyUsernameResponse} from '../../shared/model/verifyUsernameResponse';
import {ResendOtpResponse} from '../model/resendOtpResponse';
import {AuthKey} from '../../shared/model/authKey';
import {AuthData} from '../../shared/model/authData';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {ErrorService} from '../../shared/services/error.service';
import {SessionContext} from '../../shared/model/sessionContext';
import {GlobalURL} from '../../shared/services/globalURL';


@Injectable()
export class RegisterService {
    
    constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService,
                private errorService: ErrorService) {}

    registerDevice(authRequest: AuthRequest): Observable < AuthData > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.REGISTERDEVICE, authRequest)
                                  .map(resp => this.populateAuthReq(resp));
    }

    verifyCustomer(authRequest: AuthRequest): Observable < VerifyCustomerResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.VERIFYCUSTOMER, authRequest)
                                  .map(resp => this.populateCustResp(resp));
    }

    verifyOtp(authRequest: AuthRequest): Observable < VerifyOtpResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.VERIFYOTP, authRequest)
                                  .map(resp => this.populateOtpResp(resp));
    }

    verifyUsername(authRequest: AuthRequest): Observable < VerifyUsernameResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.VERIFYUSERNAME, authRequest)
                                  .map(resp => JSON.parse(resp));
    }

    resendOtp(): Observable < ResendOtpResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.RESENDOTP, null)
                                  .map(resp => this.populateResendOtpResp(resp));
    }

    registerPwd(authRequest: AuthRequest): Observable < RegisterPwdResponse > {
        console.log(SessionContext.getInstance());
        let pwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, authRequest.pwd);
        authRequest.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.REGISTERPASSWORD, authRequest)
                                  .map(resp => this.populatePwdRegisterResp(resp));
    }

    verifyLogin(authRequest: AuthRequest): Observable < RegisterPwdResponse > {
        let pwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, authRequest.pwd);
        authRequest.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOGIN.VERIFYLOGIN, authRequest)
                                  .map(resp => this.populateLoginResp(resp));
    }

    saveAuthenticationMethod(authRequest: AuthRequest): Observable < RegisterPwdResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOGIN.AUTHENTICATIONMETHOD, authRequest)
                                  .map(resp => this.populateAuthenticationMethodResp(resp));
    }

    /*
    * registerDevice Handler
    */
    private populateAuthReq(resp: string) {
        var authData = new AuthData();
        let respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            authData.authKey = new AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            var sessCtx = SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
        return authData;
    }
    /*
    * verifyCustomer Handler
    */
    private populateCustResp(resp: string) {
        let respObj = JSON.parse(resp);
        if(respObj.result.status == 'success'){
            let responseObj = new VerifyCustomerResponse();
            SessionContext.getInstance().userID = respObj.cif;
            responseObj.otpDuration = respObj.otpDuration;
            responseObj.convID = respObj.convID;
            responseObj.cif = respObj.cif;
            responseObj.emailMasked = respObj.emailMasked;
            responseObj.mobileNumberMasked = respObj.mobileNumberMasked;
            responseObj.remainingOtpAttempts = respObj.remainingOtpAttempts;
            return responseObj;
        }else if(respObj.result.status == 'error'){
            this.errorService.setErrorResp(respObj.result);
        }
    }
    /*
    * verifyOtp Handler
    */
    private populateOtpResp(resp: string) {
        let respObj = JSON.parse(resp);
        if(respObj.result.status == 'success'){
            var responseObj = new VerifyOtpResponse();
            responseObj.userName = respObj.userName;
            return responseObj;
        }else if(respObj.result.status == 'error'){
            this.errorService.setErrorResp(respObj.result);
        }        
    }

    private populatePwdRegisterResp(resp: string) {
        var respObj = JSON.parse(resp);
        if(respObj.result.status == 'success'){
            this.updateSessionContext(respObj);        
            var responseObj = new RegisterPwdResponse();
            responseObj = respObj;
            return responseObj;
        }else if(respObj.result.status == 'error'){
            this.errorService.setErrorResp(respObj.result);
        }
    }

    private populateLoginResp(resp: string){
        var respObj = JSON.parse(resp);
        if(respObj.result.status == 'success'){ 
            this.updateSessionContext(respObj);
            var responseObj = new RegisterPwdResponse();
            responseObj = respObj;
            console.log("res " + responseObj);
            return responseObj;
        }else if(respObj.result.status == 'error'){
            this.errorService.setErrorResp(respObj.result);
        }
    }

    private populateAuthenticationMethodResp(resp: string){
        var respObj = JSON.parse(resp);
        if(respObj.result.status == 'success'){
            var responseObj = new RegisterPwdResponse();
            responseObj = respObj;
            return responseObj;
        }else if(respObj.result.status == 'error'){
            this.errorService.setErrorResp(respObj.result);
        }
    }
    
    private updateSessionContext(respObj: any){
        if (respObj.result.status == 'success') {
            var authData = new AuthData();
            authData.authKey = new AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            var sessCtx = SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
    }

    private populateResendOtpResp(resp: string) {
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new ResendOtpResponse();
        console.log("res " + respObj.result.success);
        responseObj.result.status = respObj.result.status;
        return responseObj;
    }
}