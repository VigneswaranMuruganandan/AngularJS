"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
require("rxjs/add/operator/toPromise");
var verifyCustomerResponse_1 = require("../model/verifyCustomerResponse");
var registerPwdResponse_1 = require("../model/registerPwdResponse");
var verifyOtpResponse_1 = require("../../shared/model/verifyOtpResponse");
var resendOtpResponse_1 = require("../model/resendOtpResponse");
var authKey_1 = require("../../shared/model/authKey");
var authData_1 = require("../../shared/model/authData");
var serviceInvoker_service_1 = require("../../shared/connector/serviceInvoker.service");
var encryption_service_1 = require("../../shared/services/encryption.service");
var error_service_1 = require("../../shared/services/error.service");
var sessionContext_1 = require("../../shared/model/sessionContext");
var globalURL_1 = require("../../shared/services/globalURL");
var RegisterService = (function () {
    function RegisterService(serviceInvoker, encryptionService, errorService) {
        this.serviceInvoker = serviceInvoker;
        this.encryptionService = encryptionService;
        this.errorService = errorService;
    }
    RegisterService.prototype.registerDevice = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.REGISTERDEVICE, authRequest)
            .map(function (resp) { return _this.populateAuthReq(resp); });
    };
    RegisterService.prototype.verifyCustomer = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.VERIFYCUSTOMER, authRequest)
            .map(function (resp) { return _this.populateCustResp(resp); });
    };
    RegisterService.prototype.verifyOtp = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.VERIFYOTP, authRequest)
            .map(function (resp) { return _this.populateOtpResp(resp); });
    };
    RegisterService.prototype.verifyUsername = function (authRequest) {
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.VERIFYUSERNAME, authRequest)
            .map(function (resp) { return JSON.parse(resp); });
    };
    RegisterService.prototype.resendOtp = function () {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.RESENDOTP, null)
            .map(function (resp) { return _this.populateResendOtpResp(resp); });
    };
    RegisterService.prototype.registerPwd = function (authRequest) {
        var _this = this;
        console.log(sessionContext_1.SessionContext.getInstance());
        var pwdHash = this.encryptionService.generatePwdHash(sessionContext_1.SessionContext.getInstance().userID, authRequest.pwd);
        authRequest.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.REGISTERPASSWORD, authRequest)
            .map(function (resp) { return _this.populatePwdRegisterResp(resp); });
    };
    RegisterService.prototype.verifyLogin = function (authRequest) {
        var _this = this;
        var pwdHash = this.encryptionService.generatePwdHash(sessionContext_1.SessionContext.getInstance().userID, authRequest.pwd);
        authRequest.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.LOGIN.VERIFYLOGIN, authRequest)
            .map(function (resp) { return _this.populateLoginResp(resp); });
    };
    RegisterService.prototype.saveAuthenticationMethod = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.LOGIN.AUTHENTICATIONMETHOD, authRequest)
            .map(function (resp) { return _this.populateAuthenticationMethodResp(resp); });
    };
    /*
    * registerDevice Handler
    */
    RegisterService.prototype.populateAuthReq = function (resp) {
        var authData = new authData_1.AuthData();
        var respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            authData.authKey = new authKey_1.AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            var sessCtx = sessionContext_1.SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
        return authData;
    };
    /*
    * verifyCustomer Handler
    */
    RegisterService.prototype.populateCustResp = function (resp) {
        var respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            var responseObj = new verifyCustomerResponse_1.VerifyCustomerResponse();
            sessionContext_1.SessionContext.getInstance().userID = respObj.cif;
            responseObj.otpDuration = respObj.otpDuration;
            responseObj.convID = respObj.convID;
            responseObj.cif = respObj.cif;
            responseObj.emailMasked = respObj.emailMasked;
            responseObj.mobileNumberMasked = respObj.mobileNumberMasked;
            responseObj.remainingOtpAttempts = respObj.remainingOtpAttempts;
            return responseObj;
        }
        else if (respObj.result.status == 'error') {
            this.errorService.setErrorResp(respObj.result);
        }
    };
    /*
    * verifyOtp Handler
    */
    RegisterService.prototype.populateOtpResp = function (resp) {
        var respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            var responseObj = new verifyOtpResponse_1.VerifyOtpResponse();
            responseObj.userName = respObj.userName;
            return responseObj;
        }
        else if (respObj.result.status == 'error') {
            this.errorService.setErrorResp(respObj.result);
        }
    };
    RegisterService.prototype.populatePwdRegisterResp = function (resp) {
        var respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            this.updateSessionContext(respObj);
            var responseObj = new registerPwdResponse_1.RegisterPwdResponse();
            responseObj = respObj;
            return responseObj;
        }
        else if (respObj.result.status == 'error') {
            this.errorService.setErrorResp(respObj.result);
        }
    };
    RegisterService.prototype.populateLoginResp = function (resp) {
        var respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            this.updateSessionContext(respObj);
            var responseObj = new registerPwdResponse_1.RegisterPwdResponse();
            responseObj = respObj;
            console.log("res " + responseObj);
            return responseObj;
        }
        else if (respObj.result.status == 'error') {
            this.errorService.setErrorResp(respObj.result);
        }
    };
    RegisterService.prototype.populateAuthenticationMethodResp = function (resp) {
        var respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            var responseObj = new registerPwdResponse_1.RegisterPwdResponse();
            responseObj = respObj;
            return responseObj;
        }
        else if (respObj.result.status == 'error') {
            this.errorService.setErrorResp(respObj.result);
        }
    };
    RegisterService.prototype.updateSessionContext = function (respObj) {
        if (respObj.result.status == 'success') {
            var authData = new authData_1.AuthData();
            authData.authKey = new authKey_1.AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            var sessCtx = sessionContext_1.SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
    };
    RegisterService.prototype.populateResendOtpResp = function (resp) {
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new resendOtpResponse_1.ResendOtpResponse();
        console.log("res " + respObj.result.success);
        responseObj.result.status = respObj.result.status;
        return responseObj;
    };
    RegisterService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [serviceInvoker_service_1.ServiceInvoker,
            encryption_service_1.EncryptionService,
            error_service_1.ErrorService])
    ], RegisterService);
    return RegisterService;
}());
exports.RegisterService = RegisterService;
//# sourceMappingURL=register.service.js.map