"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CustomerData = (function () {
    function CustomerData() {
    }
    return CustomerData;
}());
exports.CustomerData = CustomerData;
//# sourceMappingURL=customerData.js.map