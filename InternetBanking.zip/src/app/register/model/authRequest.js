"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AuthRequest = (function () {
    function AuthRequest() {
    }
    return AuthRequest;
}());
exports.AuthRequest = AuthRequest;
//# sourceMappingURL=authRequest.js.map