import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {CustomerData} from '../model/customerData';
import {TemplateService} from '../../shared/services/template.service';

/*
* Customer Identification validation for Registration
*/
@Directive({
    selector: '[ValidateRegisterDirective]',
})
export class ValidateCustomerIdentificationRegister {
    private x = require('jquery-validator');
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let registrationCusIDValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var registrationCusIDValidation = (<any>$("#registrationCusIDForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    customerIdentificationNo: {
                        required: true
                    }
                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    }
                }
            });
            registrationCusIDValidationSubmit = registrationCusIDValidation.form();
            this.templateService.setFormValidatorFlag(registrationCusIDValidationSubmit);
        });
    }
}

/*
* Username validation for Registration
*/
@Directive({
    selector: '[ValidateUsernameRegDirective]',
})
export class ValidateUsernameRegister {
    private x = require('jquery-validator');
    @Output() usernameValidationsEvent = new EventEmitter();
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {

    }
    @HostListener('keyup', ['$event'])
    onKeyUp(event: KeyboardEvent) { 
        let e = <KeyboardEvent> event;
        let registrationUsernameSubmit;
        this.zone.runOutsideAngular(() => {

            (<any>jQuery).validator.addMethod("usernameLength", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regx6to16 = new RegExp("^.{6,16}$"),
                    flag = regx6to16.test(value);
                    if(flag){
                        $('.validate li:eq(0)').addClass('success');
                        $('.validate li:eq(0)').removeClass('error');
                    }else{
                        $('.validate li:eq(0)').addClass('error');
                        $('.validate li:eq(0)').removeClass('success');                        
                    }
                }
                return flag;
            });
            (<any>jQuery).validator.addMethod("atleast1Alphabetic", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regx1alphabetic = new RegExp("(.*[a-zA-Z]){1}"),
                    flag = regx1alphabetic.test(value);
                    if(flag){
                        $('.validate li:eq(1)').addClass('success');
                        $('.validate li:eq(1)').removeClass('error');
                    }else{
                        $('.validate li:eq(1)').addClass('error');
                        $('.validate li:eq(1)').removeClass('success');                        
                    }
                }
                return flag;
            });
            (<any>jQuery).validator.addMethod("validateSpecialCharacters", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regxSpecialCharacters = new RegExp("^[^!#%^&\\<>\/]+$"),
                    flag = regxSpecialCharacters.test(value);
                    if(flag){
                        $('.validate li:eq(2)').addClass('success');
                        $('.validate li:eq(2)').removeClass('error');
                    }else{
                        $('.validate li:eq(2)').addClass('error');
                        $('.validate li:eq(2)').removeClass('success');                        
                    }
                }
                return flag;
            });
            var registrationUsernameValidation = (<any>$("#usernameRegisterForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    username: {
                        required: function(){
                            $('.validate li:eq(0)').removeAttr('class');
                            $('.validate li:eq(1)').removeAttr('class');
                            $('.validate li:eq(2)').removeAttr('class');
                            return true;
                        },
                        usernameLength: true,
                        atleast1Alphabetic: true,
                        validateSpecialCharacters: true
                    }
                },
                messages: {
                    username: {
                        required: "Please fill",
                        usernameLength: "",
                        atleast1Alphabetic: "",
                        validateSpecialCharacters: ""
                    }
                }
            });
            registrationUsernameSubmit = registrationUsernameValidation.form();            
            this.usernameValidationsEvent.emit(registrationUsernameSubmit);
        });
    }
}

/*
* Password validation for Registration
*/
@Directive({
    selector: '[ValidatePasswordRegDirective]',
})
export class ValidatePasswordRegister {
    private x = require('jquery-validator');
    @Output() passwordValidationsEvent = new EventEmitter();
    @Input() customerData: CustomerData;

    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {

    }
    @HostListener('keyup', ['$event'])
    onKeyUp(event: KeyboardEvent) { 
        let e = <KeyboardEvent> event;
        let registrationPasswordSubmit;
        this.zone.runOutsideAngular(() => {

        	(<any>jQuery).validator.addMethod("matchUsername", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    flag = (value != param.userName) ? true : false;
                }
                return flag;
            });
            (<any>jQuery).validator.addMethod("passwordLength", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regx6to16 = new RegExp("^.{6,16}$"),
                    flag = regx6to16.test(value);
                    if(flag){
                        $('.validate li:eq(0)').addClass('success');
                        $('.validate li:eq(0)').removeClass('error');
                    }else{
                        $('.validate li:eq(0)').addClass('error');
                        $('.validate li:eq(0)').removeClass('success');                        
                    }
                }
                return flag;
            });
            (<any>jQuery).validator.addMethod("atleast1Alphabetic", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regx1alphabetic = new RegExp("(.*[a-zA-Z]){1}"),
                    flag = regx1alphabetic.test(value);
                    if(flag){
                        $('.validate li:eq(1)').addClass('success');
                        $('.validate li:eq(1)').removeClass('error');
                    }else{
                        $('.validate li:eq(1)').addClass('error');
                        $('.validate li:eq(1)').removeClass('success');                        
                    }
                }
                return flag;
            });
            (<any>jQuery).validator.addMethod("validateSpecialCharacters", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    var regxSpecialCharacters = new RegExp("^[^!#%^&\\<>\/]+$"),
                    flag = regxSpecialCharacters.test(value);
                    if(flag){
                        $('.validate li:eq(2)').addClass('success');
                        $('.validate li:eq(2)').removeClass('error');
                    }else{
                        $('.validate li:eq(2)').addClass('error');
                        $('.validate li:eq(2)').removeClass('success');                        
                    }
                }
                return flag;
            });
            var registrationPasswordValidation = (<any>$("#passwordRegisterForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    password: {
                        required: function(){
                            $('.validate li:eq(0)').removeAttr('class');
                            $('.validate li:eq(1)').removeAttr('class');
                            $('.validate li:eq(2)').removeAttr('class');
                            return true;
                        },
                        matchUsername: this.customerData,
                        passwordLength: true,
                        atleast1Alphabetic: true,
                        validateSpecialCharacters: true
                    }
                },
                messages: {
                    password: {
                        required: "Please fill",
                        matchUsername: "Password should not match with username",
                        passwordLength: "",
                        atleast1Alphabetic: "",
                        validateSpecialCharacters: ""
                    }
                }
            });
            registrationPasswordSubmit = registrationPasswordValidation.form();            
            this.passwordValidationsEvent.emit(registrationPasswordSubmit);
            this.templateService.setFormValidatorFlag(registrationPasswordSubmit);
        });
    }
}

/*
* ConfirmPassword validation for Registration
*/
@Directive({
    selector: '[ValidateConfirmPasswordDirective]',
})
export class ValidateConfirmPasswordRegister {
    private x = require('jquery-validator');
    @Input() passwordData: any;
    
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}

    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let registrationConfirmPasswordValidationSubmit;
        this.zone.runOutsideAngular(() => {


            (<any>jQuery).validator.addMethod("comparePassword", 
            function (value :any, element :any, param :any) {
                var flag = false;
                (param.password == param.confirmPassword) ? (flag = true) : (flag = false);                   
                return flag;
            });


            var registrationConfirmPasswordValidation = (<any>$("#confirmPasswordForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    confirmPassword: {
                        required: true,
                        comparePassword: this.passwordData
                    }
                },
                messages: {
                    confirmPassword: {
                        required: "Please Confirm the Password once again",
                        comparePassword: "Please enter the same password"
                    }
                }
            });
            registrationConfirmPasswordValidation.settings.rules.confirmPassword.comparePassword = this.passwordData;
            registrationConfirmPasswordValidationSubmit = registrationConfirmPasswordValidation.form();
            this.templateService.setFormValidatorFlag(registrationConfirmPasswordValidationSubmit);
        });
    }
}