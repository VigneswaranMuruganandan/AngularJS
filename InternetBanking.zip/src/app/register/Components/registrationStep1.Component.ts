import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'registrationstep1-component',
  templateUrl: './../templates/registrationStep1.html'
})
export class RegistrationStep1Component {
	@Output() validateCustomerIdentificationEvent = new EventEmitter();
	@Output() ViewRegisterTermsandConditionsEvent = new EventEmitter();
	
	private customerID:string;

	constructor( private templateService: TemplateService,
				private errorService: ErrorService) {}

	validateCustomer(valid: boolean){
		console.log(" customerID:" + this.customerID);
		if(valid){
			this.templateService.resetFormValidatorFlag();
			this.errorService.resetErrorResp();
			this.validateCustomerIdentificationEvent.emit(this.customerID);	
		}
	}

	viewTermsandConds(){
		this.ViewRegisterTermsandConditionsEvent.emit(this.customerID);
	}
}



