import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {CustomerData} from '../model/customerData';
import {TemplateService} from '../../shared/services/template.service';
import { SpinnerService} from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';

@Component({
  selector: 'registrationstep4-component',
  templateUrl: './../templates/registrationStep4.html'
})
export class RegistrationStep4Component implements OnInit{
	public showConfirmPassword: boolean;
	@Input() validPasswordFlag: boolean;
	@Output() validateRegistrationPasswordEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	public passwordData : any;

	constructor( private templateService: TemplateService,
				 private errorService: ErrorService,
				 private spinnerService: SpinnerService) {}

	ngOnInit() {
		this.passwordData = {"password":"","confirmPassword":""};
		this.showConfirmPassword = false;
		this.spinnerService.stopSpinner();
	}

	passwordValidations(flag: boolean){
		this.validPasswordFlag = flag;
	}

	validatePassword(){
		if(this.validPasswordFlag){
			this.errorService.resetErrorResp();
			this.showConfirmPassword=true;
		}		
	}
	
	validateConfirmPassword(valid: boolean){
		if(valid){
			this.templateService.resetFormValidatorFlag();
			this.validateRegistrationPasswordEvent.emit(this.passwordData.password);
		}
	}
}