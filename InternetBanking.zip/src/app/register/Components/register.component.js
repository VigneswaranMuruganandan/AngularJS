"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var register_service_1 = require("../services/register.service");
var shared_service_1 = require("../../shared/services/shared.service");
var spinner_service_1 = require("../../shared/services/spinner.service");
var error_service_1 = require("../../shared/services/error.service");
var sessionContext_1 = require("../../shared/model/sessionContext");
var authRequest_1 = require("../model/authRequest");
var customerData_1 = require("../model/customerData");
var router_1 = require("@angular/router");
var RegisterComponent = (function () {
    function RegisterComponent(registerService, sharedService, spinnerService, errorService, router) {
        this.registerService = registerService;
        this.sharedService = sharedService;
        this.spinnerService = spinnerService;
        this.errorService = errorService;
        this.router = router;
    }
    RegisterComponent.prototype.ngOnInit = function () {
        this.stepFlag = 3;
        this.validUsername = false;
        this.customerData = new customerData_1.CustomerData();
    };
    RegisterComponent.prototype.ViewRegisterTermsandConditions = function () {
    };
    /*
    * Step 1: Register the Device ID
    */
    RegisterComponent.prototype.validateCustomerIdentification = function (customerID) {
        var _this = this;
        this.spinnerService.startSpinner();
        this.customerData.customerID = customerID;
        var registerDeviceData = this.sharedService.setupAuthKeys();
        console.log("Register Device Data ::" + registerDeviceData);
        if (registerDeviceData && registerDeviceData.deviceID != null) {
            this.sharedService.registerDevice(registerDeviceData)
                .subscribe(function (resp) { return _this.handleRegisterDeviceDataResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
        }
        else {
            var sessCtx = sessionContext_1.SessionContext.getInstance();
            this.handleRegisterDeviceDataResp(sessCtx);
        }
    };
    /*
    * Step 2: Verify the customer ID to get the CIF number
    */
    RegisterComponent.prototype.handleRegisterDeviceDataResp = function (resp) {
        var _this = this;
        if (resp.authKey && resp.authKey.convID != null) {
            console.log("validating customer identification " + this.customerData.customerID);
            var data = new authRequest_1.AuthRequest();
            data.customerID = this.customerData.customerID;
            this.registerService.verifyCustomer(data)
                .subscribe(function (resp) { return _this.handleVerifyCustIDResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
        }
    };
    /*
    * Handle the Response of Verify Customer ID
    * to get Mobile number and email and move to OTP Page
    */
    RegisterComponent.prototype.handleVerifyCustIDResp = function (resp) {
        this.spinnerService.stopSpinner();
        if (resp) {
            console.log('handleVerifyCustIDResp ' + resp);
            this.stepFlag = 2;
            this.customerData.mobileNumber = resp.mobileNumberMasked;
            this.customerData.emailID = resp.emailMasked;
        }
    };
    /*
    * Step 3: Verify the OTP
    */
    RegisterComponent.prototype.validateRegistrationOTP = function (otp) {
        var _this = this;
        console.log("validating OTP " + otp);
        this.spinnerService.startSpinner();
        var data = new authRequest_1.AuthRequest();
        data.otp = otp;
        this.registerService.verifyOtp(data)
            .subscribe(function (resp) { return _this.handleVerifyOtpResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    /*
    * Handle the Verify OTP Response
    */
    RegisterComponent.prototype.handleVerifyOtpResp = function (resp) {
        this.spinnerService.stopSpinner();
        if (resp) {
            this.customerData.name = resp.userName;
            this.stepFlag = 3;
        }
    };
    /*
    * Verify the Username
    */
    RegisterComponent.prototype.validateRegistrationUsername = function (userName) {
        var _this = this;
        this.spinnerService.startSpinner();
        this.customerData.userName = userName;
        var data = new authRequest_1.AuthRequest();
        data.userName = userName;
        this.registerService.verifyUsername(data)
            .subscribe(function (resp) { return _this.handleVerifyUsernameResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    /*
    * Handle the username servcie response
    */
    RegisterComponent.prototype.handleVerifyUsernameResp = function (resp) {
        this.spinnerService.stopSpinner();
        if (resp && resp.result.status == 'success') {
            this.stepFlag = 4;
        }
        else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    };
    /*
    * Step 4: Register the  Username and Hashed Password
    */
    RegisterComponent.prototype.validateRegistrationPassword = function (pwd) {
        var _this = this;
        console.log("validating Password " + pwd);
        this.spinnerService.startSpinner();
        this.customerData.pwd = pwd;
        var data = new authRequest_1.AuthRequest();
        data.pwd = pwd;
        data.userName = this.customerData.userName;
        this.registerService.registerPwd(data)
            .subscribe(function (resp) { return _this.handleVerifyPwdResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    /*
    * Step 5: Verify the Username and Hashed Password
    */
    RegisterComponent.prototype.handleVerifyPwdResp = function (resp) {
        var _this = this;
        console.log('handleVerifyPwdResp ' + resp);
        if (resp && resp.result.status == "success") {
            var data = new authRequest_1.AuthRequest();
            data.userName = this.customerData.userName;
            data.pwd = this.customerData.pwd;
            this.registerService.verifyLogin(data)
                .subscribe(function (resp) { return _this.handleLoginResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
        }
    };
    /*
    * Handle the verify Login based on actions
    */
    RegisterComponent.prototype.handleLoginResp = function (resp) {
        this.spinnerService.stopSpinner();
        if (resp && resp.result.status == 'success') {
            if (resp.action[0] == 'VIEW_SECOND_FACTOR') {
                this.stepFlag = 5;
            }
        }
    };
    /*
    * Based on Action, if VIEW_SECOND_FACTOR,
    * Save the Authentication Method and take the user to dashboard
    */
    RegisterComponent.prototype.saveRegistration = function (authenticationMethod) {
        var _this = this;
        this.spinnerService.startSpinner();
        var data = new authRequest_1.AuthRequest();
        data.otpMethod = authenticationMethod;
        this.registerService.saveAuthenticationMethod(data)
            .subscribe(function (resp) { return _this.handleVerifyAuthenticationResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    RegisterComponent.prototype.handleVerifyAuthenticationResp = function (resp) {
        this.spinnerService.stopSpinner();
        if (resp && resp.result.status == 'success') {
            this.router.navigate(['/dashboard']);
        }
    };
    RegisterComponent = __decorate([
        core_1.Component({
            templateUrl: './../templates/register.html'
        }),
        __metadata("design:paramtypes", [register_service_1.RegisterService,
            shared_service_1.SharedService,
            spinner_service_1.SpinnerService,
            error_service_1.ErrorService,
            router_1.Router])
    ], RegisterComponent);
    return RegisterComponent;
}());
exports.RegisterComponent = RegisterComponent;
//# sourceMappingURL=register.component.js.map