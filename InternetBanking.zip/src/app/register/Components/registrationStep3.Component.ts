import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {CustomerData} from '../model/customerData';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'registrationstep3-component',
  templateUrl: './../templates/registrationStep3.html'
})
export class RegistrationStep3Component{
	@Input() validUsernameFlag: boolean;
	@Output() validateRegistrationUsernameEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	private userName:string;
	
	constructor( private errorService: ErrorService ){}

    usernameValidations(flag :boolean){
    	this.validUsernameFlag = flag;
    }

	validateUsername(valid: boolean){
		if(valid){
			this.errorService.resetErrorResp();
			this.validateRegistrationUsernameEvent.emit(this.userName);
		}		
	}
}