"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var NickNameReq = (function () {
    function NickNameReq() {
    }
    return NickNameReq;
}());
exports.NickNameReq = NickNameReq;
//# sourceMappingURL=nickNameReq.js.map