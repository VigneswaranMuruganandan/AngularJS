"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var $ = require("jquery");
var template_service_1 = require("../../shared/services/template.service");
/*
* Personal Information Email Update for Registration
*/
var ValidatePersonalInfo = (function () {
    function ValidatePersonalInfo(el, zone, templateService) {
        this.el = el;
        this.zone = zone;
        this.templateService = templateService;
        this.x = require('jquery-validator');
    }
    ValidatePersonalInfo.prototype.ngAfterViewInit = function () {
    };
    ValidatePersonalInfo.prototype.onClick = function (event) {
        var _this = this;
        var el = $(this.el.nativeElement);
        var personalInfoValidationSubmit;
        this.zone.runOutsideAngular(function () {
            var personalInfoValidation = $("#personalInfoForm").validate({
                highlight: function (element) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function (element, errorClass) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function (error, element) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    email: {
                        required: true,
                        email: true
                    }
                },
                messages: {
                    email: {
                        required: "Please enter the email ID to be updated",
                        email: "Please enter valid email ID"
                    }
                }
            });
            personalInfoValidationSubmit = personalInfoValidation.form();
            _this.templateService.setFormValidatorFlag(personalInfoValidationSubmit);
        });
    };
    __decorate([
        core_1.HostListener('click', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], ValidatePersonalInfo.prototype, "onClick", null);
    ValidatePersonalInfo = __decorate([
        core_1.Directive({
            selector: '[ValidatePersonalInfoDirective]',
        }),
        __metadata("design:paramtypes", [core_1.ElementRef, core_1.NgZone, template_service_1.TemplateService])
    ], ValidatePersonalInfo);
    return ValidatePersonalInfo;
}());
exports.ValidatePersonalInfo = ValidatePersonalInfo;
//# sourceMappingURL=validateAccountSettings.directive.js.map