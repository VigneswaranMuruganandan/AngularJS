"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var accountSettings_routing_1 = require("./accountSettings.routing");
var core_2 = require("@ngx-translate/core");
var shared_module_1 = require("../shared/shared.module");
var shared_service_1 = require("../shared/services/shared.service");
var template_service_1 = require("../shared/services/template.service");
var forms_1 = require("@angular/forms");
var accountSettings_component_1 = require("./Components/accountSettings.component");
var personalInformation_component_1 = require("./Components/personalInformation.component");
var myAccounts_component_1 = require("./Components/myAccounts.component");
var myCards_component_1 = require("./Components/myCards.component");
var myAlerts_component_1 = require("./Components/myAlerts.component");
var estatementModal_component_1 = require("./Components/estatementModal.component");
var accounts_service_1 = require("../accounts/services/accounts.service");
var accountSettings_service_1 = require("./services/accountSettings.service");
var validateAccountSettings_directive_1 = require("./directives/validateAccountSettings.directive");
var ACCOLUNTSETTINGS_COMPONENTS = [
    accountSettings_component_1.AccountSettingsComponent,
    personalInformation_component_1.PersonalInformationComponent,
    myAccounts_component_1.MyAccountsComponent,
    myCards_component_1.MyCardsComponent,
    myAlerts_component_1.MyAlertsComponent,
    estatementModal_component_1.EStatementModalComponent
];
var ACCOLUNTSETTINGS_PROVIDERS = [
    shared_service_1.SharedService,
    template_service_1.TemplateService,
    accounts_service_1.AccountsService,
    accountSettings_service_1.AccountSettingsService
];
var ACCOLUNTSETTINGS_DIRECTIVES = [
    validateAccountSettings_directive_1.ValidatePersonalInfo
];
var AccountSettingsModule = (function () {
    function AccountSettingsModule() {
    }
    AccountSettingsModule = __decorate([
        core_1.NgModule({
            imports: [
                accountSettings_routing_1.routing,
                core_2.TranslateModule.forChild(),
                shared_module_1.SharedModule,
                forms_1.FormsModule,
                common_1.CommonModule
            ],
            declarations: ACCOLUNTSETTINGS_COMPONENTS.concat(ACCOLUNTSETTINGS_DIRECTIVES),
            providers: ACCOLUNTSETTINGS_PROVIDERS.slice()
        })
    ], AccountSettingsModule);
    return AccountSettingsModule;
}());
exports.AccountSettingsModule = AccountSettingsModule;
//# sourceMappingURL=accountSettings.module.js.map