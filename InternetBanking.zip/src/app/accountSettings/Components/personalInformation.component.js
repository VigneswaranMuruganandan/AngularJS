"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/map");
var template_service_1 = require("../../shared/services/template.service");
var accountSettings_service_1 = require("../services/accountSettings.service");
var error_service_1 = require("../../shared/services/error.service");
var shared_service_1 = require("../../shared/services/shared.service");
var PersonalInformationComponent = (function () {
    function PersonalInformationComponent(templateService, errorService, sharedService, accountSettingsService) {
        this.templateService = templateService;
        this.errorService = errorService;
        this.sharedService = sharedService;
        this.accountSettingsService = accountSettingsService;
    }
    PersonalInformationComponent.prototype.ngOnInit = function () {
        this.email = this.userProfileDetails.email;
        this.editEmail = false;
    };
    PersonalInformationComponent.prototype.editUserEmailId = function () {
        this.editEmail = true;
    };
    PersonalInformationComponent.prototype.cancelUserEmailId = function () {
        $("#personalInfoForm").validate().resetForm();
        this.email = this.userProfileDetails.email;
        this.editEmail = false;
    };
    PersonalInformationComponent.prototype.saveEamilId = function (valid) {
        var _this = this;
        if (valid) {
            var data = { "email": this.email };
            this.accountSettingsService.updateEmailID(data)
                .subscribe(function (resp) { return _this.handleUpdateEmailIDResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
        }
    };
    PersonalInformationComponent.prototype.handleUpdateEmailIDResp = function (resp) {
        if (resp && resp.result.status == 'success') {
            console.log("updated the emamil id");
            this.editEmail = false;
        }
        else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], PersonalInformationComponent.prototype, "userProfileDetails", void 0);
    PersonalInformationComponent = __decorate([
        core_1.Component({
            selector: 'personalinformation-component',
            templateUrl: './../templates/personalInformation.html'
        }),
        __metadata("design:paramtypes", [template_service_1.TemplateService,
            error_service_1.ErrorService,
            shared_service_1.SharedService,
            accountSettings_service_1.AccountSettingsService])
    ], PersonalInformationComponent);
    return PersonalInformationComponent;
}());
exports.PersonalInformationComponent = PersonalInformationComponent;
//# sourceMappingURL=personalInformation.component.js.map