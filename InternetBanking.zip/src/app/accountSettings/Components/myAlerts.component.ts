import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'myalerts-component',
  templateUrl: './../templates/myAlerts.html'
})
export class MyAlertsComponent {

}