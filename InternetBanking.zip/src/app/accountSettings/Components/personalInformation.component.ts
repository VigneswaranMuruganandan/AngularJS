import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { TemplateService } from '../../shared/services/template.service';
import { AccountSettingsService } from '../services/accountSettings.service';
import { APIResponse } from '../../shared/model/apiResponse';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';

@Component({
  selector: 'personalinformation-component',
  templateUrl: './../templates/personalInformation.html'
})
export class PersonalInformationComponent implements OnInit{
	@Input() userProfileDetails:any;
	email : string;
	editEmail : boolean;

	constructor( private templateService: TemplateService,
				 private errorService: ErrorService,
				 private sharedService: SharedService,
				 private accountSettingsService: AccountSettingsService) {}

	ngOnInit() {
        this.email = this.userProfileDetails.email;
        this.editEmail = false;
    }
	editUserEmailId(){
		this.editEmail = true;
	}

	cancelUserEmailId(){
		(<any>$("#personalInfoForm")).validate().resetForm();
		this.email = this.userProfileDetails.email
		this.editEmail = false;
	}

	saveEamilId(valid: boolean){
		if(valid){
			let data = { "email":this.email };
			this.accountSettingsService.updateEmailID(data)
	        .subscribe(
	           resp => this.handleUpdateEmailIDResp(resp),
	           error => this.sharedService.handleError(error) 
	        );
		}		
	}

	handleUpdateEmailIDResp(resp: APIResponse){
		if(resp && resp.result.status == 'success'){
            console.log("updated the emamil id");
            this.editEmail = false;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}
}