"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/map");
var accounts_service_1 = require("../../accounts/services/accounts.service");
var error_service_1 = require("../../shared/services/error.service");
var spinner_service_1 = require("../../shared/services/spinner.service");
var shared_service_1 = require("../../shared/services/shared.service");
var customerAccountsResponse_1 = require("../../accounts/model/customerAccountsResponse");
var userContext_1 = require("../../shared/model/userContext");
var AccountSettingsComponent = (function () {
    function AccountSettingsComponent(accountsService, sharedService, errorService, spinnerService) {
        this.accountsService = accountsService;
        this.sharedService = sharedService;
        this.errorService = errorService;
        this.spinnerService = spinnerService;
        /*STUBS START*/
        this.accountsStub1 = { "result": { "status": "success" }, "favouriteProducts": {},
            "customerProducts": {
                "accounts": [{ "productName": "Current Account", "number": "1001001006860493", "balance": { "value": 122121, "valueFmt": "16,334,817.50", "currency": "AED" }, "accountCurrency": "AED", "holderName": "FGB SCRAMBLE NAME-", "currentBalance": { "value": 1.63348176635E10, "valueFmt": "16,334,817,663.50", "currency": "AED" }, "accountType": "CH", "productType": "CH", "nickName": "Sridhar", "isFavourite": true }, { "productName": "Current Account", "number": "1001001006860517", "balance": { "value": 4334.9, "valueFmt": "4,334.90", "currency": "AED" }, "accountCurrency": "AED", "holderName": "FGB SCRAMBLE", "currentBalance": { "value": 4334.9, "valueFmt": "4,334.90", "currency": "AED" }, "accountType": "CH", "productType": "CH", "nickName": "Current Account", "isFavourite": true }, { "productName": "Current Account", "number": "1011001006860110", "balance": { "value": 2.46648955491898E12, "valueFmt": "2,466,489.98", "currency": "USD" }, "accountCurrency": "USD", "holderName": "FGB SCRAMBLE NAME-1", "currentBalance": { "value": 2.46648955491898E12, "valueFmt": "2,466,489.98", "currency": "USD" }, "accountType": "CH", "productType": "CH", "nickName": "Current Account", "isFavourite": false }],
                "loans": [{ "loanNumber": "MG1319900068", "availableBal": -204866.79, "ledgerBal": -204866.79, "currency": "USD", "holderName": "WM INVESTMENTS", "type": "LN", "purpose": "Loan" }, { "loanNumber": "MG1413400059", "availableBal": -51677.17, "ledgerBal": -51677.17, "currency": "USD", "holderName": "WM INVESTMENTS", "type": "LN", "purpose": "Loan" }],
                "cards": [{ "cardNumber": "4002910001077114", "cardHolderName": "Faxon", "cardType": "P", "status": "A", "ownerType": "P", "cardLimit": 120000.0, "availableCashWithdrawalLimit": 14000.0, "availableBalance": 85000.0, "currentTotalOutstanding": 500000.0, "outstandingBalance": 500000.0, "minimumPaymentDue": 0.0, "paymentDueDate": 1426017600000, "nextStatementDate": 1429041600000, "greenContributionAmount": 0.0, "currency": "AED" }],
                "deposits": [{ "productName": "Term Deposit", "number": "MM1424400004", "balance": { "value": 25000.0, "valueFmt": "25,000.00", "currency": "CHF" }, "accountCurrency": "CHF", "holderName": "FIXED DEPOSITS", "currentBalance": { "value": 25000.0, "valueFmt": "25,000.00", "currency": "CHF" }, "accountType": "TD", "productType": "TD" }]
            } };
    }
    AccountSettingsComponent.prototype.ngOnInit = function () {
        this.spinnerService.startSpinner();
        this.userDetails = userContext_1.UserContext.getInstance().userDetails;
        //{"salutation":"M/S","name":"XXXZ-UL-HAQ KHOKHAR","email":"s*************e@fgb.ae","contactNumber":"05********","address1":"PO.BOX 12","address2":"Al Ain","city":"DUBAI","country":"UAE"};
        //UserContext.getInstance().userDetails;
        this.fetchAccounts();
    };
    AccountSettingsComponent.prototype.fetchAccounts = function () {
        var _this = this;
        this.accountsService.fetchCustomerAccounts()
            .subscribe(function (resp) { return _this.handleCustAcctsResp(resp); }, function (error) { return _this.sharedService.handleError(error); } //uncomment it later
        //error => this.handleCustAcctsResp(error) //comment it later
        );
    };
    AccountSettingsComponent.prototype.handleCustAcctsResp = function (resp) {
        this.spinnerService.stopSpinner();
        //resp=this.accountsStub1;//comment it later
        if (resp.result.status == "success") {
            this.customerAccountsResponse = new customerAccountsResponse_1.CustomerAccountsResponse();
            this.customerAccountsResponse = resp;
            if (this.customerAccountsResponse.customerProducts.accounts.length > 0) {
                this.accounts = this.customerAccountsResponse.customerProducts.accounts;
            }
        }
        else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    };
    AccountSettingsComponent = __decorate([
        core_1.Component({
            templateUrl: './../templates/accountSettings.html'
        }),
        __metadata("design:paramtypes", [accounts_service_1.AccountsService,
            shared_service_1.SharedService,
            error_service_1.ErrorService,
            spinner_service_1.SpinnerService])
    ], AccountSettingsComponent);
    return AccountSettingsComponent;
}());
exports.AccountSettingsComponent = AccountSettingsComponent;
//# sourceMappingURL=accountSettings.component.js.map