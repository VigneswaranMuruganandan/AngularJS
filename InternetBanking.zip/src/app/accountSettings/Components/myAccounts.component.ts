import { Component, OnInit, Input, OnChanges,SimpleChanges} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { Account } from '../../shared/model/account';
import { NickNameReq } from '../model/nickNameReq';
import {AccountSettingsService} from '../services/accountSettings.service';
import {ErrorService } from '../../shared/services/error.service';
import {SpinnerService } from '../../shared/services/spinner.service';
import {SharedService} from '../../shared/services/shared.service';
import { APIResponse } from '../../shared/model/apiResponse';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';


@Component({
  selector: 'myaccounts-component',
  templateUrl: './../templates/myAccounts.html'
})
export class MyAccountsComponent implements OnInit{

	constructor(private accountSettingsService: AccountSettingsService,
				private sharedService: SharedService,
				private errorService: ErrorService,
				private spinnerService: SpinnerService) {}


	@Input() myAccounts:Array<Account>;
	currentIndex: number;
	eStatementFlag:boolean;
	nickNameReq : NickNameReq;
	
	ngOnInit(){
		this.currentIndex = 0;
		this.onAccountSelection(this.currentIndex);
	}

	ngOnChanges(changes: SimpleChanges) {
	    if(changes.myAccounts.currentValue ){
	    	this.onAccountSelection(0);
	    }
	}

	onAccountSelection(accountIndex : number){
		this.currentIndex = accountIndex;
		if(this.myAccounts && this.myAccounts.length > 0){
			this.nickNameReq = new NickNameReq();
			this.nickNameReq.productID = this.myAccounts[this.currentIndex].number;
			this.nickNameReq.nickName = this.myAccounts[this.currentIndex].nickName;
			this.nickNameReq.isFavorite = this.myAccounts[this.currentIndex].isFavorite;
		}
	}

	onSave(){
		this.saveNickName(this.nickNameReq);
		this.spinnerService.startSpinner();
		this.errorService.resetErrorResp();
	}

	saveNickName(req:NickNameReq){
		this.accountSettingsService.updateNickName(req)
	        .subscribe(
	           resp => this.handleUpdateNickNameResp(resp),
	           error => this.sharedService.handleError(error)
	        );
	
	}

	handleUpdateNickNameResp(resp:APIResponse){
		this.spinnerService.stopSpinner();
		if(resp && resp.result.status == 'success'){
            console.log(resp);
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}

	eStatementSelection(event:any){
		if(event.currentTarget.value=="true"){
			this.eStatementFlag=true;
		}else{
			this.eStatementFlag=false;
		}
	}
	
	turnOnEstatement(){
		this.spinnerService.startSpinner();
		this.errorService.resetErrorResp();
		this.accountSettingsService.activateEstatement()
			.subscribe(
	           resp => this.handleActivateEstatementResp(resp),
	           error => this.sharedService.handleError(error)
	        );
	}

	handleActivateEstatementResp(resp:APIResponse){
		this.spinnerService.stopSpinner();
		if(resp && resp.result.status == 'success'){
            console.log(resp);
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}


	turnOffEstatement(){
		this.spinnerService.startSpinner();
		this.errorService.resetErrorResp();
		this.accountSettingsService.deactivateEstatement()
			.subscribe(
	           resp => this.handleDeactivateEstatementResp(resp),
	           error => this.sharedService.handleError(error)
	        );
	}

	handleDeactivateEstatementResp(resp:APIResponse){
		this.spinnerService.stopSpinner();
		if(resp && resp.result.status == 'success'){
            console.log(resp);
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}
}