"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nickNameReq_1 = require("../model/nickNameReq");
var accountSettings_service_1 = require("../services/accountSettings.service");
var error_service_1 = require("../../shared/services/error.service");
var spinner_service_1 = require("../../shared/services/spinner.service");
var shared_service_1 = require("../../shared/services/shared.service");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/map");
var MyAccountsComponent = (function () {
    function MyAccountsComponent(accountSettingsService, sharedService, errorService, spinnerService) {
        this.accountSettingsService = accountSettingsService;
        this.sharedService = sharedService;
        this.errorService = errorService;
        this.spinnerService = spinnerService;
    }
    MyAccountsComponent.prototype.ngOnInit = function () {
        this.currentIndex = 0;
        this.onAccountSelection(this.currentIndex);
    };
    MyAccountsComponent.prototype.ngOnChanges = function (changes) {
        if (changes.myAccounts.currentValue) {
            this.onAccountSelection(0);
        }
    };
    MyAccountsComponent.prototype.onAccountSelection = function (accountIndex) {
        this.currentIndex = accountIndex;
        if (this.myAccounts && this.myAccounts.length > 0) {
            this.nickNameReq = new nickNameReq_1.NickNameReq();
            this.nickNameReq.productID = this.myAccounts[this.currentIndex].number;
            this.nickNameReq.nickName = this.myAccounts[this.currentIndex].nickName;
            this.nickNameReq.isFavorite = this.myAccounts[this.currentIndex].isFavorite;
        }
    };
    MyAccountsComponent.prototype.onSave = function () {
        this.saveNickName(this.nickNameReq);
        this.spinnerService.startSpinner();
        this.errorService.resetErrorResp();
    };
    MyAccountsComponent.prototype.saveNickName = function (req) {
        var _this = this;
        this.accountSettingsService.updateNickName(req)
            .subscribe(function (resp) { return _this.handleUpdateNickNameResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    MyAccountsComponent.prototype.handleUpdateNickNameResp = function (resp) {
        this.spinnerService.stopSpinner();
        if (resp && resp.result.status == 'success') {
            console.log(resp);
        }
        else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    };
    MyAccountsComponent.prototype.eStatementSelection = function (event) {
        if (event.currentTarget.value == "true") {
            this.eStatementFlag = true;
        }
        else {
            this.eStatementFlag = false;
        }
    };
    MyAccountsComponent.prototype.turnOnEstatement = function () {
        var _this = this;
        this.spinnerService.startSpinner();
        this.errorService.resetErrorResp();
        this.accountSettingsService.activateEstatement()
            .subscribe(function (resp) { return _this.handleActivateEstatementResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    MyAccountsComponent.prototype.handleActivateEstatementResp = function (resp) {
        this.spinnerService.stopSpinner();
        if (resp && resp.result.status == 'success') {
            console.log(resp);
        }
        else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    };
    MyAccountsComponent.prototype.turnOffEstatement = function () {
        var _this = this;
        this.spinnerService.startSpinner();
        this.errorService.resetErrorResp();
        this.accountSettingsService.deactivateEstatement()
            .subscribe(function (resp) { return _this.handleDeactivateEstatementResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    MyAccountsComponent.prototype.handleDeactivateEstatementResp = function (resp) {
        this.spinnerService.stopSpinner();
        if (resp && resp.result.status == 'success') {
            console.log(resp);
        }
        else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Array)
    ], MyAccountsComponent.prototype, "myAccounts", void 0);
    MyAccountsComponent = __decorate([
        core_1.Component({
            selector: 'myaccounts-component',
            templateUrl: './../templates/myAccounts.html'
        }),
        __metadata("design:paramtypes", [accountSettings_service_1.AccountSettingsService,
            shared_service_1.SharedService,
            error_service_1.ErrorService,
            spinner_service_1.SpinnerService])
    ], MyAccountsComponent);
    return MyAccountsComponent;
}());
exports.MyAccountsComponent = MyAccountsComponent;
//# sourceMappingURL=myAccounts.component.js.map