import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import {GlobalURL} from '../../shared/services/globalURL';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import { NickNameReq } from '../model/nickNameReq';
import { APIResponse } from '../../shared/model/apiResponse';

@Injectable()
export class AccountSettingsService {

  	constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService) {}

    updateNickName(req:NickNameReq): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.UPDATENICKNAME,req)
                                .map(resp => JSON.parse(resp));
    }

    activateEstatement(): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.ACTIVATEESTATEMENT,null)
                                .map(resp => JSON.parse(resp));
    }

    deactivateEstatement(): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.DEACTIVATEESTATEMENT,null)
                                .map(resp => JSON.parse(resp));
    }
    
    updateEmailID(req:any): Observable <any> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.UPDATEEMAILID,req)
                                .map(resp => JSON.parse(resp));
    }
  
}


