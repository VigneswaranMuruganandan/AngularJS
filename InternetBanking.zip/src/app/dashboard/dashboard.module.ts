import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';
import { DashboardRouting } from './dashboard.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { DashboardService} from './services/dashboard.service';
import { DashboardComponent} from './Components/dashboard.component';
import { WelcomeModalComponent} from './Components/welcomeModal.component';
import { FavouritesModalComponent} from './Components/favouritesModal.component';
import { FavouritesSettingsModalComponent} from './Components/favouritesSettingsModal.component';


const DASHBOARD_COMPONENTS = [
	DashboardComponent,
	WelcomeModalComponent,
	FavouritesModalComponent,
	FavouritesSettingsModalComponent
];

const DASHBOARD_PROVIDERS = [
   SharedService,
   TemplateService,
   DashboardService
];

@NgModule({
  	imports: [
	    DashboardRouting,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
		CommonModule
	],
  	declarations: [
	    ...DASHBOARD_COMPONENTS
	],
  	providers: [
  		...DASHBOARD_PROVIDERS
  	]
})
export class DashboardModule {}
