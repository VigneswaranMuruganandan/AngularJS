import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { FavouritesDetails } from '../model/favouritesDetails';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'favouritesSettingsModal-component',
  templateUrl: './../templates/favouritesSettingsModal.html'
})
export class FavouritesSettingsModalComponent{
	@Input() favouritesDetails: FavouritesDetails;
	public favList :Array<string>;

	collectFavourites(index : number){
		console.log(index);
	}
}