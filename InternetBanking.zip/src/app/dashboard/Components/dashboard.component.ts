import { Component, Input, OnInit, AfterViewInit } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { TemplateService} from '../../shared/services/template.service';
import { SharedService} from '../../shared/services/shared.service';
import { DashboardService} from '../services/dashboard.service';
import { DashBoardDetails } from '../model/dashBoardDetails';
import { FavouritesDetails } from '../model/favouritesDetails';
import { UserDetails } from '../../shared/model/userDetails';
import * as $ from 'jquery';
import { Observable } from 'rxjs/Rx';

@Component({
  templateUrl: './../templates/dashboard.html'
})
export class DashboardComponent implements OnInit, AfterViewInit  {
	public dashBoardDetails: DashBoardDetails;
    public favouritesDetails: FavouritesDetails;
    private bootstrap = require('bootstrap');

	constructor( private dashboardService: DashboardService, 
    			 private sharedService: SharedService) {}

	ngOnInit() {        
        //this.handleFavouritesResp(this.dashboardService.fetchAllProducts());
        this.initDashboardDetails();
        //this.initFavouritesDetails();
        //let data = new UserDetails({"salutation":"M/S","name":"XXXZ-UL-HAQ KHOKHAR","email":"s*************e@fgb.ae","contactNumber":"05********","address1":"PO.BOX 12","address2":"Al Ain","city":"DUBAI","country":"UAE"});
       // data = {"salutation":"M/S","name":"XXXZ-UL-HAQ KHOKHAR","email":"s*************e@fgb.ae","contactNumber":"05********","address1":"PO.BOX 12","address2":"Al Ain","city":"DUBAI","country":"UAE"};
        //this.sharedService.updateUserContext(data);
	}

    ngAfterViewInit(){
        //(<any>$('#openWelcomeModal')).click();
    }

    /*
    * Init method to fetch the Dashboard Details service
    * will provide favourites, payment templates
    * Transfer Templates, offers and all products
    */
    initDashboardDetails(){
        this.dashboardService.fetchDashBoardResults()
            .subscribe(
                resp => this.handleDashboardInitResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleDashboardInitResp(resp: any){
        console.log("dashboard init result::"+resp);
        if(resp && resp.result.status == "success"){
            this.dashBoardDetails = new DashBoardDetails();
            this.dashBoardDetails = resp;
            if(resp.user){
              this.sharedService.updateUserContext(resp.user);  
            }            
        }
    }

    /*
    * Init method to fetch all products & Favourite products
    */
    initFavouritesDetails(){
        this.dashboardService.fetchAllProducts()
            .subscribe(
                resp => this.handleFavouritesResp(resp),
                error => this.sharedService.handleError(error)
            );
    }	

    handleFavouritesResp(resp: any){
        console.log(resp);
        if(resp && resp.result.status == "success"){
            this.favouritesDetails = new FavouritesDetails();
            this.favouritesDetails = resp;
        }
    }


    favouritesModal(){
        (<any>$('#welcomeDashboard-1')).modal('hide');
        (<any>$('#openfavouritesModal')).click();        
    }

    favouritesSettingsModal(){
        (<any>$('#welcomeDashboard-2')).modal('hide');
        (<any>$('#openfavouritesSettingsModal')).click();
    }


}