"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var shared_service_1 = require("../../shared/services/shared.service");
var dashboard_service_1 = require("../services/dashboard.service");
var dashBoardDetails_1 = require("../model/dashBoardDetails");
var favouritesDetails_1 = require("../model/favouritesDetails");
var $ = require("jquery");
var DashboardComponent = (function () {
    function DashboardComponent(dashboardService, sharedService) {
        this.dashboardService = dashboardService;
        this.sharedService = sharedService;
        this.bootstrap = require('bootstrap');
    }
    DashboardComponent.prototype.ngOnInit = function () {
        //this.handleFavouritesResp(this.dashboardService.fetchAllProducts());
        this.initDashboardDetails();
        //this.initFavouritesDetails();
        //let data = new UserDetails({"salutation":"M/S","name":"XXXZ-UL-HAQ KHOKHAR","email":"s*************e@fgb.ae","contactNumber":"05********","address1":"PO.BOX 12","address2":"Al Ain","city":"DUBAI","country":"UAE"});
        // data = {"salutation":"M/S","name":"XXXZ-UL-HAQ KHOKHAR","email":"s*************e@fgb.ae","contactNumber":"05********","address1":"PO.BOX 12","address2":"Al Ain","city":"DUBAI","country":"UAE"};
        //this.sharedService.updateUserContext(data);
    };
    DashboardComponent.prototype.ngAfterViewInit = function () {
        //(<any>$('#openWelcomeModal')).click();
    };
    /*
    * Init method to fetch the Dashboard Details service
    * will provide favourites, payment templates
    * Transfer Templates, offers and all products
    */
    DashboardComponent.prototype.initDashboardDetails = function () {
        var _this = this;
        this.dashboardService.fetchDashBoardResults()
            .subscribe(function (resp) { return _this.handleDashboardInitResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    DashboardComponent.prototype.handleDashboardInitResp = function (resp) {
        console.log("dashboard init result::" + resp);
        if (resp && resp.result.status == "success") {
            this.dashBoardDetails = new dashBoardDetails_1.DashBoardDetails();
            this.dashBoardDetails = resp;
            if (resp.user) {
                this.sharedService.updateUserContext(resp.user);
            }
        }
    };
    /*
    * Init method to fetch all products & Favourite products
    */
    DashboardComponent.prototype.initFavouritesDetails = function () {
        var _this = this;
        this.dashboardService.fetchAllProducts()
            .subscribe(function (resp) { return _this.handleFavouritesResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    DashboardComponent.prototype.handleFavouritesResp = function (resp) {
        console.log(resp);
        if (resp && resp.result.status == "success") {
            this.favouritesDetails = new favouritesDetails_1.FavouritesDetails();
            this.favouritesDetails = resp;
        }
    };
    DashboardComponent.prototype.favouritesModal = function () {
        $('#welcomeDashboard-1').modal('hide');
        $('#openfavouritesModal').click();
    };
    DashboardComponent.prototype.favouritesSettingsModal = function () {
        $('#welcomeDashboard-2').modal('hide');
        $('#openfavouritesSettingsModal').click();
    };
    DashboardComponent = __decorate([
        core_1.Component({
            templateUrl: './../templates/dashboard.html'
        }),
        __metadata("design:paramtypes", [dashboard_service_1.DashboardService,
            shared_service_1.SharedService])
    ], DashboardComponent);
    return DashboardComponent;
}());
exports.DashboardComponent = DashboardComponent;
//# sourceMappingURL=dashboard.component.js.map