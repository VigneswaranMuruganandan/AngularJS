import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'welcomeModal-component',
  templateUrl: './../templates/welcomeModal.html'
})
export class WelcomeModalComponent{
	@Output() favouritesModalEvent = new EventEmitter();
	
	showFavouritesModal(){
		this.favouritesModalEvent.emit();
	}
}