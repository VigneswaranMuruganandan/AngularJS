"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var PaymentTemplate = (function () {
    function PaymentTemplate() {
    }
    return PaymentTemplate;
}());
exports.PaymentTemplate = PaymentTemplate;
//# sourceMappingURL=paymentTemplate.js.map