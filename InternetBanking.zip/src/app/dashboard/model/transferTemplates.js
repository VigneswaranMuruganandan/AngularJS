"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var TransferTemplates = (function () {
    function TransferTemplates() {
    }
    return TransferTemplates;
}());
exports.TransferTemplates = TransferTemplates;
//# sourceMappingURL=transferTemplates.js.map