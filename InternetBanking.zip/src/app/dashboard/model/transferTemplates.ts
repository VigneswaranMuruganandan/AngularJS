export class TransferTemplates{
	name :string;
	type :string;
}