import { APIResponse } from '../../shared/model/apiResponse';

export class FavouritesDetails extends APIResponse{
    productPreference : ProductPreference[];
}


export class ProductPreference{
    enableEStatement : boolean;
    showAccountOnDashboard : boolean;
    nickName : string;
    isFavorite : boolean;
    prodRef : string;
    displaySequence : number;
}