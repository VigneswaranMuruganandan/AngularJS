import { APIResponse } from '../../shared/model/apiResponse';
import { CustomerProducts } from '../../shared/model/customerProducts';
import { PaymentTemplate } from './paymentTemplate';
import { TransferTemplates } from './transferTemplates';
import { UserDetails } from '../../shared/model/userDetails';

export class DashBoardDetails extends APIResponse{
    favouriteProducts : CustomerProducts;
	customerProducts : CustomerProducts;
	bulletins : string[];
	user : UserDetails;
	paymentTemplates : PaymentTemplate[];
	transferTemplates : TransferTemplates[];
	lastLoginDate: string;
}