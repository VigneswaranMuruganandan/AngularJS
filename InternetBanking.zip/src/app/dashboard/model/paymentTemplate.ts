export class PaymentTemplate{
	name :string;
	type :string;
}