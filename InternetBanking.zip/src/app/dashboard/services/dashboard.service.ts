import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { GlobalVariable} from '../../shared/services/global';
import { ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import { EncryptionService} from '../../shared/services/encryption.service';
import { GlobalURL} from '../../shared/services/globalURL';
import { DashBoardDetails } from '../model/dashBoardDetails';
import { CustomerProducts } from '../../shared/model/customerProducts';
import { FavouritesDetails } from '../model/favouritesDetails';

@Injectable()
export class DashboardService {

    constructor( private serviceInvoker: ServiceInvoker,
                 private encryptionService: EncryptionService) {}

    fetchDashBoardResults() {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.DASHBOARD.DASHBOARD_DETAILS, null)
                                  .map(resp => JSON.parse(resp));
    }

    fetchAllProducts() {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.DASHBOARD.DASHBOARD_DETAILS, null)
                                  .map(resp => JSON.parse(resp));
    }
}

  

