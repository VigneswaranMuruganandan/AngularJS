"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Account = (function () {
    function Account() {
    }
    return Account;
}());
exports.Account = Account;
//# sourceMappingURL=account.js.map