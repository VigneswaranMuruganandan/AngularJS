"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var StaticDataContainer = (function () {
    function StaticDataContainer() {
    }
    return StaticDataContainer;
}());
exports.StaticDataContainer = StaticDataContainer;
//# sourceMappingURL=staticDataContainer.js.map