"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var StaticData = (function () {
    function StaticData() {
    }
    return StaticData;
}());
exports.StaticData = StaticData;
//# sourceMappingURL=staticData.js.map