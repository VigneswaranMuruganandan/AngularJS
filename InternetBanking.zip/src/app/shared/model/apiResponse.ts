import {InvocationResult} from './invocationResult';

export class APIResponse{
    result: InvocationResult; 
	
}