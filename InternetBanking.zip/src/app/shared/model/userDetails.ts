export class UserDetails {
   salutation:string;
   name:string;
   email:string;
   contactNumber:string;
   address1:string;
   address2:string;
   city:string;
   country:string;
   lastLogin:string;
   lastFailedLogin:string;
   lastSuccessLogin:string;
}