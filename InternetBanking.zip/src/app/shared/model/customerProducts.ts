import { Loan } from './loan';
import { Account } from './account';
import { Card } from './card';

export class CustomerProducts{
    accounts: Account[];
	loans : Loan[];
	cards : Card[];
	deposits:Account[];
}