import { UserDetails } from './userDetails';

export class UserContext{
    private static _instance:UserContext;

    userDetails:UserDetails;

    public static getInstance():UserContext{
        return UserContext._instance||(UserContext._instance = new UserContext());
    };
}