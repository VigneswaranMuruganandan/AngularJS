export class ErrorInfo{
	code:string;
	desc:string;
};