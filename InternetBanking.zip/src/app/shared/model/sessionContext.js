"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SessionContext = (function () {
    function SessionContext() {
        this.data = [];
    }
    SessionContext.getInstance = function () {
        return SessionContext._instance || (SessionContext._instance = new SessionContext());
    };
    ;
    return SessionContext;
}());
exports.SessionContext = SessionContext;
//# sourceMappingURL=sessionContext.js.map