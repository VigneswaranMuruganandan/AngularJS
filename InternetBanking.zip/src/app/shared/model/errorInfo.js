"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ErrorInfo = (function () {
    function ErrorInfo() {
    }
    return ErrorInfo;
}());
exports.ErrorInfo = ErrorInfo;
;
//# sourceMappingURL=errorInfo.js.map