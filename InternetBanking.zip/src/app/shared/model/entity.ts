export class Entity {
	entityName:string;
}