import {StaticData} from './staticData';

export class StaticDataContainer {

	staticDataList : StaticData[]
	staticDataType:string;

}