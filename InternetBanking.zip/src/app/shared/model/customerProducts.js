"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CustomerProducts = (function () {
    function CustomerProducts() {
    }
    return CustomerProducts;
}());
exports.CustomerProducts = CustomerProducts;
//# sourceMappingURL=customerProducts.js.map