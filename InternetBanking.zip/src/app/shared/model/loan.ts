export class Loan{
   loanNumber : string;
	description : string;
	availableBal : string;
	ledgerBal : string;
	currency : string;
	holderName : string;
	categoryCode : string;
	type : string;
	purpose : string;
	nickName : string;
	displaySequence : string;
	isFavorite : boolean;
}