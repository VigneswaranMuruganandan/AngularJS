import {APIResponse} from './apiResponse';
import {StaticDataContainer} from './staticDataContainer';


export class StaticDataResponse extends APIResponse{

   staticMasterDataList : StaticDataContainer[]

}