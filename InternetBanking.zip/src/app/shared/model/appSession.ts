export class AppSession{
	convID: string;
	encKey: string;
	encIV: string;
}