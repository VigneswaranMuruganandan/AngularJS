"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Entity = (function () {
    function Entity() {
    }
    return Entity;
}());
exports.Entity = Entity;
//# sourceMappingURL=entity.js.map