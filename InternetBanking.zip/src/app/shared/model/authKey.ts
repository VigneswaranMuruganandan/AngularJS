export class AuthKey{
	 encKey : string;
     encIV  : string;
     convID  : string;
     macKey  : string;
     ec : number;
}