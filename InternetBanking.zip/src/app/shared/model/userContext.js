"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserContext = (function () {
    function UserContext() {
    }
    UserContext.getInstance = function () {
        return UserContext._instance || (UserContext._instance = new UserContext());
    };
    ;
    return UserContext;
}());
exports.UserContext = UserContext;
//# sourceMappingURL=userContext.js.map