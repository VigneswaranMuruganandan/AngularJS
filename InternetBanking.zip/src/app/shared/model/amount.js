"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Amount = (function () {
    function Amount() {
    }
    return Amount;
}());
exports.Amount = Amount;
//# sourceMappingURL=amount.js.map