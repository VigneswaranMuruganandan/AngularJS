import {ErrorInfo} from './errorInfo';

export class InvocationResult{
	status: string;
	errorInfo: ErrorInfo;
	msgArgs: number[];

    isSuccess():Boolean {
       return status == "success";
    }
}


