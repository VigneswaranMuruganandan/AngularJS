"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var APIResponse = (function () {
    function APIResponse() {
    }
    return APIResponse;
}());
exports.APIResponse = APIResponse;
//# sourceMappingURL=apiResponse.js.map