"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Loan = (function () {
    function Loan() {
    }
    return Loan;
}());
exports.Loan = Loan;
//# sourceMappingURL=loan.js.map