export class StaticData {

	code:string;
	description:string;
	entityName:string;
    sortingOrder:number;
}