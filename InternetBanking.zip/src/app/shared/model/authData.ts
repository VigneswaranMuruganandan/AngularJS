import {APIResponse} from '../../shared/model/apiResponse';
import {AuthKey} from '../../shared/model/authKey';

export class AuthData extends APIResponse{

	authKey:AuthKey;
	action:string;

}