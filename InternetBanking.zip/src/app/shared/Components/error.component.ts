import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {ErrorService} from '../services/error.service';

@Component({
  selector: 'error-component',
  templateUrl: './../templates/error.html'
})
export class ErrorComponent{
	constructor( private errorService: ErrorService){
		
	}

}