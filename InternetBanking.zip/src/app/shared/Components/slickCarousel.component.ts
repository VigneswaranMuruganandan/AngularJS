import { Component, ElementRef, NgZone, Host, Directive, Input } from '@angular/core';
require('slick-carousel');


@Component({
  selector: 'slick-carousel',
  template: `<ng-content></ng-content>`
})
export class SlickCarouselComponent {
  @Input() dataConfig: string;

  constructor(private el: ElementRef, private zone: NgZone) {
  }

  $carousel: JQuery | any;

  initialized = false;

  initCarousel() {
    this.zone.runOutsideAngular(() => {
      var conf = {
                  'favorites': {
                      'dots': true,
                      'appendDots': '.slick-carousel-dots',
                      'dotsClass': 'carousel-dots',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'arrows': false,
                      'responsive': [{
                              'breakpoint': 1500,
                              'settings': {
                                  'slidesToShow': 3,
                                  'slidesToScroll': 3,
                                  'infinite': true,
                                  'dots': true
                              }
                          },
                          {
                              'breakpoint': 1100,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2,
                                  'infinite': true,
                                  'dots': true
                              }
                          },
                          {
                              'breakpoint': 600,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2
                              }
                          },
                          {
                              'breakpoint': 520,
                              'settings': {
                                  'slidesToShow': 1,
                                  'slidesToScroll': 1
                              }
                          }
                      ]
                  },
                  'bulletins': {
                    'arrows': false,
                    'slidesToShow': 1,
                    'slidesToScroll': 1,
                    'autoplay': true,
                    'autoplaySpeed': 2000
                  }
              };
      this.$carousel = (<any>$(this.el.nativeElement)).slick(conf[this.dataConfig]);
      setTimeout(function() {
        $(window).trigger('resize');
      }, 2000);
      $( window ).resize(function() {
        //not required
      });

    });
    this.initialized = true;
  }

  slides:any[] = [];

  addSlide(slide: any) {
    !this.initialized && this.initCarousel();
    this.slides.push(slide);
    this.$carousel.slick('slickAdd', slide.el.nativeElement);
  }

  removeSlide(slide:any) {
    const idx = this.slides.indexOf(slide);
    this.$carousel.slick('slickRemove', idx);
    this.slides = this.slides.filter(s => s != slide);
  }
}


@Directive({
  selector: '[slick-carousel-item]',
})
export class SlickCarouselItem {
  constructor(private el: ElementRef, @Host() private carousel: SlickCarouselComponent) {
  }
  ngAfterViewInit() {
    this.carousel.addSlide(this);
  }
  ngOnDestroy() {
    this.carousel.removeSlide(this);
  }
}

