import {Component, Input, ElementRef, ContentChild, Renderer,
Directive, HostListener, Host, NgZone, Output, EventEmitter} from '@angular/core';
import * as $ from 'jquery';


@Component({
  selector: 'pin-component',
  template: `<ng-content></ng-content>`
})
export class PinFourDigitComponent {
   constructor(private el:ElementRef) {}
  
  changeFocus(id:number){
   let elem = this.el.nativeElement;
   let nextElem=$(elem).find('ul li input:password')[id];
   if( id < 4){
     $(nextElem).focus();
   }
  }
}



@Directive({
  selector: '[pinkeypress]',
})
export class PinKeypress {
@Input() pinkeypress:number;
@Output() validatePinEvent= new EventEmitter();
  constructor(private el: ElementRef,@Host() private pinComponent:PinFourDigitComponent) {
  }

  @HostListener('keyup', ['$event']) 
    onKeyUp(event: any) {
      var el = $(this.el.nativeElement);
        
        let pinFormSubmit:boolean;
        let pinFormValidation = (<any>$("#pinForm")).validate({
          highlight: function (element :any) {
            var field = $(element);
            field.addClass("field-error");
          },
          unhighlight: function (element :any, errorClass :any) {
            var field = $(element);
            field.removeClass("field-error");
          },
          errorPlacement: function (error :any, element :any) {
            console.log(error);
            if (element.is("input")) {
              $('.custom-error-msg').append(error);
            }
          },
          rules: {
            pinBox1: { required: true },
            pinBox2: { required: true },
            pinBox3: { required: true },
            pinBox4: { required: true }
          },
          groups: {
            PinBoxError: "pinBox1 pinBox2 pinBox3 pinBox4"
          },
          messages: {
            pinBox1: {required: "Please enter the Pin"},
            pinBox2: {required: "Please enter the Pin"},
            pinBox3: {required: "Please enter the Pin"},
            pinBox4: {required: "Please enter the Pin"}
          }
        });
        pinFormSubmit = pinFormValidation.form();
        if(pinFormSubmit){
          this.validatePinEvent.emit();
        } 

        this.pinComponent.changeFocus(this.pinkeypress);
    }
}






