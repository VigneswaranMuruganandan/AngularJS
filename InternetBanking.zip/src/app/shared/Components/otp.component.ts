import {
    Component,
    Input,
    ElementRef,
    ContentChild,
    Renderer,
    Directive,
    HostListener,
    Host,
    NgZone,
    Output,
    EventEmitter
} from '@angular/core';
import * as $ from 'jquery';

@Component({
    selector: 'otp-component',
    template: `<ng-content></ng-content>`
})
export class OTPComponent {
    private x = require('jquery-validator');
    private CryptoJS = require('crypto-js');
    constructor(private el: ElementRef) {}
    changeFocus(id: number) {
        console.log(id);
        let el = this.el.nativeElement;
        let nextElement = $(el).find('ul li input:text')[id];
        if (id < 7)
          $(nextElement).focus();

    }
    ngAfterViewInit() {
        var el = this.el.nativeElement;
        var otpe1 = $(el).find('ul li input:text')[0];
        $(otpe1).focus();
    }
}

@Directive({
    selector: '[otpkeypress]',
})
export class OTPKeypress {
    @Input() otpkeypress: number;
    @Output() validateOTPEvent = new EventEmitter();
    constructor(private el: ElementRef, @Host() private otp: OTPComponent, private zone: NgZone) {}
    ngAfterViewInit() {}
    @HostListener('keyup', ['$event'])
    onKeyUp(event: any) {
        let el = $(this.el.nativeElement),
        otpFormSubmit;
        let otpFormValidation = ( < any > $("#otpForm")).validate({
            highlight: function(element: any) {
                var field = $(element);
                field.addClass("field-error");
            },
            unhighlight: function(element: any, errorClass: any) {
                var field = $(element);
                field.removeClass("field-error");
            },
            errorPlacement: function(error: any, element: any) {
                console.log(error);
                if (element.is("input")) {
                    $('.custom-error-msg').append(error);
                }
            },
            rules: {
                otpBox1: {
                    required: true
                },
                otpBox2: {
                    required: true
                },
                otpBox3: {
                    required: true
                },
                otpBox4: {
                    required: true
                },
                otpBox5: {
                    required: true
                },
                otpBox6: {
                    required: true
                }
            },
            groups: {
                OTPBoxError: "otpBox1 otpBox2 otpBox3 otpBox4 otpBox5 otpBox6"
            },
            messages: {
                otpBox1: {
                    required: "Please enter the correct OTP"
                },
                otpBox2: {
                    required: "Please enter the correct OTP"
                },
                otpBox3: {
                    required: "Please enter the correct OTP"
                },
                otpBox4: {
                    required: "Please enter the correct OTP"
                },
                otpBox5: {
                    required: "Please enter the correct OTP"
                },
                otpBox6: {
                    required: "Please enter the correct OTP"
                }
            }
        });
        otpFormSubmit = otpFormValidation.form();
        console.log(otpFormSubmit);
        if (el.val() != '') {
            this.otp.changeFocus(this.otpkeypress);
        }
        if (otpFormSubmit) {
            this.validateOTPEvent.emit();
        }
    }
}