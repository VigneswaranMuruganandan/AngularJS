"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var $ = require("jquery");
var OTPComponent = (function () {
    function OTPComponent(el) {
        this.el = el;
        this.x = require('jquery-validator');
        this.CryptoJS = require('crypto-js');
    }
    OTPComponent.prototype.changeFocus = function (id) {
        console.log(id);
        var el = this.el.nativeElement;
        var nextElement = $(el).find('ul li input:text')[id];
        if (id < 7)
            $(nextElement).focus();
    };
    OTPComponent.prototype.ngAfterViewInit = function () {
        var el = this.el.nativeElement;
        var otpe1 = $(el).find('ul li input:text')[0];
        $(otpe1).focus();
    };
    OTPComponent = __decorate([
        core_1.Component({
            selector: 'otp-component',
            template: "<ng-content></ng-content>"
        }),
        __metadata("design:paramtypes", [core_1.ElementRef])
    ], OTPComponent);
    return OTPComponent;
}());
exports.OTPComponent = OTPComponent;
var OTPKeypress = (function () {
    function OTPKeypress(el, otp, zone) {
        this.el = el;
        this.otp = otp;
        this.zone = zone;
        this.validateOTPEvent = new core_1.EventEmitter();
    }
    OTPKeypress.prototype.ngAfterViewInit = function () { };
    OTPKeypress.prototype.onKeyUp = function (event) {
        var el = $(this.el.nativeElement), otpFormSubmit;
        var otpFormValidation = $("#otpForm").validate({
            highlight: function (element) {
                var field = $(element);
                field.addClass("field-error");
            },
            unhighlight: function (element, errorClass) {
                var field = $(element);
                field.removeClass("field-error");
            },
            errorPlacement: function (error, element) {
                console.log(error);
                if (element.is("input")) {
                    $('.custom-error-msg').append(error);
                }
            },
            rules: {
                otpBox1: {
                    required: true
                },
                otpBox2: {
                    required: true
                },
                otpBox3: {
                    required: true
                },
                otpBox4: {
                    required: true
                },
                otpBox5: {
                    required: true
                },
                otpBox6: {
                    required: true
                }
            },
            groups: {
                OTPBoxError: "otpBox1 otpBox2 otpBox3 otpBox4 otpBox5 otpBox6"
            },
            messages: {
                otpBox1: {
                    required: "Please enter the correct OTP"
                },
                otpBox2: {
                    required: "Please enter the correct OTP"
                },
                otpBox3: {
                    required: "Please enter the correct OTP"
                },
                otpBox4: {
                    required: "Please enter the correct OTP"
                },
                otpBox5: {
                    required: "Please enter the correct OTP"
                },
                otpBox6: {
                    required: "Please enter the correct OTP"
                }
            }
        });
        otpFormSubmit = otpFormValidation.form();
        console.log(otpFormSubmit);
        if (el.val() != '') {
            this.otp.changeFocus(this.otpkeypress);
        }
        if (otpFormSubmit) {
            this.validateOTPEvent.emit();
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], OTPKeypress.prototype, "otpkeypress", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], OTPKeypress.prototype, "validateOTPEvent", void 0);
    __decorate([
        core_1.HostListener('keyup', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], OTPKeypress.prototype, "onKeyUp", null);
    OTPKeypress = __decorate([
        core_1.Directive({
            selector: '[otpkeypress]',
        }),
        __param(1, core_1.Host()),
        __metadata("design:paramtypes", [core_1.ElementRef, OTPComponent, core_1.NgZone])
    ], OTPKeypress);
    return OTPKeypress;
}());
exports.OTPKeypress = OTPKeypress;
//# sourceMappingURL=otp.component.js.map