"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var $ = require("jquery");
var PinFourDigitComponent = (function () {
    function PinFourDigitComponent(el) {
        this.el = el;
    }
    PinFourDigitComponent.prototype.changeFocus = function (id) {
        var elem = this.el.nativeElement;
        var nextElem = $(elem).find('ul li input:password')[id];
        if (id < 4) {
            $(nextElem).focus();
        }
    };
    PinFourDigitComponent = __decorate([
        core_1.Component({
            selector: 'pin-component',
            template: "<ng-content></ng-content>"
        }),
        __metadata("design:paramtypes", [core_1.ElementRef])
    ], PinFourDigitComponent);
    return PinFourDigitComponent;
}());
exports.PinFourDigitComponent = PinFourDigitComponent;
var PinKeypress = (function () {
    function PinKeypress(el, pinComponent) {
        this.el = el;
        this.pinComponent = pinComponent;
        this.validatePinEvent = new core_1.EventEmitter();
    }
    PinKeypress.prototype.onKeyUp = function (event) {
        var el = $(this.el.nativeElement);
        var pinFormSubmit;
        var pinFormValidation = $("#pinForm").validate({
            highlight: function (element) {
                var field = $(element);
                field.addClass("field-error");
            },
            unhighlight: function (element, errorClass) {
                var field = $(element);
                field.removeClass("field-error");
            },
            errorPlacement: function (error, element) {
                console.log(error);
                if (element.is("input")) {
                    $('.custom-error-msg').append(error);
                }
            },
            rules: {
                pinBox1: { required: true },
                pinBox2: { required: true },
                pinBox3: { required: true },
                pinBox4: { required: true }
            },
            groups: {
                PinBoxError: "pinBox1 pinBox2 pinBox3 pinBox4"
            },
            messages: {
                pinBox1: { required: "Please enter the Pin" },
                pinBox2: { required: "Please enter the Pin" },
                pinBox3: { required: "Please enter the Pin" },
                pinBox4: { required: "Please enter the Pin" }
            }
        });
        pinFormSubmit = pinFormValidation.form();
        if (pinFormSubmit) {
            this.validatePinEvent.emit();
        }
        this.pinComponent.changeFocus(this.pinkeypress);
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], PinKeypress.prototype, "pinkeypress", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], PinKeypress.prototype, "validatePinEvent", void 0);
    __decorate([
        core_1.HostListener('keyup', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], PinKeypress.prototype, "onKeyUp", null);
    PinKeypress = __decorate([
        core_1.Directive({
            selector: '[pinkeypress]',
        }),
        __param(1, core_1.Host()),
        __metadata("design:paramtypes", [core_1.ElementRef, PinFourDigitComponent])
    ], PinKeypress);
    return PinKeypress;
}());
exports.PinKeypress = PinKeypress;
//# sourceMappingURL=pinFourDigit.component.js.map