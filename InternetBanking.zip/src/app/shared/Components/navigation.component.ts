import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { GlobalURL} from '../../shared/services/globalURL';

@Component({
  selector: 'navigation-component',
  templateUrl: './../templates/navigation.html'
})
export class NavigationComponent implements OnInit {
	globalURL: any;

	ngOnInit() {
		this.globalURL = GlobalURL;
	}	
}