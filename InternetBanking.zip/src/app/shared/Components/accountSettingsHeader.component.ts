import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { Router, Routes, RouterModule }  from '@angular/router';

@Component({
  selector: '[accountsettingsheader-component]',
  templateUrl: './../templates/accountSettingsHeader.html'
})
export class AccountSettingsHeaderComponent {
	constructor(private router:Router) {}

	viewAccountSettings(){
		this.router.navigate(['/accountsettings']);
	}
}