import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {AppSession} from '../model/appSession';
import {AuthRequest} from '../../register/model/authRequest';
import {VerifyCustomerResponse} from '../../register/model/verifyCustomerResponse';
import {RegisterPwdResponse} from '../../register/model/registerPwdResponse';
import {VerifyOtpResponse} from '../model/verifyOtpResponse';
import {ResendOtpResponse} from '../../register/model/resendOtpResponse';
import {AuthKey} from '../model/authKey';
import {AuthData} from '../model/authData';
import {UserDetails} from '../model/userDetails';
import {ServiceInvoker} from '../connector/serviceInvoker.service';
import {SpinnerService} from './spinner.service';
import {EncryptionService} from '../services/encryption.service';
import {SessionContext} from '../model/sessionContext';
import {UserContext} from '../model/userContext';
import {GlobalURL} from '../services/globalURL';
import {GlobalVariable} from './global';

@Injectable()
export class SharedService {

    private baseUrl: string = 'app/_assets/stubs/';

    constructor( private serviceInvoker: ServiceInvoker,
                 private spinnerService: SpinnerService,
                 private encryptionService: EncryptionService) {}

    registerDevice(authRequest: AuthRequest): Observable < AuthData > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.REGISTERDEVICE, authRequest)
            .map(resp => this.populateAuthReq(resp));
    }

    private populateAuthReq(resp: string) {
        var authData = new AuthData();
        let respObj = JSON.parse(resp);
        console.log("result " + respObj.result.status);
        if (respObj.result.status == 'success') {
            authData.authKey = new AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            console.log("convid " + authData.authKey.convID);
            var sessCtx = SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
        return authData;
    }

    setupAuthKeys() {
        let data = new AuthRequest();
        let sessCtx = SessionContext.getInstance();
        let jsonResp = "";
        if (sessCtx.authKey == null) {
            data.deviceID = "br_" + this.createGuid();
            console.log("in constructor dev id " + data.deviceID);
        }
        return data;
    }

    createGuid(): string {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0,
                v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    updateUserContext(data: UserDetails){        
        let userCtx = UserContext.getInstance();
        userCtx.userDetails = new UserDetails();
    	let temp =  Object.getOwnPropertyNames(data)
    				.map((key: string) => {
    					
    					userCtx.userDetails[key] = data[key];
    				});	
    }
    handleObject(key :string){
    	console.log(key);
    }
    handleError(error: any){
        this.spinnerService.stopSpinner();
        console.log('handleVerifyCustIDError ' + error);
    }
}