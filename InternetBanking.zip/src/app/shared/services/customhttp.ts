import {Injectable} from '@angular/core';
import {Http, ConnectionBackend, Request, RequestOptions, RequestOptionsArgs, Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';

@Injectable()
export class CustomHttp extends Http {
  constructor(backend: ConnectionBackend, defaultOptions: RequestOptions) {
    super(backend, defaultOptions);
  }

  request(url: string | Request, options?: RequestOptionsArgs): Observable<any> {
    //console.log('Before the request...');
    return super.request(url, options)
        .catch((err: any): any => {
          return;
        })
        .retryWhen(error => error.delay(500))
        .timeoutWith(10000, Observable.throw(new Error('delay exceeded')))
        .finally(() => {
          //console.log('After the request...');
        });
  }



  get(url: string, options?: RequestOptionsArgs): Observable<any> {

    if(options && options.headers){
    //console.log("customhttp::::"+options);
       options.headers.append('Cache-Control', 'no-cache, no-store, max-age=0');
       options.headers.append('Pragma', 'no-cache');
    }
    
    //console.log('Before the request...');
    return super.get(url, options)
        .catch((err: any): any => {
          if (err.status === 400 || err.status === 422) {
            return Observable.throw(err);
          } else {
            
            return Observable.empty();
          }
        })
        .retryWhen(error => error.delay(500))
        .timeoutWith(10000, Observable.throw(new Error('delay exceeded')))
        .finally(() => {
          //console.log('After the request...');
        });
  }


  

  post(url: string, body: any, options?: RequestOptionsArgs): Observable<any> {
    //console.log('Before the request...');
    return super.post(url, body, options)
        .catch((err: any): any => {
          if (err.status === 400 || err.status === 422) {
            return Observable.throw(err);
          } else {
            
            return Observable.empty();
          }
        })
        .timeoutWith(10000, Observable.throw(new Error('delay exceeded')))
        .finally(() => {
          //console.log('After the request...');
        });
  }
  

  

}