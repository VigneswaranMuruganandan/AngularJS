"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var EncryptionService = (function () {
    function EncryptionService(http) {
        this.http = http;
        this.CryptoJS = require('crypto-js');
        this.keySize = 128 / 32;
        this.iterationCount = 1000;
    }
    EncryptionService.prototype.generatePwdHash = function (salt, cleartext) {
        var saltInBytes = this.CryptoJS.enc.Utf8.parse(salt);
        var txtInBytes = this.CryptoJS.enc.Utf8.parse(cleartext);
        var hash = this.CryptoJS.PBKDF2(txtInBytes, saltInBytes, { keySize: 512 / 32, iterations: 50 });
        return hash;
    };
    EncryptionService.prototype.getEncodedKey = function (clearText) {
        console.log("encoding text " + clearText);
        //var textString = 'Hello world'; // Utf8-encoded string
        var words = this.CryptoJS.enc.Utf8.parse(clearText); // WordArray object
        return words; //this.CryptoJS.enc.Base64.stringify(words);
    };
    EncryptionService.prototype.convertToBase64 = function (words) {
        return this.CryptoJS.enc.Base64.stringify(words);
    };
    EncryptionService.prototype.convertWordsToUtf8 = function (words) {
        return this.CryptoJS.enc.Utf8.stringify(words);
    };
    EncryptionService.prototype.getDecodedKey = function (encKey) {
        console.log("decoding text " + encKey);
        var words = this.CryptoJS.enc.Base64.parse(encKey);
        return words;
    };
    /* Encrypt */
    EncryptionService.prototype.encrypt = function (plainText, encKey, encIv) {
        var key = this.getDecodedKey(encKey);
        var iv = this.getDecodedKey(encIv);
        console.log("key " + key);
        console.log("iv " + iv);
        var encrypted = this.CryptoJS.AES.encrypt(plainText, key, {
            mode: this.CryptoJS.mode.CBC,
            padding: this.CryptoJS.pad.Pkcs7,
            iv: iv //this.CryptoJS.enc.Hex.parse(iv)
        });
        //return btoa(encrypted.ciphertext);  
        var encrB64 = this.CryptoJS.enc.Base64.stringify(encrypted.ciphertext);
        // CryptoJS.enc.Base64.toString(encrypted.ciphertext);
        console.log("encr b64 " + encrB64);
        return encrB64;
        //return encrypted.ciphertext.toString(this.CryptoJS.enc.Base64);
    };
    /* Decrypt */
    EncryptionService.prototype.decrypt = function (cipherText, encKey, encIv) {
        console.log('decrypting ...' + cipherText);
        var key = this.getDecodedKey(encKey); // this.generateKey(salt, passPhrase);
        var iv = this.getDecodedKey(encIv);
        var decrypted = this.CryptoJS.AES.decrypt({
            ciphertext: this.getDecodedKey(cipherText)
        }, key, {
            mode: this.CryptoJS.mode.CBC,
            padding: this.CryptoJS.pad.Pkcs7,
            iv: iv //this.CryptoJS.enc.Hex.parse(iv)
        });
        var decryptedText = decrypted.toString(this.CryptoJS.enc.Utf8);
        console.log("decryptedText " + decryptedText);
        return decryptedText;
    };
    /* Key Generation */
    EncryptionService.prototype.generateKey = function (salt, passPhrase) {
        var key = this.CryptoJS.PBKDF2(passPhrase, this.CryptoJS.enc.Hex.parse(salt), {
            keySize: this.keySize,
            iterations: this.iterationCount
        });
        return key;
    };
    EncryptionService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [http_1.Http])
    ], EncryptionService);
    return EncryptionService;
}());
exports.EncryptionService = EncryptionService;
//# sourceMappingURL=encryption.service.js.map