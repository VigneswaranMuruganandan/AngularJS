"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlobalURL = Object.freeze({
    SERVICE_URL: {
        REGISTRATION: {
            REGISTERDEVICE: "/registration/device/register",
            VERIFYCUSTOMER: "/registration/customer/verify",
            VERIFYOTP: "/registration/otp/verify",
            RESENDOTP: "/registration/otp/resend",
            VERIFYUSERNAME: "/registration/uname/verify",
            REGISTERPASSWORD: "/registration/pwd/register"
        },
        LOGIN: {
            VERIFYLOGIN: "/accesscontrol/cred/verify",
            AUTHENTICATIONMETHOD: "/registration/auth2/update",
            VERIFYCUSTOMERID: "/registration/customer/id/verify"
        },
        FORGOT_PASSWORD: {
            RESETPASSWORD: "/accesscontrol/cred/reset",
            VERIFYPASSWORD: "/authcred/pwd/verify",
            CUST_PWDRECOVERY: "/registration/customer/pwdrecovery"
        },
        DASHBOARD: {
            DASHBOARD_DETAILS: "/cust/dashboard",
            ALL_PRODUCTS: "/pref/products/fetch",
            SAVE_FAVOURITIES: "/pref/products/update"
        },
        SHARED: {
            //API_URL: "http://10.230.9.50:9080/PersonalBankingAPI/pbapp/",
            API_URL: "http://172.20.238.125:9080/PersonalBankingAPI/pbapp/",
            ATM_BRANCH_LOCATIONS: "https://www.fgbgroup.com/fgb-group/about-fgb/branch-locator"
        },
        ACCOUNTS: {
            CUSTOMERACCOUNTS: "/account/custpos/fetch",
            ACCOUNTDETAIL: "/account/detail/fetch"
        },
        ACCOUNTSETTINGS: {
            UPDATENICKNAME: "/pref/nickname/update",
            UPDATEEMAILID: "/pref/email/update",
            ACTIVATEESTATEMENT: "/pref/estmt/activate",
            DEACTIVATEESTATEMENT: "/pref/estmt/deactivate"
        },
        INVESTMENTS: {
            VIEW_PRODUCTS: "/bnk/data"
        }
    },
    PROPERTIES: {
        STUBS: "N"
    }
});
//# sourceMappingURL=globalURL.js.map