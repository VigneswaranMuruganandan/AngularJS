import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import * as $ from 'jquery';
import {GlobalVariable} from './global';

@Injectable()
export class TemplateService{
  validFormFlag : boolean;
  errorFlag : boolean;
  serviceErrorMessage : any;
  action : string;
  
  constructor(private http : Http){
    this.validFormFlag = false;
    this.errorFlag = true;
    this.serviceErrorMessage = {"flag":"true","message":""}; 
  }

  /* Setting the Flag for form validation */
  setFormValidatorFlag(flag: boolean){
    this.validFormFlag = flag;
  }

  /* Setting the Flag for form validation */
  resetFormValidatorFlag(){
    this.validFormFlag = false;
  }

  /* Setting the Flag for form validation */
  setErrorFlag(flag: boolean){
    this.errorFlag = flag;
  }

  /* Setting the Flag for form validation */
  resetErrorFlag(){
    this.errorFlag = false;
  }

  getServiceError(){
    return this.serviceErrorMessage;
  }

  setServiceError(flag: boolean, message: string){
    this.serviceErrorMessage = {"flag": flag ,"message": message}; 
  }

  setAction(value: string){
    this.action = value;
  }

  getAction(){
    return this.action;
  }

  /* Getting the Image source*/
  getImageURL(id:string){
    return 'app/assets/images/'+GlobalVariable.IMAGE_URL[id];
  }

  /* Checking the Menu status to 
  make the alignment for Navigation bar*/
  checkMenuState(){
    if( $( '.hamburger').hasClass( "animate" ) ){
      if ($(window).width() >= 960) {
         $('.main').addClass('push');
      }
      $('.sidebar').css('left','0');
    }else{
      $('.main').removeClass('push');
      $('.sidebar').css('left','-300px');
    }
  }

  /* Show or hide menu */
  showHideMenu(){
    if ($(window).width() < 959) {
       $('.hamburger').removeClass('animate');
    }
    else {
       $('.hamburger').addClass('animate');
    }
  }
    
}