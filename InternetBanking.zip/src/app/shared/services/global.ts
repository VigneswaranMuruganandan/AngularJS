export const GlobalVariable = Object.freeze({
    ROUTE_MAPPING: {
     	OPEN_TERM_DEPOSIT: "/account/opentermdeposit",
	    ACCOUNT_ACTIVITY: "/account/accountactivity",
	    SMART_ALERT_ACCOUNTS: "",
	    ACC_STATEMENT_BY_EMAIL: "",
	    ISAVE_PRODUCT_FEATURES: "",
	    CREATE_ISAVE_ACC: "",
	    VIEW_MODIFY_ISAVE_ACC: "",
	    CLOSE_ISAVE_ACC: "",
	    SETUP_REG_SAV: "",
	    VIEW_MODIFY_SETUP_REG_SAV: "",
	    CREDIT_CARD_ACTIVITY: "",
	    CREDIT_CARD_STATEMENT: "",
	    ACCELERATOR_STATEMENT: "",
	    SMART_ALERTS_CARDS: "",
	    CARD_STATEMENT_BY_EMAIL: "",
	    DEPOSIT_RATES_ENQUIRY: "",
	    EXCHANGE_RATES_ENQUIRY: "",
	    OPEN_GOLD_CURR_ACC: "",
	    BUY_GOLD: "",
	    SELL_GOLD: "",
	    DETAILS_OF_REG_BILLERS: "",
	    UTILITY_PAYMENTS: "",
	    SALIK_RECHARGE: "",
	    AUTO_SALIK_PAYMENT: "",
	    REG_SALIK_PAYMENTS: "",
	    WASEL_RECHARGE: "",
	    WASEL_RENEWAL: "",
	    DU_RECHARGE: "",
	    CREDIT_CARD_PAYMENT: "",
	    REGISTER_AUTO_PAYMENT: "",
	    DETAILS_OF_REG_PAYMENTS: "",
	    OWN_ACC_TRANSFER: "",
	    BENEF_MAINTENANCE: "",
	    TRANSFER_WITHIN_FGB: "",
	    TRANSFER_WITHIN_UAE: "",
	    TRANSFER_OUTSIDE_UAE: "",
	    P2P_TRANSFER_TO_MOBILE:"",
	    GLOBAL_MARKET_UPDATE: "",
	    ASSET_PRODUCT_ALLOCATION: "",
	    ABOUT_US: "",
	    PRODUCTS: "",
	    ELIGIBILITY: "",
	    HOLDING_SUMMARY: "",
	    TRANSACTION_HISTORY: "",
	    PENDING_ORDER_STATUS: "",
	    ALERTS: "",
	    LEAD_MANAGEMENT_APPLY_NOW: ".",
	    REPLACEMENT_OF_CREDIT_CARD: "",
	    CHANGE_BILLING_CYCLE: "",
	    CREDIT_CARD_PIN_CHANGE: "",
	    ACTIVATE_DEBIT_CARD: "",
	    CHANGE_OF_DEBIT_CARD_LIMIT: "",
	    DEBIT_CARD_PIN_CHANGE: "",
	    UPDATE_MOBILE_NUMBER: "",
	    BALANCE_TRANSFER: "",
	    QUICK_CASH: ""
    },
    URL_MAPPING: {
     	ACCOUNT:{
     		OPEN_TERM_DEPOSIT: "opentermdeposit.json",
     		OFFER_BANNER: "offer_content.json",
     		VERIFY_ACCESS_TOKEN: "verifyaccesstoken.json"
     	}
    },
    IMAGE_URL: {
    	ACTIVATE_DEBIT_CARD: "fgb-activation-credit-card.png"
    },
    SLIDER_PROPERTIES:{
    	FAVOURITES: {}
    },
    ERROR_CODES:{
    	USERNAME_PASSWORD_WRONG : "You have MESSAGE_DISPLAY remaining attempts for login",
    	VRFY_OTP_MTCH_FLD : "You have MESSAGE_DISPLAY remaining attempts"
    }
 });

