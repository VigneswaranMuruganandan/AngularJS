"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var StubResponse = (function () {
    function StubResponse() {
    }
    StubResponse.prototype.getData = function () {
        var data = {
            "\/registration\/device/register": "REGISTRATION",
            "REGISTRATION_REQ": "{\"deviceID\":\"ryuuiioooo\"}",
            "REGISTRATION_RES_1": "{\"result\":{\"success\":true},\"data\":{\"encKey\":\"Z6LzDX5yeOcZMKfBnk5ocQ==\",\"encIV\":\"iWYWyt\/Rh\/uDZcuxy52KUg==\",\"convID\":\"b52bb655ff7c4e8f8c7a510819768e6a\",\"deviceID\":\"0A46004E-6354-4006-8681-04B21EB3624C\",\"deviceToken\":\"JHDXAJQbTXjm7DCGAXco8A==\",\"macKey\":\"TIP7HURS6BbCOGttOxNJGg==\",\"eventCtr\":6271883939526526759,\"sessionType\":\"MB_ANON\"}}",
            "REGISTRATION_RES_2": "{\"result\":{\"success\":true},\"data\":{\"encKey\":\"Z6LzDX5yeOcZMKfBnk5ocQ==\",\"encIV\":\"iWYWyt\/Rh\/uDZcuxy52KUg==\",\"convID\":\"b52bb655ff7c4e8f8c7a510819768e6a\",\"deviceID\":\"0A46004E-6354-4006-8681-04B21EB3624C\",\"deviceToken\":\"JHDXAJQbTXjm7DCGAXco8A==\",\"macKey\":\"TIP7HURS6BbCOGttOxNJGg==\",\"eventCtr\":6271883939526526759,\"sessionType\":\"MB_REG\"}}",
            "\/accesscontrol\/cred\/verify": "LOGIN",
            "LOGIN_REQ": "{\"deviceID\":\"ryuuiioooo\",\"pin\":\"ryuuiioooo\"}",
            "LOGIN_RES_1": "{\"result\":{\"success\":true},\"session\":{\"encKey\":\"Z6LzDX5yeOcZMKfBnk5ocQ==\",\"encIV\":\"iWYWyt\/Rh\/uDZcuxy52KUg==\",\"convID\":\"b52bb655ff7c4e8f8c7a510819768e6a\",\"deviceID\":\"0A46004E-6354-4006-8681-04B21EB3624C\",\"deviceToken\":\"JHDXAJQbTXjm7DCGAXco8A==\",\"macKey\":\"TIP7HURS6BbCOGttOxNJGg==\",\"eventCtr\":6271883939526526759,\"sessionType\":\"MB_ANON\"}}",
            "LOGIN_RES_2": "{\"result\":{\"success\":false},\"remainingNumOfLoginAttempts\":3}"
        };
        return data;
    };
    return StubResponse;
}());
exports.StubResponse = StubResponse;
//# sourceMappingURL=stubResponse.js.map