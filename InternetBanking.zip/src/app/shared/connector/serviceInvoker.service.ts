import { Injectable } from '@angular/core';
import { Http, Response, Headers , URLSearchParams, RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import {AppSession} from '../model/appSession';
import {SessionContext} from '../model/sessionContext';
import {StubResponse} from './stubResponse';
import {EncryptionService} from '../services/encryption.service';
import {GlobalURL} from '../services/globalURL';


@Injectable()
export class ServiceInvoker {
    private apiUrl = GlobalURL.SERVICE_URL.SHARED.API_URL; 
    private stubEnabled = GlobalURL.PROPERTIES.STUBS;
    private encServ: EncryptionService = null;

    constructor( private http: Http, 
                 private encryptionService: EncryptionService) {
        this.encServ = encryptionService;
    }

    invoke(op: string, data: any): Observable < any > {
        console.log("executing " + op + " with data " + data);
        let invResult = this.getHttpReq(op, data)
            .map(res => this.extractData(res, this.encryptionService))
            .catch(this.handleError);
        return invResult;
    }

    private extractData(res: Response, encServ: EncryptionService) {
        console.log("extracting data " + res);
        let body = res.text();
        console.log("enc serv " + encServ);
        console.log("body " + body);
        var sessCtx = SessionContext.getInstance();
        var jsonResp = "";
        if (sessCtx.authKey == null) {
            console.log("decoding resp..." + encServ);
            jsonResp = atob(body);
            console.log("decoded jsonResp  " + jsonResp);
        } else {
            console.log("decr req...");
            let key = sessCtx.authKey.encKey;
            let iv = sessCtx.authKey.encIV;
            console.log('before decrypt ' + key + ' ' + iv);
            jsonResp = encServ.decrypt(body, key, iv);
            console.log('afer decrypt ' + jsonResp);
        }
        return jsonResp;
    }

    private createGuid(): string {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0,
                v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    private getHttpReq(op: string, data: any) {
        let headers = new Headers();
       //headers.append('Content-type', 'application/x-www-form-urlencoded');
        headers.append('Content-type', 'text/plain');
        headers.append('Accept', 'application/json');
        var sessCtx = SessionContext.getInstance();
        if (sessCtx.authKey != null) {
            headers.append('Authorization', sessCtx.authKey.convID);
        }
        headers.append('op', op);
        headers.append('dv', "b");
        headers.append('rc', this.createGuid());
        const options = new RequestOptions({
            headers: headers
        });
        const body: URLSearchParams = new URLSearchParams();
        var encReq = '';
        var sessCtx = SessionContext.getInstance();
        if (data != null) {
            const req = JSON.stringify(data);
            if (sessCtx.authKey == null) {
                console.log("encoding req..." + req);
                let words = this.encryptionService.getEncodedKey(req);
                encReq = this.encryptionService.convertToBase64(words);
                console.log("encdReq  " + encReq);
            } else {
                console.log("encryt req...");
                let key = sessCtx.authKey.encKey;
                let iv = sessCtx.authKey.encIV;
                encReq = this.encryptionService.encrypt(req, key, iv);
            }
            console.log("enc req sent: " + encReq + " " + this.apiUrl);
            body.set('request', encReq);
        }
        return this.http.post(this.apiUrl, encReq, options);  
        //return this.http.post(this.apiUrl, body.toString(), options);
    }

    private handleError(error: Response | any) {
        console.log("in error " + error);
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
}