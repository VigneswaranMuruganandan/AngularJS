"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var $ = require("jquery");
var template_service_1 = require("../../shared/services/template.service");
var HamburgerMenu = (function () {
    function HamburgerMenu(el, templateService) {
        this.el = el;
        this.templateService = templateService;
    }
    HamburgerMenu.prototype.onClick = function (event) {
        $('.hamburger').toggleClass('animate');
        this.templateService.checkMenuState();
    };
    __decorate([
        core_1.HostListener('click', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], HamburgerMenu.prototype, "onClick", null);
    HamburgerMenu = __decorate([
        core_1.Directive({
            selector: '[HamburgerMenuDirective]'
        }),
        __metadata("design:paramtypes", [core_1.ElementRef,
            template_service_1.TemplateService])
    ], HamburgerMenu);
    return HamburgerMenu;
}());
exports.HamburgerMenu = HamburgerMenu;
var HamburgerInitDirective = (function () {
    function HamburgerInitDirective(el, templateService) {
        this.el = el;
        this.templateService = templateService;
    }
    HamburgerInitDirective.prototype.ngOnInit = function () {
        this.templateService.showHideMenu();
        this.templateService.checkMenuState();
    };
    HamburgerInitDirective = __decorate([
        core_1.Directive({
            selector: '[HamburgerInitDirective]'
        }),
        __metadata("design:paramtypes", [core_1.ElementRef,
            template_service_1.TemplateService])
    ], HamburgerInitDirective);
    return HamburgerInitDirective;
}());
exports.HamburgerInitDirective = HamburgerInitDirective;
var Navigation = (function () {
    function Navigation(el) {
        this.el = el;
    }
    Navigation.prototype.onClick = function (event) {
        event.preventDefault();
        var el = $(this.el.nativeElement);
        if (el.next().hasClass('show')) {
            el.next().removeClass('show');
            el.next().slideUp(350);
            el.parent().find('a').removeClass('active');
        }
        else {
            el.parent().parent().find('li .inner').removeClass('show');
            el.parent().parent().find('li .inner').slideUp(350);
            el.parent().find('a').addClass('active');
            el.next().toggleClass('show');
            el.next().slideToggle(350);
        }
    };
    __decorate([
        core_1.HostListener('click', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], Navigation.prototype, "onClick", null);
    Navigation = __decorate([
        core_1.Directive({
            selector: '[NavigationDirective]'
        }),
        __metadata("design:paramtypes", [core_1.ElementRef])
    ], Navigation);
    return Navigation;
}());
exports.Navigation = Navigation;
var AccountSettings = (function () {
    function AccountSettings(el) {
        this.el = el;
    }
    AccountSettings.prototype.onClick = function (event) {
        event.preventDefault();
        $(".logged-in-menu").toggleClass("show");
    };
    __decorate([
        core_1.HostListener('click', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], AccountSettings.prototype, "onClick", null);
    AccountSettings = __decorate([
        core_1.Directive({
            selector: '[AccountSettings]'
        }),
        __metadata("design:paramtypes", [core_1.ElementRef])
    ], AccountSettings);
    return AccountSettings;
}());
exports.AccountSettings = AccountSettings;
//# sourceMappingURL=stylers.directive.js.map