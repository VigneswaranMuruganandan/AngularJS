"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var AccountNumberFormatPipe = (function () {
    function AccountNumberFormatPipe() {
    }
    AccountNumberFormatPipe.prototype.transform = function (value, args) {
        if (!value)
            return value;
        return value.replace(/\w\S*/g, function (txt) {
            var split_txt = /^(\d{3})(\d{8})(\d{5})$/.exec(txt);
            return split_txt[1] + '-' + split_txt[2] + '-' + split_txt[3];
        });
    };
    AccountNumberFormatPipe = __decorate([
        core_1.Pipe({ name: 'accountNumberFormat' })
    ], AccountNumberFormatPipe);
    return AccountNumberFormatPipe;
}());
exports.AccountNumberFormatPipe = AccountNumberFormatPipe;
var CardNumberFormatPipe = (function () {
    function CardNumberFormatPipe() {
    }
    CardNumberFormatPipe.prototype.transform = function (value, args) {
        if (!value)
            return value;
        return value.replace(/\w\S*/g, function (txt) {
            var split_txt = /^(\d{4})(\d{4})(\d{4})(\d{4})$/.exec(txt);
            return split_txt[1] + ' ' + split_txt[2] + ' ' + split_txt[3] + ' ' + split_txt[4];
        });
    };
    CardNumberFormatPipe = __decorate([
        core_1.Pipe({ name: 'cardNumberFormat' })
    ], CardNumberFormatPipe);
    return CardNumberFormatPipe;
}());
exports.CardNumberFormatPipe = CardNumberFormatPipe;
var AccountNumberMaskPipe = (function () {
    function AccountNumberMaskPipe() {
    }
    AccountNumberMaskPipe.prototype.transform = function (value, args) {
        if (!value)
            return value;
        return value.replace(/\w\S*/g, function (txt) {
            var split_txt = /^(\d{4})(\d{4})(\d{4})(\d{4})$/.exec(txt);
            return '**** **** **** ' + split_txt[4];
        });
    };
    AccountNumberMaskPipe = __decorate([
        core_1.Pipe({ name: 'accountNumberMask' })
    ], AccountNumberMaskPipe);
    return AccountNumberMaskPipe;
}());
exports.AccountNumberMaskPipe = AccountNumberMaskPipe;
//# sourceMappingURL=stylers.pipe.js.map