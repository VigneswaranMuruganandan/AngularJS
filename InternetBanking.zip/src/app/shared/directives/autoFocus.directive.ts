import {Directive, ElementRef, Renderer2} from '@angular/core';
import * as $ from 'jquery';

@Directive({
    selector: '[autofocus]'
})
export class Autofocus
{
    constructor(private el: ElementRef, private renderer: Renderer2)
    {        
    }

    ngOnInit()
    {        
    }

    ngAfterViewInit()
    {
        var el = $(this.el.nativeElement)[0];
        el.focus();
    }
}