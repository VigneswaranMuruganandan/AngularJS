import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'accountNumberFormat'})
export class AccountNumberFormatPipe implements PipeTransform {
  transform(value: string, args: string[]): any {
    if (!value) return value;

    return value.replace(/\w\S*/g, function(txt) {
    	  let split_txt : Array<string> = /^(\d{3})(\d{8})(\d{5})$/.exec(txt);
        return split_txt[1] + '-' + split_txt[2] + '-' + split_txt[3] ;
    });
  }
}

@Pipe({name: 'cardNumberFormat'})
export class CardNumberFormatPipe implements PipeTransform {
  transform(value: string, args: string[]): any {
    if (!value) return value;

    return value.replace(/\w\S*/g, function(txt) {
    	  let split_txt : Array<string> = /^(\d{4})(\d{4})(\d{4})(\d{4})$/.exec(txt);
        return split_txt[1] + ' ' + split_txt[2] + ' ' + split_txt[3] + ' ' + split_txt[4];
    });
  }
}

@Pipe({name: 'accountNumberMask'})
export class AccountNumberMaskPipe implements PipeTransform {
  transform(value: string, args: string[]): any {
    if (!value) return value;

    return value.replace(/\w\S*/g, function(txt) {
        let split_txt : Array<string> = /^(\d{4})(\d{4})(\d{4})(\d{4})$/.exec(txt);
        return '**** **** **** ' + split_txt[4] ;
    });
  }
}