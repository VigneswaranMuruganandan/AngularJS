
import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[OnlyNumber]'
})
export class OnlyNumber {

  constructor(private el: ElementRef) { }

  @Input() OnlyNumber: boolean;

  @HostListener('keydown', ['$event']) onKeyDown(event: any) {
    let e = <KeyboardEvent> event;
    if (this.OnlyNumber) {

    console.log(e);
         console.log((e.key).length);
        if(((e.key).match(/^[0-9+$]/))!=null){
            return;
         }if((e.key).length >1){
            return;
         }
         else {
            e.preventDefault();
         }
         
        }  
    }
  }

