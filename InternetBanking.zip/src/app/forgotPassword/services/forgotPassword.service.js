"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var serviceInvoker_service_1 = require("../../shared/connector/serviceInvoker.service");
var encryption_service_1 = require("../../shared/services/encryption.service");
var error_service_1 = require("../../shared/services/error.service");
var globalURL_1 = require("../../shared/services/globalURL");
var sessionContext_1 = require("../../shared/model/sessionContext");
var authKey_1 = require("../../shared/model/authKey");
var authData_1 = require("../../shared/model/authData");
var verifyOtpResponse_1 = require("../../shared/model/verifyOtpResponse");
var verifyCustomerResponse_1 = require("../../register/model/verifyCustomerResponse");
var registerPwdResponse_1 = require("../../register/model/registerPwdResponse");
var ForgotPasswordService = (function () {
    function ForgotPasswordService(serviceInvoker, encryptionService, errorService) {
        this.serviceInvoker = serviceInvoker;
        this.encryptionService = encryptionService;
        this.errorService = errorService;
    }
    ForgotPasswordService.prototype.verifyCustomer = function (forgotPassword) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.FORGOT_PASSWORD.CUST_PWDRECOVERY, forgotPassword)
            .map(function (resp) { return _this.populateCustResp(resp); });
    };
    ForgotPasswordService.prototype.verifyOtp = function (forgotPassword) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.VERIFYOTP, forgotPassword)
            .map(function (resp) { return _this.populateOtpResp(resp); });
    };
    ForgotPasswordService.prototype.verifyUsername = function (forgotPassword) {
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.VERIFYUSERNAME, forgotPassword)
            .map(function (resp) { return JSON.parse(resp); });
    };
    ForgotPasswordService.prototype.verifyPassword = function (forgotPassword) {
        console.log(sessionContext_1.SessionContext.getInstance());
        var pwdHash = this.encryptionService.generatePwdHash(sessionContext_1.SessionContext.getInstance().userID, forgotPassword.pwd);
        forgotPassword.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.FORGOT_PASSWORD.VERIFYPASSWORD, forgotPassword)
            .map(function (resp) { return JSON.parse(resp); });
    };
    ForgotPasswordService.prototype.resetPwd = function (forgotPassword) {
        var _this = this;
        console.log(sessionContext_1.SessionContext.getInstance());
        var pwdHash = this.encryptionService.generatePwdHash(sessionContext_1.SessionContext.getInstance().userID, forgotPassword.pwd);
        forgotPassword.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.FORGOT_PASSWORD.RESETPASSWORD, forgotPassword)
            .map(function (resp) { return _this.populatePwdRegisterResp(resp); });
    };
    ForgotPasswordService.prototype.verifyLogin = function (forgotPassword) {
        var _this = this;
        var pwdHash = this.encryptionService.generatePwdHash(sessionContext_1.SessionContext.getInstance().userID, forgotPassword.pwd);
        forgotPassword.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.LOGIN.VERIFYLOGIN, forgotPassword)
            .map(function (resp) { return _this.populateLoginResp(resp); });
    };
    ForgotPasswordService.prototype.populateCustResp = function (resp) {
        console.log("cust resp " + resp);
        var respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            var responseObj = new verifyCustomerResponse_1.VerifyCustomerResponse();
            sessionContext_1.SessionContext.getInstance().userID = respObj.cif;
            responseObj.otpDuration = respObj.otpDuration;
            responseObj.convID = respObj.convID;
            responseObj.cif = respObj.cif;
            responseObj.emailMasked = respObj.emailMasked;
            responseObj.mobileNumberMasked = respObj.mobileNumberMasked;
            responseObj.remainingOtpAttempts = respObj.remainingOtpAttempts;
            return responseObj;
        }
        else if (respObj.result.status == 'error') {
            this.errorService.setErrorResp(respObj.result);
        }
    };
    ForgotPasswordService.prototype.populateOtpResp = function (resp) {
        var respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            var responseObj = new verifyOtpResponse_1.VerifyOtpResponse();
            console.log("res " + respObj.result.success);
            responseObj.userName = respObj.userName;
            return responseObj;
        }
        else if (respObj.result.status == 'error') {
            this.errorService.setErrorResp(respObj.result);
        }
    };
    ForgotPasswordService.prototype.populatePwdRegisterResp = function (resp) {
        var respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            var responseObj = new registerPwdResponse_1.RegisterPwdResponse();
            responseObj = respObj;
            return responseObj;
        }
        else if (respObj.result.status == 'error') {
            this.errorService.setErrorResp(respObj.result);
        }
    };
    ForgotPasswordService.prototype.populateLoginResp = function (resp) {
        var respObj = JSON.parse(resp);
        this.updateSessionContext(respObj);
        var responseObj = new registerPwdResponse_1.RegisterPwdResponse();
        responseObj = respObj;
        console.log("res " + responseObj);
        return responseObj;
    };
    ForgotPasswordService.prototype.updateSessionContext = function (respObj) {
        if (respObj.result.status == 'success') {
            var authData = new authData_1.AuthData();
            authData.authKey = new authKey_1.AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            var sessCtx = sessionContext_1.SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
    };
    ForgotPasswordService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [serviceInvoker_service_1.ServiceInvoker,
            encryption_service_1.EncryptionService,
            error_service_1.ErrorService])
    ], ForgotPasswordService);
    return ForgotPasswordService;
}());
exports.ForgotPasswordService = ForgotPasswordService;
//# sourceMappingURL=forgotPassword.service.js.map