import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ForgotPassword } from '../model/forgotPassword';
import { GlobalVariable } from '../../shared/services/global';
import { ServiceInvoker } from '../../shared/connector/serviceInvoker.service';
import { EncryptionService } from '../../shared/services/encryption.service';
import { ErrorService } from '../../shared/services/error.service';
import { GlobalURL } from '../../shared/services/globalURL';
import { SessionContext } from '../../shared/model/sessionContext';
import { AuthKey } from '../../shared/model/authKey';
import { AuthData } from '../../shared/model/authData';
import { VerifyOtpResponse} from '../../shared/model/verifyOtpResponse';
import { VerifyUsernameResponse } from '../../shared/model/verifyUsernameResponse';
import { VerifyPasswordResponse } from '../../shared/model/verifyPasswordResponse';
import { VerifyCustomerResponse } from '../../register/model/verifyCustomerResponse';
import { RegisterPwdResponse } from '../../register/model/registerPwdResponse';

@Injectable()
export class ForgotPasswordService{


  constructor(  private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService,
                private errorService: ErrorService){
  }

  verifyCustomer(forgotPassword: ForgotPassword): Observable < VerifyCustomerResponse > {
   return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.FORGOT_PASSWORD.CUST_PWDRECOVERY, forgotPassword)
                              .map(resp => this.populateCustResp(resp));
  }

  verifyOtp(forgotPassword: ForgotPassword): Observable < VerifyOtpResponse > {
    return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.VERIFYOTP, forgotPassword)
                              .map(resp => this.populateOtpResp(resp));
  }

  verifyUsername(forgotPassword: ForgotPassword): Observable < VerifyUsernameResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.VERIFYUSERNAME, forgotPassword)
                                .map(resp => JSON.parse(resp));
  }

  verifyPassword(forgotPassword: ForgotPassword): Observable < VerifyPasswordResponse > {
	console.log(SessionContext.getInstance());
	let pwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, forgotPassword.pwd);
	forgotPassword.pwd = this.encryptionService.convertToBase64(pwdHash);
  	return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.FORGOT_PASSWORD.VERIFYPASSWORD, forgotPassword)
                                .map(resp => JSON.parse(resp));
  }

  resetPwd(forgotPassword: ForgotPassword): Observable < RegisterPwdResponse > {
    console.log(SessionContext.getInstance());
    let pwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, forgotPassword.pwd);
    forgotPassword.pwd = this.encryptionService.convertToBase64(pwdHash);
    return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.FORGOT_PASSWORD.RESETPASSWORD, forgotPassword)
                              .map(resp => this.populatePwdRegisterResp(resp));
  }  

  verifyLogin(forgotPassword: ForgotPassword): Observable < RegisterPwdResponse > {
      let pwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, forgotPassword.pwd);
      forgotPassword.pwd = this.encryptionService.convertToBase64(pwdHash);
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOGIN.VERIFYLOGIN, forgotPassword)
                                .map(resp => this.populateLoginResp(resp));
  }

  private populateCustResp(resp: string) {
    console.log("cust resp " + resp);
    let respObj = JSON.parse(resp);
    if(respObj.result.status == 'success'){
    let responseObj = new VerifyCustomerResponse();
      SessionContext.getInstance().userID = respObj.cif;
      responseObj.otpDuration = respObj.otpDuration;
      responseObj.convID = respObj.convID;
      responseObj.cif = respObj.cif;
      responseObj.emailMasked = respObj.emailMasked;
      responseObj.mobileNumberMasked = respObj.mobileNumberMasked;
      responseObj.remainingOtpAttempts = respObj.remainingOtpAttempts;
      return responseObj;
    }else if(respObj.result.status == 'error'){
      this.errorService.setErrorResp(respObj.result);
    }
  }

  private populateOtpResp(resp: string) {
    let respObj = JSON.parse(resp);
    if(respObj.result.status == 'success'){
      var responseObj = new VerifyOtpResponse();
      console.log("res " + respObj.result.success);
      responseObj.userName = respObj.userName;
      return responseObj;
    }else if(respObj.result.status == 'error'){
      this.errorService.setErrorResp(respObj.result);
    } 
  }

  private populatePwdRegisterResp(resp: string) {
      var respObj = JSON.parse(resp);
      if(respObj.result.status == 'success'){
        var responseObj = new RegisterPwdResponse();
        responseObj = respObj;
        return responseObj;
      }else if(respObj.result.status == 'error'){
        this.errorService.setErrorResp(respObj.result);
      } 
  }

  private populateLoginResp(resp: string){
      var respObj = JSON.parse(resp); 
      this.updateSessionContext(respObj);
      var responseObj = new RegisterPwdResponse();
      responseObj = respObj;
      console.log("res " + responseObj);
      return responseObj;
  }

  private updateSessionContext(respObj: any){
    if (respObj.result.status == 'success') {
        var authData = new AuthData();
        authData.authKey = new AuthKey();
        authData.authKey.encIV = respObj.data.encIV;
        authData.authKey.encKey = respObj.data.encKey;
        authData.authKey.convID = respObj.data.convID;
        authData.authKey.macKey = respObj.data.macKey;
        authData.authKey.ec = respObj.data.eventCtr;
        var sessCtx = SessionContext.getInstance();
        sessCtx.authKey = authData.authKey;
    }
  }

}

  

