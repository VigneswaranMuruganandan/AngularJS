"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var forgotPassword_component_1 = require("./Components/forgotPassword.component");
var routes = [
    {
        path: '',
        component: forgotPassword_component_1.ForgotPasswordComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=forgotPassword.routing.js.map