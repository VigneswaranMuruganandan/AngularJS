"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var forgotPassword_routing_1 = require("./forgotPassword.routing");
var core_2 = require("@ngx-translate/core");
var shared_module_1 = require("../shared/shared.module");
var shared_service_1 = require("../shared/services/shared.service");
var template_service_1 = require("../shared/services/template.service");
var forgotPassword_service_1 = require("./services/forgotPassword.service");
var forms_1 = require("@angular/forms");
var forgotPassword_component_1 = require("./Components/forgotPassword.component");
var forgotPasswordStep1_Component_1 = require("./Components/forgotPasswordStep1.Component");
var forgotPasswordStep2_Component_1 = require("./Components/forgotPasswordStep2.Component");
var forgotPasswordStep3_Component_1 = require("./Components/forgotPasswordStep3.Component");
var forgotPasswordStep4_Component_1 = require("./Components/forgotPasswordStep4.Component");
var forgotPasswordStep5_Component_1 = require("./Components/forgotPasswordStep5.Component");
var FORGOTPASSWORD_COMPONENTS = [
    forgotPassword_component_1.ForgotPasswordComponent,
    forgotPasswordStep1_Component_1.ForgotPasswordStep1Component,
    forgotPasswordStep2_Component_1.ForgotPasswordStep2Component,
    forgotPasswordStep3_Component_1.ForgotPasswordStep3Component,
    forgotPasswordStep4_Component_1.ForgotPasswordStep4Component,
    forgotPasswordStep5_Component_1.ForgotPasswordStep5Component
];
var FORGOTPASSWORD_DIRECTIVES = [];
var FORGOTPASSWORD_PROVIDERS = [
    shared_service_1.SharedService,
    template_service_1.TemplateService,
    forgotPassword_service_1.ForgotPasswordService
];
var ForgotPasswordModule = (function () {
    function ForgotPasswordModule() {
    }
    ForgotPasswordModule = __decorate([
        core_1.NgModule({
            imports: [
                forgotPassword_routing_1.routing,
                core_2.TranslateModule.forChild(),
                shared_module_1.SharedModule,
                forms_1.FormsModule,
                common_1.CommonModule
            ],
            declarations: FORGOTPASSWORD_COMPONENTS /*,
          ...FORGOTPASSWORD_DIRECTIVES*/.slice(),
            providers: FORGOTPASSWORD_PROVIDERS.slice()
        })
    ], ForgotPasswordModule);
    return ForgotPasswordModule;
}());
exports.ForgotPasswordModule = ForgotPasswordModule;
//# sourceMappingURL=forgotPassword.module.js.map