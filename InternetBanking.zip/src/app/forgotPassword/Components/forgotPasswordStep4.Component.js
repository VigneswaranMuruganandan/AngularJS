"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var shared_service_1 = require("../../shared/services/shared.service");
var customerData_1 = require("../../register/model/customerData");
var template_service_1 = require("../../shared/services/template.service");
var spinner_service_1 = require("../../shared/services/spinner.service");
var forgotPassword_service_1 = require("../services/forgotPassword.service");
var error_service_1 = require("../../shared/services/error.service");
var forgotPassword_1 = require("../model/forgotPassword");
var ForgotPasswordStep4Component = (function () {
    function ForgotPasswordStep4Component(forgotPasswordService, sharedService, templateService, errorService, spinnerService) {
        this.forgotPasswordService = forgotPasswordService;
        this.sharedService = sharedService;
        this.templateService = templateService;
        this.errorService = errorService;
        this.spinnerService = spinnerService;
        this.validateForgotNewPasswordEvent = new core_1.EventEmitter();
    }
    ForgotPasswordStep4Component.prototype.ngOnInit = function () {
        this.passwordData = { "password": "", "confirmPassword": "" };
        this.showConfirmPassword = false;
        this.spinnerService.stopSpinner();
    };
    ForgotPasswordStep4Component.prototype.passwordValidations = function (flag) {
        this.validPasswordFlag = flag;
    };
    ForgotPasswordStep4Component.prototype.validatePassword = function () {
        var _this = this;
        if (this.validPasswordFlag) {
            this.errorService.resetErrorResp();
            var data = new forgotPassword_1.ForgotPassword();
            data.pwd = this.passwordData.password;
            this.forgotPasswordService.verifyPassword(data)
                .subscribe(function (resp) { return _this.handleVerifyPasswordResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
        }
    };
    ForgotPasswordStep4Component.prototype.handleVerifyPasswordResp = function (resp) {
        if (resp && resp.result.status == 'success') {
            this.showConfirmPassword = true;
        }
        else if (resp && resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    };
    ForgotPasswordStep4Component.prototype.validateConfirmPassword = function (valid) {
        if (valid) {
            this.templateService.resetFormValidatorFlag();
            this.validateForgotNewPasswordEvent.emit(this.passwordData.password);
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Boolean)
    ], ForgotPasswordStep4Component.prototype, "validPasswordFlag", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], ForgotPasswordStep4Component.prototype, "validateForgotNewPasswordEvent", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", customerData_1.CustomerData)
    ], ForgotPasswordStep4Component.prototype, "customerData", void 0);
    ForgotPasswordStep4Component = __decorate([
        core_1.Component({
            selector: 'forgotpasswordstep4-component',
            templateUrl: './../templates/forgotPasswordStep4.html'
        }),
        __metadata("design:paramtypes", [forgotPassword_service_1.ForgotPasswordService,
            shared_service_1.SharedService,
            template_service_1.TemplateService,
            error_service_1.ErrorService,
            spinner_service_1.SpinnerService])
    ], ForgotPasswordStep4Component);
    return ForgotPasswordStep4Component;
}());
exports.ForgotPasswordStep4Component = ForgotPasswordStep4Component;
//# sourceMappingURL=forgotPasswordStep4.Component.js.map