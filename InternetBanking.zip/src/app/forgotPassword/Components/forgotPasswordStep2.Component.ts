import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { CustomerData } from '../../register/model/customerData';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'forgotpasswordstep2-component',
  templateUrl: './../templates/forgotPasswordStep2.html'
})
export class ForgotPasswordStep2Component implements OnInit{
	@Output() validateForgotPwdOTPEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	public otp:string;
	public otpList :Array<string>;

	constructor( private errorService: ErrorService ){}
	
	ngOnInit() { 
    	this.otpList = ['','','','','','']
    }

	validateOTP(){
		this.errorService.resetErrorResp();
		this.otp = this.otpList.join('');
		this.validateForgotPwdOTPEvent.emit(this.otp);
	}
}