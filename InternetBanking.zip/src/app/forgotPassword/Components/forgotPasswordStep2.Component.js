"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var customerData_1 = require("../../register/model/customerData");
var error_service_1 = require("../../shared/services/error.service");
var ForgotPasswordStep2Component = (function () {
    function ForgotPasswordStep2Component(errorService) {
        this.errorService = errorService;
        this.validateForgotPwdOTPEvent = new core_1.EventEmitter();
    }
    ForgotPasswordStep2Component.prototype.ngOnInit = function () {
        this.otpList = ['', '', '', '', '', ''];
    };
    ForgotPasswordStep2Component.prototype.validateOTP = function () {
        this.errorService.resetErrorResp();
        this.otp = this.otpList.join('');
        this.validateForgotPwdOTPEvent.emit(this.otp);
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], ForgotPasswordStep2Component.prototype, "validateForgotPwdOTPEvent", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", customerData_1.CustomerData)
    ], ForgotPasswordStep2Component.prototype, "customerData", void 0);
    ForgotPasswordStep2Component = __decorate([
        core_1.Component({
            selector: 'forgotpasswordstep2-component',
            templateUrl: './../templates/forgotPasswordStep2.html'
        }),
        __metadata("design:paramtypes", [error_service_1.ErrorService])
    ], ForgotPasswordStep2Component);
    return ForgotPasswordStep2Component;
}());
exports.ForgotPasswordStep2Component = ForgotPasswordStep2Component;
//# sourceMappingURL=forgotPasswordStep2.Component.js.map