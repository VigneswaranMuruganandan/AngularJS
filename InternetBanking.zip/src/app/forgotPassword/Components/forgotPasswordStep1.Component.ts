import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'forgotpasswordstep1-component',
  templateUrl: './../templates/forgotPasswordStep1.html'
})
export class ForgotPasswordStep1Component {
	@Output() validateCustomerIdentificationForgotPwdEvent = new EventEmitter();

	private customerID:string;

	constructor( private templateService: TemplateService,
				private errorService: ErrorService) {}

	validateCustomer(valid: boolean){
		console.log(" customerID:" + this.customerID);
		if(valid){
			this.templateService.resetFormValidatorFlag();
			this.errorService.resetErrorResp();
			this.validateCustomerIdentificationForgotPwdEvent.emit(this.customerID);	
		}
	}
}