import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { CustomerData } from '../../register/model/customerData';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'forgotpasswordstep3-component',
  templateUrl: './../templates/forgotPasswordStep3.html'
})
export class ForgotPasswordStep3Component {
	@Input() validUsernameFlag: boolean;
	@Output() validateForgotPwdUsernameEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	private userName:string;
	
	constructor( private errorService: ErrorService ){}

    usernameValidations(flag :boolean){
    	this.validUsernameFlag = flag;
    }

	validateUsername(){
		this.errorService.resetErrorResp();
		this.validateForgotPwdUsernameEvent.emit(this.userName);
	}
}