"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ForgotPassword = (function () {
    function ForgotPassword() {
    }
    return ForgotPassword;
}());
exports.ForgotPassword = ForgotPassword;
//# sourceMappingURL=forgotPassword.js.map