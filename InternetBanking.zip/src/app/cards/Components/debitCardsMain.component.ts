import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  templateUrl: './../templates/debitCardsMain.html'
})
export class DebitCardsMainComponent{
	
	
	
}