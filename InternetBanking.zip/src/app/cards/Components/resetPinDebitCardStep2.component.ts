import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'resetPinDebitCardStep2-component',
  templateUrl: './../templates/resetPinDebitCardStep2.html'
})
export class ResetPinDebitCardStep2Component{
	@Output() validateOTPDebitCardResetPinEvent = new EventEmitter();
	constructor(private templateService: TemplateService) {}

	validateOTP(event:any){
		this.validateOTPDebitCardResetPinEvent.emit();
	}
	
}