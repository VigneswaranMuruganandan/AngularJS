import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  templateUrl: './../templates/resetPinDebitCard.html'
})
export class ResetPinDebitCardComponent implements OnInit{
	public stepNumber: number;
	
	
	ngOnInit() { 
    	this.stepNumber = 1;
    }

    validateDebitCardResetPin(){
    	this.stepNumber = 2;
    	console.log("begin debit card activitation process");
    }

    validateOTPDebitCardResetPin(){
        console.log("OTP")
        this.stepNumber = 3;
    }

    validatePinDebitCard(){
        console.log("set pin")
        this.stepNumber = 4;
    }
    validateConfirmPinDebitCard(){
        console.log("set pin")
        this.stepNumber = 5;
    }
	
}