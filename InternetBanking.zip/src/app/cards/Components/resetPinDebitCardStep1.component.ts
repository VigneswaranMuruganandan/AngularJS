import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'resetPinDebitCardStep1-component',
  templateUrl: './../templates/resetPinDebitCardStep1.html'
})
export class ResetPinDebitCardStep1Component implements OnInit{

	@Output() validateDebitCardResetPinEvent = new EventEmitter();
	
	constructor(private templateService: TemplateService) {}

	ngOnInit() { 
    	
    }
	beginDebitCardResetPin(event:any){
		
		this.validateDebitCardResetPinEvent.emit();
	}
}