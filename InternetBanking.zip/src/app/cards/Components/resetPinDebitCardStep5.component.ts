import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'resetPinDebitCardStep5-component',
  templateUrl: './../templates/resetPinDebitCardStep5.html'
})
export class ResetPinDebitCardStep5Component{
	
	constructor(private templateService: TemplateService) {}	
}