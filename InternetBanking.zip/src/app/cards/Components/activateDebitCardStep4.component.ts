import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'activateDebitCardStep4-component',
  templateUrl: './../templates/activateDebitCardStep4.html'
})
export class ActivateDebitCardStep4Component implements OnInit{
	@Output() validateConfirmPinDebitCardEvent = new EventEmitter();
	constructor(private templateService: TemplateService) {}
	private pin:string;
	private pinList :Array<string>;

	ngOnInit() { 
    	this.pinList = ['','','','']
    }	

	validateConfirmPin(event:any){
		this.pin=this.pinList.join('');
		this.validateConfirmPinDebitCardEvent.emit(this.pin);
	}
	
}