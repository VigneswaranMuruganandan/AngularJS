import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'activateDebitCardStep3-component',
  templateUrl: './../templates/activateDebitCardStep3.html'
})
export class ActivateDebitCardStep3Component implements OnInit{
	@Output() validatePinDebitCardEvent = new EventEmitter();
	constructor(private templateService: TemplateService) {}
	private pin:string;
	private pinList :Array<string>;

	ngOnInit() { 
    	this.pinList = ['','','','']
    }
	validatePin(event:any){
		this.pin=this.pinList.join('');
		this.validatePinDebitCardEvent.emit(this.pin);
	}
}