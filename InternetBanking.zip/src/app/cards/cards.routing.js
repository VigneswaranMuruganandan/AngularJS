"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var creditCardPinReset_component_1 = require("./Components/creditCardPinReset.component");
var activateDebitCard_component_1 = require("./Components/activateDebitCard.component");
var debitCardsMain_component_1 = require("./Components/debitCardsMain.component");
var resetPinDebitCard_component_1 = require("./Components/resetPinDebitCard.component");
var routes = [
    {
        path: '',
        component: debitCardsMain_component_1.DebitCardsMainComponent
    },
    {
        path: 'creditCardPinReset',
        component: creditCardPinReset_component_1.CreditCardPinResetComponent
    },
    {
        path: 'resetPinDebitCard',
        component: resetPinDebitCard_component_1.ResetPinDebitCardComponent
    },
    {
        path: 'activateDebitCard',
        component: activateDebitCard_component_1.ActivateDebitCardComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=cards.routing.js.map