import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';
import { routing } from './cards.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { CardsComponent }   from './Components/cards.component';
import { CreditCardPinResetComponent }   from './Components/creditCardPinReset.component';
import { ActivateDebitCardComponent }   from './Components/activateDebitCard.component';
import { ActivateDebitCardStep1Component }   from './Components/activateDebitCardStep1.component';
import { ActivateDebitCardStep2Component }   from './Components/activateDebitCardStep2.component';
import { ActivateDebitCardStep3Component }   from './Components/activateDebitCardStep3.component';
import { ActivateDebitCardStep4Component }   from './Components/activateDebitCardStep4.component';
import { ActivateDebitCardStep5Component }   from './Components/activateDebitCardStep5.component';
import { ResetPinDebitCardComponent }   from './Components/resetPinDebitCard.component';
import { ResetPinDebitCardStep1Component }   from './Components/resetPinDebitCardStep1.component';
import { ResetPinDebitCardStep2Component }   from './Components/resetPinDebitCardStep2.component';
import { ResetPinDebitCardStep3Component }   from './Components/resetPinDebitCardStep3.component';
import { ResetPinDebitCardStep4Component }   from './Components/resetPinDebitCardStep4.component';
import { ResetPinDebitCardStep5Component }   from './Components/resetPinDebitCardStep5.component';
import { DebitCardsMainComponent }   from './Components/debitCardsMain.component';
import { DebitCardsDetailsComponent }   from './Components/debitCardsDetails.component';
import { DebitCardsRightContentComponent }   from './Components/debitCardsRightContent.component';

const CARDS_COMPONENTS = [
    CardsComponent,
    CreditCardPinResetComponent,
    ActivateDebitCardComponent,
    ActivateDebitCardStep1Component,
    ActivateDebitCardStep2Component,
    ActivateDebitCardStep3Component,
    ActivateDebitCardStep4Component,
    ActivateDebitCardStep5Component,
    ResetPinDebitCardComponent,
    ResetPinDebitCardStep1Component,
    ResetPinDebitCardStep2Component,
    ResetPinDebitCardStep3Component,
    ResetPinDebitCardStep4Component,
    ResetPinDebitCardStep5Component,
    DebitCardsMainComponent,
    DebitCardsDetailsComponent,
    DebitCardsRightContentComponent
];

const CARDS_DIRECTIVES = [
];

const CARDS_PROVIDERS = [
   SharedService,
   TemplateService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      	CommonModule
	],
  	declarations: [
	  	...CARDS_COMPONENTS/*,
      	...CARDS_DIRECTIVES*/
	],
	providers: [
		...CARDS_PROVIDERS
	]
})
export class CardsModule {}
