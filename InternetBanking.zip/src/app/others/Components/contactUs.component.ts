import { Component, OnInit, Input} from '@angular/core';

@Component({
  templateUrl: './../templates/contactUs.html'
})
export class ContactUsComponent {
	

}