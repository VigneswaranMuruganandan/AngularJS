import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './others.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { OthersService } from './services/others.service';
import { FormsModule } from '@angular/forms';
import { OthersComponent } from './Components/others.component';
import { ContactUsComponent } from './Components/contactUs.component';


const OTHERS_COMPONENTS = [
    OthersComponent,
    ContactUsComponent
];

const OTHERS_PROVIDERS = [
   SharedService,
   TemplateService,
   OthersService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      	CommonModule
	],
  	declarations: [
	    ...OTHERS_COMPONENTS
	],
  	providers: [
  		...OTHERS_PROVIDERS
  	]
})
export class OthersModule {}
