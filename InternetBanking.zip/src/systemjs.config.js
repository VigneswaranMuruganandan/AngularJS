/**
 * System configuration for Angular samples
 * Adjust as necessary for your application needs.
 */
(function (global) {
  System.config({
    paths: {
      // paths serve as alias
      'npm:': 'node_modules/'
    },
    // map tells the System loader where to look for things
    map: {
      // our app is within the app folder
      //'app': 'dist/app',
      'app': 'app',
      '@ngx-translate/core': 'app/assets/node_modules/core.umd.js',
      '@ngx-translate/http-loader': 'app/assets/node_modules/http-loader.umd.js',

      // angular bundles
      '@angular/core': 'app/assets/node_modules/angular-core.umd.js',
      '@angular/common': 'app/assets/node_modules/common.umd.js',
      '@angular/compiler': 'app/assets/node_modules/compiler.umd.js',
      '@angular/platform-browser': 'app/assets/node_modules/platform-browser.umd.js',
      '@angular/platform-browser-dynamic': 'app/assets/node_modules/platform-browser-dynamic.umd.js',
      '@angular/http': 'app/assets/node_modules/http.umd.js',
      '@angular/router': 'app/assets/node_modules/router.umd.js',
      '@angular/forms': 'app/assets/node_modules/forms.umd.js',

      // other libraries      
      'crypto-js': 'app/assets/node_modules/crypto-js.js',
      'jquery': 'app/assets/node_modules/jquery.js',
      'bootstrap': 'app/assets/node_modules/bootstrap.min.js',
      'jquery-validator': 'app/assets/js/jquery.validate.js',
      'slick-carousel': 'app/assets/node_modules/slick.js',
      'date-picker': 'app/assets/js/jquery-ui.js',      
      '@swimlane/ngx-datatable':'app/assets/node_modules/ngx-datatable.js',
      'lodash': 'app/assets/node_modules/lodash.js',
      'rxjs': 'npm:rxjs',
      'angular-in-memory-web-api': 'app/assets/node_modules/in-memory-web-api.umd.js',
      'typescript': 'app/assets/node_modules/typescript.js',
      
    },
    // packages tells the System loader how to load when no filename and/or no extension
    packages: {
      app: {
        defaultExtension: 'js',
        meta: {
          './*.js': {
            loader: 'systemjs-angular-loader.js'
          }
        }
      },
      rxjs: { defaultExtension: 'js' },
      'angular2-datatable': { main: 'index.js',defaultExtension: 'js' },
      '@swimlane/ngx-datatable': { main: 'index.js',defaultExtension: 'js' },
      'lodash':{ defaultExtension: 'js' },
    }
  });
})(this);
